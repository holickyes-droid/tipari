
  # Project Catalog Design_V2 (Copy)

  This is a code bundle for Project Catalog Design_V2 (Copy). The original project is available at https://www.figma.com/design/xh2xSG5Cc2bzQa5YORylp9/Project-Catalog-Design_V2--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  