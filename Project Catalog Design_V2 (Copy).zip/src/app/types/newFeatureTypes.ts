/**
 * NEW FEATURE TYPES - TYPE DEFINITIONS
 * 
 * TypeScript interfaces and types for NewFeature module
 * Development Expansion Zone - Safe to modify
 */

/**
 * Base feature data structure
 */
export interface FeatureData {
  id: string;
  name: string;
  description?: string;
  status: FeatureStatus;
  createdAt: Date;
  updatedAt?: Date;
}

/**
 * Feature status enum
 */
export type FeatureStatus = 
  | 'draft'
  | 'active'
  | 'completed'
  | 'archived';

/**
 * Feature configuration
 */
export interface FeatureConfig {
  enabled: boolean;
  maxItems?: number;
  allowDuplicates?: boolean;
  notifications?: boolean;
}

/**
 * Feature analytics
 */
export interface FeatureAnalytics {
  views: number;
  interactions: number;
  conversions: number;
  conversionRate: number;
}

/**
 * API response wrapper
 */
export interface FeatureApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: string;
}

/**
 * User preferences for feature
 */
export interface FeaturePreferences {
  userId: string;
  autoSave: boolean;
  displayMode: 'grid' | 'list' | 'table';
  sortBy: 'name' | 'date' | 'status';
  sortOrder: 'asc' | 'desc';
}
