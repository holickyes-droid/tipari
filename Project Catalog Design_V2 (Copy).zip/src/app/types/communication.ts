/**
 * COMMUNICATION & ACTIVITY TRACKING
 * 
 * Pro sledování historie komunikace mezi Tiparem a investory
 * včetně poznámek, odeslaných dokumentů a dalších aktivit
 */

export type CommunicationActivityType =
  | 'TICKET_OFFERED'          // Tiket nabídnut investorovi
  | 'CONTRACT_SENT'           // Rezervační smlouva (RA) zaslána
  | 'CONTRACT_SIGNED'         // RA podepsána investorem
  | 'EMAIL_SENT'              // Obecný e-mail
  | 'PHONE_CALL'              // Telefonní hovor
  | 'MEETING_SCHEDULED'       // Schůzka naplánována
  | 'MEETING_COMPLETED'       // Schůzka proběhla
  | 'NOTE_ADDED'              // Interní poznámka přidána
  | 'DOCUMENT_SENT'           // Dokument zaslán
  | 'FOLLOW_UP'               // Follow-up komunikace
  | 'STATUS_CHANGED'          // Status změněn
  | 'SLA_EXPIRED';            // SLA vypršelo - rezervace ukončena systémem

export type CommunicationChannel =
  | 'EMAIL'
  | 'PHONE'
  | 'PLATFORM'
  | 'IN_PERSON'
  | 'OTHER';

export interface CommunicationActivity {
  id: string;
  reservationId: string;
  activityType: CommunicationActivityType;
  channel?: CommunicationChannel;
  
  // Content
  title: string;                // Krátký popis aktivity
  description?: string;         // Detailní popis (volitelný)
  notes?: string;               // Interní poznámky (neviditelné pro investora)
  
  // Metadata
  createdAt: string;            // ISO date
  createdBy: string;            // Tipar ID
  createdByName: string;        // Tipar jméno
  
  // Attachments
  documentUrl?: string;         // URL dokumentu, pokud byl zaslán
  documentName?: string;        // Název dokumentu
  
  // Related entities
  investorId?: string;
  emailSubject?: string;        // Pro e-maily
  phoneNumber?: string;         // Pro hovory
  meetingDate?: string;         // Pro schůzky
}

export interface InvestorNote {
  id: string;
  investorId: string;
  reservationId?: string;       // Volitelné - poznámka může být obecná
  
  // Content
  content: string;              // Text poznámky
  category?: 'GENERAL' | 'PREFERENCE' | 'RISK' | 'FOLLOW_UP' | 'OTHER';
  isImportant?: boolean;        // Označit jako důležité
  
  // Metadata
  createdAt: string;
  createdBy: string;
  createdByName: string;
  updatedAt?: string;
  
  // Tags for organization
  tags?: string[];
}

/**
 * Communication Timeline Item
 * Kombinovaný view pro zobrazení všech aktivit v časové ose
 */
export interface TimelineItem {
  id: string;
  type: 'activity' | 'note' | 'system';
  timestamp: string;
  title: string;
  description?: string;
  actor: string;               // Kdo provedl akci
  icon?: string;               // Icon name pro zobrazení
  color?: string;              // Barva pro vizuální odlišení
  data?: CommunicationActivity | InvestorNote;
}

/**
 * Communication Summary
 * Přehled komunikace pro rychlý náhled
 */
export interface CommunicationSummary {
  totalActivities: number;
  lastContactDate?: string;
  emailsSent: number;
  phoneCalls: number;
  meetingsHeld: number;
  documentsShared: number;
  notesCount: number;
  contractsSent: number;
  contractsSigned: number;
}