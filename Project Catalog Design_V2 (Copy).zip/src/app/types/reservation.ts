/**
 * Reservation Entity
 */
export interface Reservation {
  id: string;
  reservationNumber: string; // Human-readable (e.g., "RES-2024-001234")
  
  // Links
  introducerId: string;
  slotId: string; // Which global slot is locked
  projectId: string;
  ticketId: string;
  investorId: string;
  
  // Lifecycle
  phase: ReservationPhase;
  status: ReservationStatus;
  nextActor: NextActor;
  
  // Dates
  createdAt: string; // ISO date
  expiresAt?: string; // ISO date (SLA deadline)
  investorSignedAt?: string; // Phase 1 → 2
  developerApprovedAt?: string; // Phase 2 → 3
  meetingConfirmedAt?: string; // Phase 3 → 4 (ACTIVE MOMENT)
  meetingCompletedAt?: string; // Phase 4 → 5
  closedAt?: string; // Phase 6A/6B/X
  
  // Meeting Details (revealed only after confirmation)
  proposedMeetingDates?: string[]; // ISO dates
  selectedMeetingDate?: string; // ISO date
  meetingLocation?: string;
  
  // Outcome
  dealSuccessful?: boolean; // true = SUCCESS, false = NO_DEAL, undefined = EXPIRED
  outcomeNotes?: string;
  estimatedProvision?: number; // Calculated commission if successful
  
  // Expiration tracking
  expiredFromPhase?: ReservationPhase; // Track which phase reservation expired from
  
  // Metadata
  cancelledBy?: string; // User ID if manually cancelled
  cancelReason?: string;
  slaViolation?: boolean; // If expired due to SLA
  
  // Audit Log / History
  auditLog?: ReservationAuditEvent[]; // Internal history for support, disputes, and tracking
  
  // Additional metadata
  investorName?: string;
  meetingScheduledDate?: string;
  slaDeadline?: string;
  updatedAt?: string;
}

/**
 * Reservation Audit Event
 * Internal history tracking for support, disputes, and auditing
 */
export interface ReservationAuditEvent {
  id: string; // Unique event ID
  timestamp: string; // ISO date when event occurred
  eventType: 
    | 'reservation_created'
    | 'reservation_expired'
    | 'investor_signed'
    | 'developer_approved'
    | 'developer_rejected'
    | 'meeting_confirmed'
    | 'meeting_completed'
    | 'reservation_closed_success'
    | 'reservation_closed_no_deal'
    | 'reservation_cancelled'
    | 'slot_locked'
    | 'slot_released';
  
  reason?: string; // Human-readable reason
  effect?: string; // What changed as a result
  performedBy?: string; // User ID or 'SYSTEM'
  metadata?: Record<string, any>; // Additional context
}