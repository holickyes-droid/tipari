export type ProjectType = 'Residential' | 'Commercial' | 'Development';
export type ProjectStatus = 'Open' | 'Fully reserved' | 'Paused' | 'Finished';
export type LegacyProjectStatus = 'Active' | 'Last slots available' | 'Sold out' | 'Inactive';
export type DevelopmentStage = 'Development' | 'Financování' | 'Refinancování' | 'Akvizice shares' | 'Akvizice Asset' | 'Redevelopment' | 'Prodej Asset' | 'Prodej SPV';
export type AssetClass = 'Rezidenční' | 'Logistika' | 'Komerční' | 'Smíšený' | 'Retail' | 'Hotel' | 'Pozemky' | 'Energetika' | 'Ostatní';
export type InvestmentForm = 'Juniorní zápůjčka' | 'Seniorní zápůjčka' | 'Majoritní ekvita' | 'Minoritní ekvita' | 'Prodej' | 'Zpětný leasing' | 'Mezanin';

export type ValuationType = 'Interní ocenění' | 'Externí ocenění' | 'Bez ocenění';

export type ProfitSharingType = 
  | 'Ne'
  | 'Ano / Smluvní'
  | { type: 'Fixní'; percentage: number };

export type InterestPayoutSchedule = 
  | 'Měsíčně'
  | 'Čtvrtletně'
  | 'Pololetně'
  | 'Ročně'
  | 'Při splatnosti'
  | 'Jiné';

export type SlotState = 'Available' | 'Reserved' | 'Expired' | 'Completed';

export type ReservationState = 'active' | 'expired' | 'completed' | 'cancelled';

export type DocumentStatus = 'Available' | 'Pending' | 'Not available';

export type DocumentType = 'PDF' | 'DOCX' | 'XLSX' | 'ZIP';

export interface ProjectDocument {
  id: string;
  name: string;
  fileType: DocumentType;
  status: DocumentStatus;
  uploadDate?: string; // ISO date
  fileSize?: string; // e.g., "2.4 MB"
}

export type SecurityType = 
  | 'Zástava 1. pořadí'
  | 'Zástava 2. pořadí'
  | 'Zástava k OP, KL, Akcie'
  | 'Osobní směnka'
  | 'Firemní směnka'
  | 'Notářský zápis'
  | 'Notářský zápis s přímou vykonatelností'
  | 'Ručitelský závazek'
  | 'Postoupení pohledávek'
  | 'Zástava movitých věcí'
  | 'Zajištění nájmů'
  | 'Převedení vlastnictví se zpětným odkupem'
  | 'Zajišťovací blankosměnka'
  | 'Bez zajištění';

export interface LTVDetails {
  value: number;
  appraisalType: 'externí' | 'interní' | 'ne';
  appraiserName?: string;
  appraiserCompany?: string;
  appraiserWebsite?: string;
  appraisalDocumentUrl?: string;
}

export interface Slot {
  id: string;
  ticketId: string;
  state: SlotState;
  reservedBy?: string; // investor ID
  reservedAt?: string; // ISO date
  expiresAt?: string; // ISO date
  completedAt?: string; // ISO date
}

export interface Reservation {
  id: string;
  slotId: string;
  ticketId: string;
  projectId: string;
  investorId: string;
  investorName: string;
  state: ReservationState;
  createdAt: string; // ISO date
  expiresAt: string; // ISO date
  completedAt?: string; // ISO date
  cancelledAt?: string; // ISO date
  cancelledBy?: string; // user ID who cancelled
  cancelReason?: string;
}

export interface Ticket {
  id: string;
  ticketNumber: string;
  investmentAmount: number;
  yieldPA: number;
  duration: number;
  secured: boolean;
  securedTypes?: SecurityType[];
  ltv?: number;
  ltvDetails?: LTVDetails;
  commission: number;
  occupancy: {
    current: number;
    total: number;
  };
  recommendedInvestors: string[];
  remainingReservations: number;
  matchPercentage?: number;
  recommendation?: 'Nejlepší' | 'Vhodný' | string;
  investmentForm?: InvestmentForm;
  // New domain fields
  profitSharing?: ProfitSharingType;
  interestPayout?: InterestPayoutSchedule;
  slots?: Slot[];
  reservations?: Reservation[];
}

export interface Project {
  id: string;
  name: string;
  location: string;
  type: ProjectType;
  developmentStage: DevelopmentStage;
  assetClass: AssetClass;
  status: ProjectStatus;
  imageUrl: string;
  totalInvestmentVolume: number;
  yieldPA: number;
  ltv: number;
  investmentForm: InvestmentForm;
  commission: number;
  secured: boolean;
  securedByRealEstate: boolean;
  timeLimited: boolean;
  slaDeadline?: string;
  tickets: Ticket[];
  relevanceScore?: number;
  broughtByCurrentUser?: boolean; // If this project was submitted by the current introducer
  ownerId?: string; // ID of the Tipar who uploaded this project
  description?: string; // Added for project detail
  // New domain fields
  valuationType?: ValuationType;
  profitSharing?: ProfitSharingType;
  documents?: ProjectDocument[];
  // Developer info
  developerName?: string;
  developerCompany?: string;
  developerRating?: 'A+' | 'A' | 'A-' | 'B+' | 'B' | 'B-' | 'C';
  developerEmail?: string;
  developerPhone?: string;
  developerWebsite?: string;
  developerDescription?: string;
}

export type FilterOptions = {
  status: ProjectStatus[];
  type: ProjectType[];
  location: string[];
  yieldRange: [number, number];
  durationRange: [number, number];
  ltvRange: [number, number];
  occupancy: 'all' | 'available' | 'limited';
  relevance: 'all' | 'high';
};

export type SortOption = 
  | 'relevance' 
  | 'newest' 
  | 'priority'
  | 'yield-desc'
  | 'yield-asc'
  | 'ltv-asc'
  | 'ltv-desc'
  | 'duration-asc'
  | 'duration-desc'
  | 'volume-desc'
  | 'volume-asc'
  | 'commission-desc'
  | 'commission-asc'
  | 'available-tickets';