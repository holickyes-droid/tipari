/**
 * NOTIFICATION CONTEXT
 * Global notification state management for Tipari.cz
 * Handles in-app notifications (bell icon / notification center)
 */

import { createContext, useContext, useState, ReactNode, useCallback } from 'react';

export type NotificationType = 'reservation' | 'project' | 'payment' | 'system';
export type NotificationIcon = 'success' | 'error' | 'warning' | 'info' | 'payment' | 'calendar' | 'project' | 'sla';

/**
 * Notification Priority Levels
 * - INFO: Informational only, no action required
 * - WARNING: Attention recommended, but not urgent
 * - CRITICAL: System action performed, requires user awareness
 */
export type NotificationPriority = 'INFO' | 'WARNING' | 'CRITICAL';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  description: string;
  context: string; // Project name / Ticket ID / Reservation number
  timestamp: string;
  timestampDate?: Date; // Exact timestamp for sorting and display
  unread: boolean;
  priority: NotificationPriority; // Required: every notification must have a priority
  icon: NotificationIcon;
  link?: string; // Navigation link (e.g., reservation ID for detail view)
  isPermanent?: boolean; // If true, notification is stored permanently for audit trail
  systemEventLabel?: string; // Label for system events (e.g., "Systémová událost")
  metadata?: {
    reservationId?: string;
    reservationNumber?: string;
    projectName?: string;
    [key: string]: any;
  };
}

interface NotificationContextValue {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'unread'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  removeNotification: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextValue | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([
    // Mock initial notifications
    {
      id: '1',
      type: 'reservation',
      title: 'Rezervace potvrzena',
      description: 'Investor potvrdil schůzku na 5. ledna 2025',
      context: 'T-001-01 • Business Center Praha',
      timestamp: '2h ago',
      unread: true,
      priority: 'INFO',
      icon: 'success',
    },
    {
      id: '2',
      type: 'system',
      title: 'Rezervace expiruje za 24h',
      description: 'Dokončete podpis rezervační smlouvy',
      context: 'T-003-02 • Green Valley',
      timestamp: '3h ago',
      unread: true,
      priority: 'CRITICAL',
      icon: 'warning',
    },
    {
      id: '3',
      type: 'payment',
      title: 'Provize schválena',
      description: 'Provize z rezervace byla schválena k výplatě',
      context: '245 000 Kč • T-001-01',
      timestamp: '5h ago',
      unread: true,
      priority: 'INFO',
      icon: 'payment',
    },
    {
      id: '4',
      type: 'project',
      title: 'Nový projekt publikován',
      description: 'Nová investiční příležitost splňuje vaše kritéria',
      context: 'Residence Karlín',
      timestamp: 'Yesterday',
      unread: false,
      priority: 'INFO',
      icon: 'project',
    },
  ]);

  const unreadCount = notifications.filter(n => n.unread).length;

  const addNotification = useCallback((notification: Omit<Notification, 'id' | 'timestamp' | 'unread'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: 'Just now',
      unread: true,
    };

    setNotifications(prev => [newNotification, ...prev]);
  }, []);

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, unread: false } : n))
    );
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        removeNotification,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within NotificationProvider');
  }
  return context;
}