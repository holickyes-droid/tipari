/**
 * CUSTOM HOOK: useReservationFlow
 * Centralized state management for reservation flow
 * Genius pattern: Separation of concerns, testability, reusability
 */

import { useState, useCallback, useMemo } from 'react';
import { toast } from 'sonner';
import { Ticket } from '../types/project';

export type SignatureMethod = 'electronic' | 'physical' | null;

export type FlowStep = 
  | 'investor-selection'
  | 'summary'
  | 'signature-method'
  | 'waiting-electronic'
  | 'electronic-signed'
  | 'waiting-physical-upload'
  | 'upload-document'
  | 'document-uploaded'
  | 'physical-confirmed'
  | 'reservation-pending';

export interface Investor {
  id: string;
  name: string;
  initials: string;
  type: 'Privátní investor' | 'Family office' | 'Investiční skupina' | 'Právnická osoba';
  email: string;
  phone: string;
  portfolioValue: number;
  activeInvestments: number;
  preferredAmount: number;
  preferredYield: number;
}

export interface UploadedDocument {
  fileName: string;
  uploadedAt: number;
  fileSize: number;
}

export interface ReservationData {
  reservationNumber: string;
  createdAt: number;
  expiresAt: number;
  signatureMethod: SignatureMethod;
  investor: Investor;
  uploadedDocument?: UploadedDocument;
}

interface NewInvestorData {
  name: string;
  type: string;
  email: string;
  phone: string;
}

export function useReservationFlow(ticket: Ticket | null, onSaveDraft?: Function) {
  const [currentStep, setCurrentStep] = useState<FlowStep>('investor-selection');
  const [selectedSignature, setSelectedSignature] = useState<SignatureMethod>(null);
  const [selectedInvestor, setSelectedInvestor] = useState<Investor | null>(null);
  const [showNewInvestorForm, setShowNewInvestorForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [reservation, setReservation] = useState<ReservationData | null>(null);
  const [uploadedDoc, setUploadedDoc] = useState<UploadedDocument | null>(null);
  const [showContractPreview, setShowContractPreview] = useState(false);
  const [showEmailChangeForm, setShowEmailChangeForm] = useState(false);
  const [customEmail, setCustomEmail] = useState('');
  const [contractSentAt, setContractSentAt] = useState<Date | null>(null);
  const [showCloseConfirmation, setShowCloseConfirmation] = useState(false);
  const [newInvestorData, setNewInvestorData] = useState<NewInvestorData>({
    name: '',
    type: 'Privátní investor',
    email: '',
    phone: ''
  });

  // Mock CRM investors - in production, this would come from API
  const [crmInvestors, setCrmInvestors] = useState<Investor[]>([
    {
      id: '1',
      name: 'Andrea Nováková',
      initials: 'AN',
      type: 'Privátní investor',
      email: 'andrea.novakova@example.com',
      phone: '+420 601 234 567',
      portfolioValue: 15000000,
      activeInvestments: 3,
      preferredAmount: 5000000,
      preferredYield: 6.5,
    },
    {
      id: '2',
      name: 'Petr Svoboda',
      initials: 'PS',
      type: 'Investiční skupina',
      email: 'petr.svoboda@investgroup.cz',
      phone: '+420 602 345 678',
      portfolioValue: 50000000,
      activeInvestments: 8,
      preferredAmount: 10000000,
      preferredYield: 5.5,
    },
    {
      id: '3',
      name: 'Jana Malá',
      initials: 'JM',
      type: 'Family office',
      email: 'jana.mala@familyoffice.cz',
      phone: '+420 603 456 789',
      portfolioValue: 80000000,
      activeInvestments: 12,
      preferredAmount: 8000000,
      preferredYield: 5.0,
    },
    {
      id: '4',
      name: 'Martin Černý s.r.o.',
      initials: 'MC',
      type: 'Právnická osoba',
      email: 'info@cerny.cz',
      phone: '+420 604 567 890',
      portfolioValue: 25000000,
      activeInvestments: 5,
      preferredAmount: 6000000,
      preferredYield: 6.0,
    },
  ]);

  // Filtered investors with memoization for performance
  const filteredInvestors = useMemo(
    () => crmInvestors.filter(inv =>
      inv.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.type.toLowerCase().includes(searchQuery.toLowerCase())
    ),
    [crmInvestors, searchQuery]
  );

  // Navigation handlers with useCallback for performance
  const handleSelectInvestor = useCallback((investor: Investor) => {
    setSelectedInvestor(investor);
  }, []);

  const handleContinueToSummary = useCallback(() => {
    if (!selectedInvestor || !ticket) return;
    
    if (onSaveDraft) {
      const draft = {
        id: `draft-${Date.now()}`,
        ticket,
        projectName: ticket.ticketNumber,
        investorName: selectedInvestor.name,
        currentStep: 'summary',
        savedAt: new Date(),
      };
      onSaveDraft(draft);
      
      toast.success('Rezervace uložena', {
        description: `Rozpracovaná rezervace pro ${selectedInvestor.name} byla automaticky uložena.`,
        duration: 4000,
      });
    }
    
    setCurrentStep('summary');
  }, [selectedInvestor, ticket, onSaveDraft]);

  const handleContinueToSignature = useCallback(() => {
    setCurrentStep('signature-method');
  }, []);

  const createReservation = useCallback(() => {
    if (!selectedInvestor || !selectedSignature) return;
    
    const now = Math.floor(Date.now() / 1000);
    setReservation({
      reservationNumber: `R-${Math.floor(Math.random() * 10000)}`,
      createdAt: now,
      expiresAt: now + (48 * 60 * 60),
      signatureMethod: selectedSignature,
      investor: selectedInvestor,
      uploadedDocument: uploadedDoc || undefined,
    });
  }, [selectedInvestor, selectedSignature, uploadedDoc]);

  const handleSignatureMethodSelected = useCallback(() => {
    if (!selectedSignature) return;
    
    if (selectedSignature === 'electronic') {
      const emailToUse = customEmail || selectedInvestor?.email;
      if (!emailToUse) {
        toast.error('Chyba', {
          description: 'Prosím zadejte email investora pro zaslání smlouvy',
        });
        return;
      }
      
      setContractSentAt(new Date());
      setCurrentStep('waiting-electronic');
      
      // Simulate electronic signing
      setTimeout(() => {
        setCurrentStep('electronic-signed');
        createReservation();
      }, 3000);
    } else {
      setCurrentStep('waiting-physical-upload');
    }
  }, [selectedSignature, customEmail, selectedInvestor, createReservation]);

  const handleUploadDocument = useCallback(() => {
    setCurrentStep('upload-document');
  }, []);

  const handleDocumentUploaded = useCallback(() => {
    const doc: UploadedDocument = {
      fileName: 'rezervacni_smlouva_podepsana.pdf',
      uploadedAt: Math.floor(Date.now() / 1000),
      fileSize: 245632,
    };
    setUploadedDoc(doc);
    setCurrentStep('document-uploaded');
  }, []);

  const handleConfirmPhysicalSignature = useCallback(() => {
    createReservation();
    setCurrentStep('physical-confirmed');
  }, [createReservation]);

  const handleContinueToPending = useCallback(() => {
    setCurrentStep('reservation-pending');
  }, []);

  const handleBack = useCallback(() => {
    const backMap: Partial<Record<FlowStep, FlowStep>> = {
      'summary': 'investor-selection',
      'signature-method': 'summary',
      'waiting-physical-upload': 'signature-method',
      'upload-document': 'waiting-physical-upload',
      'document-uploaded': 'waiting-physical-upload',
      'waiting-electronic': 'signature-method',
    };
    
    const previousStep = backMap[currentStep];
    if (previousStep) {
      setCurrentStep(previousStep);
    }
  }, [currentStep]);

  const handleResendContract = useCallback(() => {
    const emailToUse = customEmail || selectedInvestor?.email;
    if (!emailToUse) return;
    
    setContractSentAt(new Date());
    setShowEmailChangeForm(false);
    
    toast.success('Smlouva odeslána', {
      description: `Smlouva byla odeslána na email: ${emailToUse}`,
    });
  }, [customEmail, selectedInvestor]);

  return {
    // State
    currentStep,
    selectedSignature,
    selectedInvestor,
    showNewInvestorForm,
    searchQuery,
    reservation,
    uploadedDoc,
    showContractPreview,
    showEmailChangeForm,
    customEmail,
    contractSentAt,
    showCloseConfirmation,
    newInvestorData,
    crmInvestors,
    filteredInvestors,
    
    // Setters
    setCurrentStep,
    setSelectedSignature,
    setSelectedInvestor,
    setShowNewInvestorForm,
    setSearchQuery,
    setReservation,
    setUploadedDoc,
    setShowContractPreview,
    setShowEmailChangeForm,
    setCustomEmail,
    setContractSentAt,
    setShowCloseConfirmation,
    setNewInvestorData,
    setCrmInvestors,
    
    // Handlers
    handleSelectInvestor,
    handleContinueToSummary,
    handleContinueToSignature,
    handleSignatureMethodSelected,
    handleUploadDocument,
    handleDocumentUploaded,
    handleConfirmPhysicalSignature,
    handleContinueToPending,
    handleBack,
    handleResendContract,
    createReservation,
  };
}
