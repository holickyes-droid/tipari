/**
 * USE NEW FEATURE HOOK - CUSTOM REACT HOOK
 * 
 * Custom hook for managing NewFeature state and logic
 * Development Expansion Zone - Independent module
 */

import { useState, useEffect, useCallback } from 'react';
import { FeatureData, FeatureStatus } from '../types/newFeatureTypes';
import { fetchNewFeatureData } from '../components/NewFeature/NewFeatureLogic';

interface UseNewFeatureOptions {
  autoLoad?: boolean;
  refreshInterval?: number;
}

export function useNewFeature(options: UseNewFeatureOptions = {}) {
  const { autoLoad = false, refreshInterval } = options;

  const [data, setData] = useState<FeatureData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Load feature data
   */
  const loadData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetchNewFeatureData('/api/feature');
      
      if (response.success) {
        setData(response.data || []);
      } else {
        setError('Nepodařilo se načíst data');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Neznámá chyba');
    } finally {
      setIsLoading(false);
    }
  }, []);

  /**
   * Add new item
   */
  const addItem = useCallback((item: Omit<FeatureData, 'id' | 'createdAt'>) => {
    const newItem: FeatureData = {
      ...item,
      id: `feature-${Date.now()}`,
      createdAt: new Date(),
    };

    setData(prev => [...prev, newItem]);
  }, []);

  /**
   * Update existing item
   */
  const updateItem = useCallback((id: string, updates: Partial<FeatureData>) => {
    setData(prev =>
      prev.map(item =>
        item.id === id
          ? { ...item, ...updates, updatedAt: new Date() }
          : item
      )
    );
  }, []);

  /**
   * Remove item
   */
  const removeItem = useCallback((id: string) => {
    setData(prev => prev.filter(item => item.id !== id));
  }, []);

  /**
   * Filter items by status
   */
  const filterByStatus = useCallback((status: FeatureStatus) => {
    return data.filter(item => item.status === status);
  }, [data]);

  /**
   * Auto-load on mount
   */
  useEffect(() => {
    if (autoLoad) {
      loadData();
    }
  }, [autoLoad, loadData]);

  /**
   * Auto-refresh interval
   */
  useEffect(() => {
    if (refreshInterval && refreshInterval > 0) {
      const intervalId = setInterval(() => {
        loadData();
      }, refreshInterval);

      return () => clearInterval(intervalId);
    }
  }, [refreshInterval, loadData]);

  return {
    data,
    isLoading,
    error,
    loadData,
    addItem,
    updateItem,
    removeItem,
    filterByStatus,
  };
}
