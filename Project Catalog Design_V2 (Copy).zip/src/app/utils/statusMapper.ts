import { ProjectStatus, LegacyProjectStatus } from '../types/project';

/**
 * Maps legacy status values to new framework-compliant status values
 * This maintains backward compatibility while transitioning to the new status system
 */
export function mapLegacyStatusToFramework(legacyStatus: LegacyProjectStatus): ProjectStatus {
  const mapping: Record<LegacyProjectStatus, ProjectStatus> = {
    'Active': 'Open',
    'Last slots available': 'Open', // Still open, just with urgency indicator
    'Sold out': 'Fully subscribed',
    'Inactive': 'Closed',
  };

  return mapping[legacyStatus];
}

/**
 * Determines if a project should show urgency indicators
 * (e.g., "Last slots" badge) based on ticket availability
 */
export function hasUrgencyIndicator(status: LegacyProjectStatus): boolean {
  return status === 'Last slots available';
}

/**
 * Maps framework status back to legacy for display purposes
 * (if needed for gradual migration)
 */
export function mapFrameworkStatusToLegacy(frameworkStatus: ProjectStatus): LegacyProjectStatus {
  const mapping: Record<ProjectStatus, LegacyProjectStatus> = {
    'Open': 'Active',
    'Fully subscribed': 'Sold out',
    'Paused': 'Inactive',
    'Closed': 'Inactive',
  };

  return mapping[frameworkStatus];
}

/**
 * Gets human-readable Czech label for framework status
 */
export function getStatusLabel(status: ProjectStatus): string {
  const labels: Record<ProjectStatus, string> = {
    'Open': 'Aktivní',
    'Fully subscribed': 'Plně zainvestováno',
    'Paused': 'Pozastaveno',
    'Closed': 'Uzavřeno',
  };

  return labels[status];
}

/**
 * Gets status color for UI display
 */
export function getStatusColor(status: ProjectStatus): string {
  const colors: Record<ProjectStatus, string> = {
    'Open': '#14AE6B', // Green
    'Fully subscribed': '#6B7280', // Gray
    'Paused': '#F59E0B', // Orange
    'Closed': '#6B7280', // Gray
  };

  return colors[status];
}
