/**
 * RESERVATION & SLOT UTILITY FUNCTIONS
 * Tipari.cz B2B Investment Referral Platform
 */

import {
  ReservationPhase,
  ReservationStatus,
  ReservationDisplayInfo,
  SlotState,
  NextActor,
  Reservation,
  SlotAvailability,
  ReservationActions,
} from '../types/reservation';
import { Ticket } from '../types/project';

// ============================================================================
// PHASE & STATUS LABELS (Czech)
// ============================================================================

export const PHASE_LABELS: Record<ReservationPhase, string> = {
  WAITING_INVESTOR_SIGNATURE: 'Čeká na podpis investora',
  WAITING_DEVELOPER_DECISION: 'Čeká na rozhodnutí developera',
  WAITING_MEETING_SELECTION: 'Čeká na výběr termínu schůzky',
  MEETING_CONFIRMED: 'Schůzka potvrzena — aktivní rezervace',
  MEETING_COMPLETED: 'Schůzka proběhla',
  SUCCESS: 'Úspěšné uzavření — provize nárokována',
  NO_DEAL: 'Uzavřeno bez dohody',
  EXPIRED: 'Vypršelo — slot uvolněn',
};

export const STATUS_LABELS: Record<ReservationStatus, string> = {
  waiting_investor_signature: 'Čeká na podpis investora',
  waiting_developer_decision: 'Čeká na rozhodnutí developera',
  waiting_meeting_selection: 'Čeká na výběr termínu',
  meeting_confirmed: 'Schůzka potvrzena',
  meeting_completed: 'Schůzka proběhla',
  successful: 'Úspěšné',
  closed_no_deal: 'Bez dohody',
  expired: 'Vypršelo',
};

export const NEXT_ACTOR_LABELS: Record<NextActor, string> = {
  INVESTOR: 'Investor',
  DEVELOPER: 'Developer',
  ADMIN: 'Administrátor',
  NONE: '—',
};

export const SLOT_STATE_LABELS: Record<SlotState, string> = {
  FREE: 'Volný',
  LOCKED_WAITING: 'Zamčený (čeká)',
  LOCKED_CONFIRMED: 'Zamčený (aktivní)',
  RELEASED: 'Uvolněný',
  USED: 'Využitý',
};

// ============================================================================
// DISPLAY INFO HELPERS
// ============================================================================

/**
 * Get complete display info for reservation
 */
export function getReservationDisplayInfo(reservation: Reservation): ReservationDisplayInfo {
  const phaseLabel = PHASE_LABELS[reservation.phase];
  
  // Determine status color
  let statusColor: 'green' | 'yellow' | 'gray' | 'red' = 'gray';
  if (reservation.phase === 'MEETING_CONFIRMED' || reservation.phase === 'SUCCESS') {
    statusColor = 'green';
  } else if (reservation.phase === 'EXPIRED' || reservation.phase === 'NO_DEAL') {
    statusColor = 'red';
  } else if (
    reservation.phase === 'WAITING_INVESTOR_SIGNATURE' ||
    reservation.phase === 'WAITING_DEVELOPER_DECISION' ||
    reservation.phase === 'WAITING_MEETING_SELECTION'
  ) {
    statusColor = 'yellow';
  }
  
  // Determine status icon
  let statusIcon = 'Clock';
  if (reservation.phase === 'MEETING_CONFIRMED') statusIcon = 'CheckCircle';
  if (reservation.phase === 'SUCCESS') statusIcon = 'Award';
  if (reservation.phase === 'EXPIRED') statusIcon = 'XCircle';
  if (reservation.phase === 'NO_DEAL') statusIcon = 'MinusCircle';
  
  // Next actor label
  const nextActorLabel = NEXT_ACTOR_LABELS[reservation.nextActor];
  
  // SLA remaining
  let slaRemaining: number | undefined;
  let slaExpired = false;
  if (reservation.expiresAt) {
    const now = new Date();
    const expires = new Date(reservation.expiresAt);
    const diffMs = expires.getTime() - now.getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    slaRemaining = diffDays;
    slaExpired = diffDays < 0;
  }
  
  // Is active?
  const isActive = reservation.phase === 'MEETING_CONFIRMED' || reservation.phase === 'MEETING_COMPLETED';
  
  // Identities revealed?
  const identitiesRevealed = !!reservation.meetingConfirmedAt;
  
  return {
    phase: reservation.phase,
    phaseLabel,
    statusColor,
    statusIcon,
    nextActorLabel,
    sllaRemaining: slaRemaining,
    slaExpired,
    isActive,
    identitiesRevealed,
  };
}

/**
 * Get reservation actions based on phase and user role
 */
export function getReservationActions(
  reservation: Reservation,
  userRole: 'INTRODUCER' | 'INVESTOR' | 'DEVELOPER' | 'ADMIN'
): ReservationActions {
  const actions: ReservationActions = {
    canCancel: false,
    canSignRA: false,
    canApprove: false,
    canReject: false,
    canSelectMeeting: false,
    canUploadAgreement: false,
    canMarkNoAgreement: false,
    requiresUserAction: false,
  };
  
  // Introducer can always cancel before meeting confirmation
  if (userRole === 'INTRODUCER') {
    if (
      reservation.phase !== 'SUCCESS' &&
      reservation.phase !== 'NO_DEAL' &&
      reservation.phase !== 'EXPIRED' &&
      reservation.phase !== 'MEETING_CONFIRMED' &&
      reservation.phase !== 'MEETING_COMPLETED'
    ) {
      actions.canCancel = true;
    }
  }
  
  // Investor actions
  if (userRole === 'INVESTOR') {
    if (reservation.phase === 'WAITING_INVESTOR_SIGNATURE') {
      actions.canSignRA = true;
      actions.requiresUserAction = true;
    }
    if (reservation.phase === 'WAITING_MEETING_SELECTION') {
      actions.canSelectMeeting = true;
      actions.requiresUserAction = true;
    }
  }
  
  // Developer actions
  if (userRole === 'DEVELOPER') {
    if (reservation.phase === 'WAITING_DEVELOPER_DECISION') {
      actions.canApprove = true;
      actions.canReject = true;
      actions.requiresUserAction = true;
    }
  }
  
  // Admin actions
  if (userRole === 'ADMIN') {
    if (reservation.phase === 'MEETING_COMPLETED') {
      actions.canUploadAgreement = true;
      actions.canMarkNoAgreement = true;
      actions.requiresUserAction = true;
    }
  }
  
  return actions;
}

// ============================================================================
// SLOT AVAILABILITY HELPERS
// ============================================================================

/**
 * Check if user can create new reservation on ticket
 */
export function checkSlotAvailability(
  ticket: Ticket,
  globalSlotsFree: number,
  globalSlotsTotal: number,
  ticketReservationCount: number
): SlotAvailability {
  const hasGlobalSlots = globalSlotsFree > 0;
  const hasTicketSlots = ticketReservationCount < 3;
  const hasTicketCapacity = ticket.occupancy.current < ticket.occupancy.total;
  
  const canReserve = hasGlobalSlots && hasTicketSlots && hasTicketCapacity;
  
  let blockingReason: string | undefined;
  if (!hasGlobalSlots) {
    blockingReason = `Nemáte volné sloty (${globalSlotsTotal}/${globalSlotsTotal} použitých)`;
  } else if (!hasTicketSlots) {
    blockingReason = `Dosažen limit rezervací na tento tiket (${ticketReservationCount}/3)`;
  } else if (!hasTicketCapacity) {
    blockingReason = 'Tiket je plně obsazen';
  }
  
  return {
    hasGlobalSlots,
    globalSlotsFree,
    globalSlotsTotal,
    hasTicketSlots,
    ticketReservations: ticketReservationCount,
    ticketMaxReservations: 3,
    hasTicketCapacity,
    ticketOccupancy: ticket.occupancy,
    canReserve,
    blockingReason,
  };
}

/**
 * Format slot count display
 */
export function formatSlotCount(free: number, total: number): string {
  return `${free}/${total} volných`;
}

/**
 * Format ticket reservation count
 */
export function formatTicketReservationCount(count: number): string {
  return `${count}/3 rezervací`;
}

// ============================================================================
// SLA & DEADLINE HELPERS
// ============================================================================

/**
 * Calculate days remaining until deadline
 */
export function calculateDaysRemaining(isoDate: string): number {
  const now = new Date();
  const deadline = new Date(isoDate);
  const diffMs = deadline.getTime() - now.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Calculate hours remaining until deadline
 */
export function calculateHoursRemaining(isoDate: string): number {
  const now = new Date();
  const deadline = new Date(isoDate);
  const diffMs = deadline.getTime() - now.getTime();
  return Math.ceil(diffMs / (1000 * 60 * 60));
}

/**
 * Format SLA deadline display
 */
export function formatSLADeadline(isoDate: string): string {
  const daysRemaining = calculateDaysRemaining(isoDate);
  
  if (daysRemaining < 0) {
    return `Prošlo před ${Math.abs(daysRemaining)} dny`;
  } else if (daysRemaining === 0) {
    const hoursRemaining = calculateHoursRemaining(isoDate);
    if (hoursRemaining <= 0) return 'Vypršelo';
    return `Zbývá ${hoursRemaining}h`;
  } else if (daysRemaining === 1) {
    return 'Zbývá 1 den';
  } else if (daysRemaining <= 7) {
    return `Zbývá ${daysRemaining} dny`;
  } else {
    return `Zbývá ${daysRemaining} dní`;
  }
}

/**
 * Get SLA color indicator
 */
export function getSLAColor(isoDate: string): 'green' | 'yellow' | 'red' {
  const daysRemaining = calculateDaysRemaining(isoDate);
  
  if (daysRemaining < 0) return 'red';
  if (daysRemaining <= 1) return 'red';
  if (daysRemaining <= 3) return 'yellow';
  return 'green';
}

// ============================================================================
// BUSINESS LOGIC VALIDATORS
// ============================================================================

/**
 * Validate if reservation can be created
 */
export function validateReservationCreation(
  globalSlotsFree: number,
  ticketReservationCount: number,
  ticketOccupancy: { current: number; total: number }
): { valid: boolean; error?: string } {
  if (globalSlotsFree === 0) {
    return { valid: false, error: 'Nemáte volné sloty pro novou rezervaci' };
  }
  
  if (ticketReservationCount >= 3) {
    return { valid: false, error: 'Dosažen limit 3 rezervací na tento tiket' };
  }
  
  if (ticketOccupancy.current >= ticketOccupancy.total) {
    return { valid: false, error: 'Tiket je plně obsazen' };
  }
  
  return { valid: true };
}

/**
 * Validate if reservation can be cancelled
 */
export function validateReservationCancellation(phase: ReservationPhase): { 
  valid: boolean; 
  error?: string;
} {
  // Cannot cancel after meeting is confirmed
  if (
    phase === 'MEETING_CONFIRMED' ||
    phase === 'MEETING_COMPLETED' ||
    phase === 'SUCCESS' ||
    phase === 'NO_DEAL' ||
    phase === 'EXPIRED'
  ) {
    return { 
      valid: false, 
      error: 'Nelze zrušit rezervaci v této fázi' 
    };
  }
  
  return { valid: true };
}
