/**
 * Compliance-first tooltip definitions for all risk metrics and domain terms
 * These ensure auditability and clarity as required by the framework
 */

export const METRIC_TOOLTIPS = {
  // Risk & Security Metrics
  LTV: {
    label: 'LTV (Loan-to-Value)',
    definition: 'Poměr výše úvěru k hodnotě zajištění. Nižší LTV = vyšší bezpečnostní polštář. Hodnota je orientační a nepředstavuje garanci návratnosti investice.',
    example: 'LTV 65% znamená, že úvěr činí 65% z hodnoty zajišťovací nemovitosti.',
  },
  
  YIELD: {
    label: 'Výnos p.a.',
    definition: 'Orientační roční výnos (per annum). Skutečný výnos může být nižší v závislosti na realizaci projektu a tržních podmínkách. Nejedná se o zaručený výnos.',
    example: '8.5% p.a. = očekávaný roční výnos 8.5%',
  },

  DURATION: {
    label: 'Doba trvání',
    definition: 'Plánovaná doba trvání investice v měsících. Skutečná doba může být kratší nebo delší v závislosti na průběhu projektu.',
    example: '24 měsíců = očekávaná doba splatnosti 2 roky',
  },

  SECURED: {
    label: 'Zajištěno',
    definition: 'Investice je zajištěna zástavním právem k nemovitosti nebo jinému aktivu. V případě defaultu má investor právo uspokojit svou pohledávku z výtěžku prodeje zajištění.',
    example: 'Zajištěno zástavním právem prvního pořadí k rezidenčnímu projektu',
  },

  COMMISSION: {
    label: 'Provize',
    definition: 'Provize zprostředkovatele za úspěšné zprostředkování investice. Vyplácena při úspěšné alokaci investice.',
    example: '2.5% z objemu investice',
  },

  OCCUPANCY: {
    label: 'Obsazenost',
    definition: 'Aktuální stav obsazenosti investičních slotů. Ukazuje, kolik investičních jednotek je již obsazeno z celkového počtu dostupných slotů v projektu.',
    example: '3 z 5 slotů = 3 obsazené, 2 volné',
  },

  // Security Types
  SECURITY_FIRST_LIEN: {
    label: 'Zástava 1. pořadí',
    definition: 'Nejprioritnější zajištění. V případě exekuce má držitel zástavního práva první pořadí přednost před ostatními věřiteli.',
  },

  SECURITY_SECOND_LIEN: {
    label: 'Zástava 2. pořadí',
    definition: 'Sekundární zajištění. V případě exekuce má držitel zástavního práva druhé pořadí přednost až po uspokojení držitele prvního pořadí.',
  },

  SECURITY_SHARES_PLEDGE: {
    label: 'Zástava obchodního podílu',
    definition: 'Zajištění ve formě zástavy obchodního podílu ve společnosti (s.r.o., a.s., apod.).',
  },

  SECURITY_NO_SECURITY: {
    label: 'Bez zajištění',
    definition: 'Nezajištěná zápůjčka. Vyšší riziko ztráty investice. Doporučeno pouze pro investory s vysokou tolerancí rizika.',
  },

  // Valuation Types
  VALUATION_EXTERNAL: {
    label: 'Externí ocenění',
    definition: 'Ocenění provedené nezávislým externím znalcem. Poskytuje vyšší míru objektivity.',
  },

  VALUATION_INTERNAL: {
    label: 'Interní ocenění',
    definition: 'Ocenění provedené interním týmem developera nebo investora. Může být méně objektivní než externí ocenění.',
  },

  VALUATION_NONE: {
    label: 'Bez ocenění',
    definition: 'Není k dispozici formální ocenění aktiv. Zvýšené riziko nesprávného ohodnocení zajištění.',
  },

  // Profit Sharing
  PROFIT_SHARING_NO: {
    label: 'Bez podílu na zisku',
    definition: 'Investor získává pouze fixní úrokový výnos. Nemá nárok na podíl ze zisku projektu.',
  },

  PROFIT_SHARING_NEGOTIABLE: {
    label: 'Podíl na zisku - smluvní',
    definition: 'Možnost dojednat podíl na zisku projektu nad rámec fixního úroku. Podmínky podléhají individuální dohodě.',
  },

  PROFIT_SHARING_FIXED: {
    label: 'Podíl na zisku - fixní',
    definition: 'Investor má nárok na pevně stanovený podíl ze zisku projektu nad rámec základního výnosu.',
  },

  // Interest Payout
  PAYOUT_MONTHLY: {
    label: 'Měsíční výplata',
    definition: 'Úroky jsou vypláceny každý měsíc. Nejvyšší frekvence cash flow.',
  },

  PAYOUT_QUARTERLY: {
    label: 'Čtvrtletní výplata',
    definition: 'Úroky jsou vypláceny jednou za 3 měsíce.',
  },

  PAYOUT_AT_MATURITY: {
    label: 'Při splatnosti',
    definition: 'Úroky jsou vypláceny jednorázově na konci investičního období spolu s jistinou.',
  },

  // Slot States
  SLOT_AVAILABLE: {
    label: 'Dostupný slot',
    definition: 'Slot je volný a připravený k rezervaci pro investora.',
  },

  SLOT_RESERVED: {
    label: 'Rezervovaný slot',
    definition: 'Slot je dočasně rezervován pro konkrétního investora. Rezervace má omezenou platnost.',
  },

  SLOT_EXPIRED: {
    label: 'Slot s vypršenou rezervací',
    definition: 'Rezervace vypršela a slot je opět dostupný pro jiné investory.',
  },

  SLOT_COMPLETED: {
    label: 'Dokončený slot',
    definition: 'Investice byla úspěšně dokončena a slot je obsazen.',
  },

  // Development Stage / Use of Funds
  USE_DEVELOPMENT: {
    label: 'Development',
    definition: 'Prostředky budou použity na výstavbu/vývoj projektu.',
  },

  USE_FINANCING: {
    label: 'Financování',
    definition: 'Prostředky budou použity na primární financování projektu.',
  },

  USE_REFINANCING: {
    label: 'Refinancování',
    definition: 'Prostředky budou použity na refinancování existujícího dluhu.',
  },

  // Risk Factors
  RISK_MARKET: {
    label: 'Tržní riziko',
    definition: 'Riziko změny tržních podmínek, které mohou negativně ovlivnit hodnotu projektu, poptávku po produktu nebo návratnost investice.',
  },

  RISK_CONSTRUCTION: {
    label: 'Stavební riziko',
    definition: 'Riziko prodlení ve výstavbě, překročení rozpočtu nebo technických komplikací během realizace projektu.',
  },

  RISK_DEVELOPER: {
    label: 'Riziko developera',
    definition: 'Riziko finanční nestability developera, nedostatku zkušeností nebo neplnění závazků.',
  },

  RISK_LIQUIDITY: {
    label: 'Riziko likvidity',
    definition: 'Riziko obtížného nebo zpožděného prodeje aktiva či předčasného ukončení investice za nepříznivých podmínek.',
  },

  RISK_REGULATORY: {
    label: 'Regulatorní riziko',
    definition: 'Riziko změn legislativy, stavebních předpisů, územního plánu nebo jiných regulací ovlivňujících projekt.',
  },

  RISK_VALUATION: {
    label: 'Oceňovací riziko',
    definition: 'Riziko, že skutečná tržní hodnota zajištění je nižší než odhadovaná hodnota, zejména při interním nebo zastaralém ocenění.',
  },

  RISK_LTV: {
    label: 'Riziko LTV',
    definition: 'Při vysokém LTV je bezpečnostní polštář menší, což zvyšuje riziko ztráty při výkonu zajištění v případě poklesu hodnoty aktiva.',
  },
};

/**
 * Get tooltip definition by key
 */
export function getTooltip(key: keyof typeof METRIC_TOOLTIPS) {
  return METRIC_TOOLTIPS[key];
}

/**
 * Format tooltip for display component
 */
export function formatTooltipContent(key: keyof typeof METRIC_TOOLTIPS): string {
  const tooltip = METRIC_TOOLTIPS[key];
  if (!tooltip) return '';
  
  let content = `<strong>${tooltip.label}</strong><br/>${tooltip.definition}`;
  if (tooltip.example) {
    content += `<br/><br/><em>Příklad: ${tooltip.example}</em>`;
  }
  
  return content;
}