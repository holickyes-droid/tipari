/**
 * FORMATTERS UTILITY
 * Centralized formatting functions for currency, dates, numbers
 * Genius pattern: DRY, consistency, performance with memoization
 */

// Currency formatter singleton for performance
const currencyFormatter = new Intl.NumberFormat('cs-CZ', {
  style: 'decimal',
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

const currencyFormatterWithDecimals = new Intl.NumberFormat('cs-CZ', {
  style: 'decimal',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const dateFormatter = new Intl.DateTimeFormat('cs-CZ', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
});

const dateTimeFormatter = new Intl.DateTimeFormat('cs-CZ', {
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
});

/**
 * Format number as Czech currency (Kč)
 */
export function formatCurrency(amount: number, includeDecimals = false): string {
  const formatter = includeDecimals ? currencyFormatterWithDecimals : currencyFormatter;
  return `${formatter.format(amount)} Kč`;
}

/**
 * Format number as compact Czech currency (mil. Kč for millions)
 */
export function formatCurrencyCompact(amount: number): string {
  if (amount >= 1000000) {
    return `${(amount / 1000000).toFixed(1)} mil. Kč`;
  }
  if (amount >= 1000) {
    return `${Math.round(amount / 1000)} tis. Kč`;
  }
  return formatCurrency(amount);
}

/**
 * Format date to Czech format (DD.MM.YYYY)
 */
export function formatDate(date: Date | string | number): string {
  const dateObj = typeof date === 'object' ? date : new Date(date);
  return dateFormatter.format(dateObj);
}

/**
 * Format date and time to Czech format (DD.MM.YYYY HH:MM)
 */
export function formatDateTime(date: Date | string | number): string {
  const dateObj = typeof date === 'object' ? date : new Date(date);
  return dateTimeFormatter.format(dateObj);
}

/**
 * Format percentage with optional decimal places
 */
export function formatPercentage(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`;
}

/**
 * Format file size in bytes to human readable format
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

/**
 * Format duration in months to human readable format
 */
export function formatDuration(months: number): string {
  if (months < 12) {
    return `${months} měs.`;
  }
  
  const years = Math.floor(months / 12);
  const remainingMonths = months % 12;
  
  if (remainingMonths === 0) {
    return `${years} ${years === 1 ? 'rok' : years < 5 ? 'roky' : 'let'}`;
  }
  
  return `${years} ${years === 1 ? 'rok' : years < 5 ? 'roky' : 'let'} ${remainingMonths} měs.`;
}

/**
 * Format number with thousands separator
 */
export function formatNumber(value: number): string {
  return currencyFormatter.format(value);
}

/**
 * Get initials from full name
 */
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

/**
 * Truncate text with ellipsis
 */
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength - 3) + '...';
}

/**
 * Format phone number to Czech format
 */
export function formatPhoneNumber(phone: string): string {
  // Remove all non-digit characters
  const cleaned = phone.replace(/\D/g, '');
  
  // Check if it's a Czech number
  if (cleaned.startsWith('420')) {
    const number = cleaned.slice(3);
    return `+420 ${number.slice(0, 3)} ${number.slice(3, 6)} ${number.slice(6)}`;
  }
  
  // Default format
  return phone;
}
