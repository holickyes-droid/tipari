/**
 * SECURITY TIER SYSTEM
 * Professional legal + investment perspective on collateral quality
 */

export type SecurityType =
  | 'Zástava 1. pořadí'
  | 'Zástava 2. pořadí'
  | 'Zástava k OP, KL, Akcie'
  | 'Osobní směnka'
  | 'Firemní směnka'
  | 'Notářský zápis'
  | 'Notářský zápis s přímou vykonatelností'
  | 'Ručitelský závazek'
  | 'Postoupení pohledávek'
  | 'Zástava movitých věcí'
  | 'Zajištění nájmů'
  | 'Převedení vlastnictví se zpětným odkupem'
  | 'Zajišťovací blankosměnka'
  | 'Bez zajištění';

export type SecurityTier = 'PREMIUM' | 'STRONG' | 'MODERATE' | 'BASIC' | 'NONE';

export interface SecurityScore {
  score: number; // 0-100
  tier: SecurityTier;
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
  description: string;
}

/**
 * Security scoring weights based on legal enforceability and investor protection
 */
const SECURITY_SCORES: Record<SecurityType, number> = {
  // TIER 1 - PREMIUM (95-100)
  'Zástava 1. pořadí': 100,
  'Notářský zápis s přímou vykonatelností': 98,
  'Převedení vlastnictví se zpětným odkupem': 95,

  // TIER 2 - STRONG (75-94)
  'Zástava 2. pořadí': 85,
  'Notářský zápis': 80,
  'Postoupení pohledávek': 78,

  // TIER 3 - MODERATE (50-74)
  'Zajištění nájmů': 68,
  'Zástava k OP, KL, Akcie': 65,
  'Zástava movitých věcí': 55,
  'Ručitelský závazek': 52,

  // TIER 4 - BASIC (25-49)
  'Firemní směnka': 45,
  'Zajišťovací blankosměnka': 42,
  'Osobní směnka': 30,

  // TIER 5 - NONE (0)
  'Bez zajištění': 0,
};

/**
 * Determine security tier based on score
 */
function getSecurityTier(score: number): SecurityTier {
  if (score >= 95) return 'PREMIUM';
  if (score >= 75) return 'STRONG';
  if (score >= 50) return 'MODERATE';
  if (score >= 25) return 'BASIC';
  return 'NONE';
}

/**
 * Get security tier labels
 */
const TIER_LABELS: Record<SecurityTier, string> = {
  PREMIUM: 'Premium zajištění',
  STRONG: 'Silné zajištění',
  MODERATE: 'Standardní zajištění',
  BASIC: 'Základní zajištění',
  NONE: 'Bez zajištění',
};

/**
 * Get security tier colors (professional, subtle)
 */
const TIER_COLORS: Record<SecurityTier, { color: string; bgColor: string; borderColor: string }> = {
  PREMIUM: {
    color: 'text-[#14AE6B]',
    bgColor: 'bg-[#14AE6B]/10',
    borderColor: 'border-[#14AE6B]/20',
  },
  STRONG: {
    color: 'text-blue-700',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
  },
  MODERATE: {
    color: 'text-gray-700',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-200',
  },
  BASIC: {
    color: 'text-amber-700',
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200',
  },
  NONE: {
    color: 'text-red-700',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
  },
};

/**
 * Get security tier descriptions
 */
const TIER_DESCRIPTIONS: Record<SecurityTier, string> = {
  PREMIUM: 'Nejvyšší úroveň ochrany investora s preferenčním uspokojením',
  STRONG: 'Silná ochrana s exekučně vykonatelnými nástroji',
  MODERATE: 'Standardní ochrana závislá na externích faktorech',
  BASIC: 'Formální zajištění s omezenou vymahatelností',
  NONE: 'Investice bez zajištění - maximální riziko',
};

/**
 * Calculate comprehensive security score
 */
export function calculateSecurityScore(
  securityType: SecurityType,
  ltvPercent?: number
): SecurityScore {
  const baseScore = SECURITY_SCORES[securityType] || 0;
  let adjustedScore = baseScore;

  // LTV adjustment for collateral-based securities
  if (ltvPercent && (
    securityType.includes('Zástava') ||
    securityType.includes('Převedení vlastnictví')
  )) {
    // Reduce score if LTV is too high
    if (ltvPercent > 80) {
      adjustedScore = Math.max(baseScore - 15, 0);
    } else if (ltvPercent > 70) {
      adjustedScore = Math.max(baseScore - 10, 0);
    } else if (ltvPercent > 60) {
      adjustedScore = Math.max(baseScore - 5, 0);
    }
    // Bonus for very low LTV
    if (ltvPercent < 50) {
      adjustedScore = Math.min(baseScore + 2, 100);
    }
  }

  const tier = getSecurityTier(adjustedScore);
  const colors = TIER_COLORS[tier];

  return {
    score: adjustedScore,
    tier,
    label: TIER_LABELS[tier],
    color: colors.color,
    bgColor: colors.bgColor,
    borderColor: colors.borderColor,
    description: TIER_DESCRIPTIONS[tier],
  };
}

/**
 * Get simple security badge for display
 */
export function getSecurityBadge(securityType: SecurityType, ltvPercent?: number) {
  const score = calculateSecurityScore(securityType, ltvPercent);
  return {
    tier: score.tier,
    label: score.label,
    color: score.color,
    bgColor: score.bgColor,
    borderColor: score.borderColor,
  };
}

/**
 * Compare two securities (for sorting)
 */
export function compareSecurities(
  a: { securityType: SecurityType; ltvPercent?: number },
  b: { securityType: SecurityType; ltvPercent?: number }
): number {
  const scoreA = calculateSecurityScore(a.securityType, a.ltvPercent).score;
  const scoreB = calculateSecurityScore(b.securityType, b.ltvPercent).score;
  return scoreB - scoreA; // Higher score first
}
