/**
 * TICKET HELPERS UTILITY
 * Business logic for ticket operations
 * Genius pattern: Separation of business logic from UI components
 */

import { Ticket, Reservation } from '../types/project';

/**
 * Get availability status for a ticket
 */
export function getTicketAvailability(ticket: Ticket, currentUserId?: string) {
  const activeReservations = ticket.reservations?.filter(r => r.state === 'active').length || 0;
  const MAX_RESERVATIONS = 3;
  const availableSlots = MAX_RESERVATIONS - activeReservations;
  
  if (availableSlots === 0) {
    return { 
      text: 'Plné', 
      color: 'text-red-600',
      isAvailable: false,
      availableSlots: 0
    };
  }
  
  if (availableSlots === 1) {
    return { 
      text: 'Poslední!', 
      color: 'text-orange-600',
      isAvailable: true,
      availableSlots: 1
    };
  }
  
  return { 
    text: `${availableSlots} volné`, 
    color: 'text-[#14AE6B]',
    isAvailable: true,
    availableSlots
  };
}

/**
 * Get global activity for a ticket (all traders)
 */
export function getGlobalTicketActivity(ticket: Ticket, currentUserId?: string) {
  const activeReservations = ticket.reservations?.filter(r => r.state === 'active').length || 0;
  const pendingSlotsOthers = ticket.slots?.filter(s => 
    s.state === 'Reserved' && s.reservedBy !== currentUserId
  ).length || 0;
  
  return { 
    activeReservations, 
    pendingSlotsOthers 
  };
}

/**
 * Get user's activity for a ticket
 */
export function getUserTicketActivity(ticket: Ticket, currentUserId: string) {
  const myActiveReservations = ticket.reservations?.filter(r => 
    r.state === 'active' && r.investorId === currentUserId
  ).length || 0;
  
  const myPendingSlots = ticket.slots?.filter(s => 
    s.state === 'Reserved' && s.reservedBy === currentUserId
  ).length || 0;
  
  return { 
    myActiveReservations, 
    myPendingSlots 
  };
}

/**
 * Calculate available slots (total - occupied)
 */
export function getAvailableSlots(ticket: Ticket): number {
  return ticket.occupancy.total - ticket.occupancy.current;
}

/**
 * Get recommended investors count
 */
export function getMatchCount(ticket: Ticket): number {
  return ticket.recommendedInvestors?.length || 0;
}

/**
 * Calculate commission amount for a ticket
 */
export function calculateCommission(ticket: Ticket): number {
  return (ticket.investmentAmount * ticket.commission) / 100;
}

/**
 * Check if ticket can be reserved
 */
export function canReserveTicket(ticket: Ticket, currentUserId?: string): boolean {
  const availability = getTicketAvailability(ticket, currentUserId);
  return availability.isAvailable && getAvailableSlots(ticket) > 0;
}

/**
 * Get ticket status badge info
 */
export function getTicketStatusBadge(ticket: Ticket) {
  const availableSlots = getAvailableSlots(ticket);
  
  if (availableSlots === 0) {
    return {
      text: 'Vyprodáno',
      bgColor: 'bg-red-100',
      textColor: 'text-red-700',
      borderColor: 'border-red-200',
    };
  }
  
  if (availableSlots <= 2) {
    return {
      text: 'Poslední místa',
      bgColor: 'bg-orange-100',
      textColor: 'text-orange-700',
      borderColor: 'border-orange-200',
    };
  }
  
  return {
    text: 'Dostupné',
    bgColor: 'bg-green-100',
    textColor: 'text-green-700',
    borderColor: 'border-green-200',
  };
}

/**
 * Get yield category (high/medium/low)
 */
export function getYieldCategory(yieldPA: number): 'high' | 'medium' | 'low' {
  if (yieldPA >= 7) return 'high';
  if (yieldPA >= 5) return 'medium';
  return 'low';
}

/**
 * Get LTV risk level
 */
export function getLTVRiskLevel(ltv: number): 'low' | 'medium' | 'high' {
  if (ltv <= 60) return 'low';
  if (ltv <= 75) return 'medium';
  return 'high';
}

/**
 * Calculate estimated return for ticket
 */
export function calculateEstimatedReturn(ticket: Ticket): number {
  const monthlyRate = ticket.yieldPA / 12 / 100;
  const totalReturn = ticket.investmentAmount * monthlyRate * ticket.duration;
  return totalReturn;
}

/**
 * Get ticket priority score (for sorting)
 */
export function getTicketPriorityScore(ticket: Ticket): number {
  let score = 0;
  
  // High yield adds points
  score += ticket.yieldPA * 10;
  
  // Low LTV adds points (safer)
  if (ticket.ltv) {
    score += (100 - ticket.ltv) * 2;
  }
  
  // Secured adds points
  if (ticket.secured) {
    score += 100;
  }
  
  // High commission adds points
  score += ticket.commission * 50;
  
  // Available slots add points
  const available = getAvailableSlots(ticket);
  score += available * 10;
  
  return score;
}
