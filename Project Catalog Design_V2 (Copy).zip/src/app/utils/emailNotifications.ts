/**
 * EMAIL NOTIFICATION UTILITIES
 * 
 * Handles email sending logic for system-triggered notifications
 * In production, this would integrate with email service (SendGrid, AWS SES, etc.)
 */

import { Reservation } from '../types/reservation';
import { 
  EMAIL_SLA_EXPIRED_NO_SIGNATURE_SUBJECT,
  getEmailSLAExpiredNoSignaturePlainText,
  generateEmailMetadata,
  EmailSLAExpiredMetadata,
} from '../components/EmailSLAExpiredNoSignature';

/**
 * Email Service Configuration
 */
interface EmailConfig {
  fromEmail: string;
  fromName: string;
  replyTo: string;
}

const EMAIL_CONFIG: EmailConfig = {
  fromEmail: 'no-reply@tipari.cz',
  fromName: 'Tipari.cz',
  replyTo: 'support@tipari.cz',
};

/**
 * Email Send Result
 */
interface EmailSendResult {
  success: boolean;
  emailId?: string;
  error?: string;
  metadata: EmailSLAExpiredMetadata;
}

/**
 * Send SLA Expired (No Signature) Email to Introducer
 * 
 * Triggered when:
 * - Reservation SLA expires
 * - Investor has NOT signed reservation agreement
 * 
 * @param reservation - The expired reservation
 * @param projectName - Name of the project
 * @param investorName - Name of the investor
 * @param introducerName - Name of the introducer (tipař)
 * @param introducerEmail - Email of the introducer
 */
export async function sendSLAExpiredNoSignatureEmail(
  reservation: Reservation,
  projectName: string,
  investorName: string,
  introducerName: string,
  introducerEmail: string,
): Promise<EmailSendResult> {
  try {
    // Generate email metadata for logging
    const metadata = generateEmailMetadata(reservation);

    // Generate plain text version
    const plainTextContent = getEmailSLAExpiredNoSignaturePlainText({
      reservation,
      projectName,
      investorName,
      introducerName,
    });

    // In production, this would:
    // 1. Render the React email component to HTML string (server-side)
    // 2. Send via email service API (SendGrid, AWS SES, etc.)
    /*
    const htmlContent = renderEmailToHTML(EmailSLAExpiredNoSignature({
      reservation,
      projectName,
      investorName,
      introducerName,
      introducerEmail,
    }));
    
    const response = await sendGridClient.send({
      to: introducerEmail,
      from: {
        email: EMAIL_CONFIG.fromEmail,
        name: EMAIL_CONFIG.fromName,
      },
      replyTo: EMAIL_CONFIG.replyTo,
      subject: EMAIL_SLA_EXPIRED_NO_SIGNATURE_SUBJECT,
      html: htmlContent,
      text: plainTextContent,
      customArgs: {
        emailType: metadata.emailType,
        reservationId: metadata.reservationId,
        introducerId: metadata.introducerId,
      },
    });
    */

    // MOCK: Simulate email sending
    console.log('📧 [EMAIL] Sending SLA Expired (No Signature) notification...');
    console.log('📧 [EMAIL] To:', introducerEmail);
    console.log('📧 [EMAIL] Subject:', EMAIL_SLA_EXPIRED_NO_SIGNATURE_SUBJECT);
    console.log('📧 [EMAIL] Reservation:', reservation.reservationNumber);
    console.log('📧 [EMAIL] Project:', projectName);
    console.log('📧 [EMAIL] Investor:', investorName);
    console.log('📧 [EMAIL] Introducer:', introducerName);
    console.log('📧 [EMAIL] Metadata:', metadata);
    console.log('📧 [EMAIL] Plain Text Preview:');
    console.log('---');
    console.log(plainTextContent);
    console.log('---');

    // Simulate successful send
    const mockEmailId = `email_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    // Log to analytics/database (in production)
    await logEmailNotification({
      emailId: mockEmailId,
      metadata,
      toEmail: introducerEmail,
      sentAt: new Date().toISOString(),
    });

    return {
      success: true,
      emailId: mockEmailId,
      metadata,
    };
  } catch (error) {
    console.error('❌ [EMAIL] Failed to send SLA expired email:', error);
    
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      metadata: generateEmailMetadata(reservation),
    };
  }
}

/**
 * Log email notification to database/analytics
 * In production, this would store in database for audit trail
 */
async function logEmailNotification(data: {
  emailId: string;
  metadata: EmailSLAExpiredMetadata;
  toEmail: string;
  sentAt: string;
}): Promise<void> {
  // MOCK: In production, save to database
  console.log('💾 [DATABASE] Logging email notification:', {
    emailId: data.emailId,
    emailType: data.metadata.emailType,
    reservationNumber: data.metadata.reservationNumber,
    toEmail: data.toEmail,
    sentAt: data.sentAt,
  });
}

/**
 * Batch process expired reservations and send notifications
 * This would typically run as a cron job or scheduled task
 */
export async function processExpiredReservationsNotifications(
  expiredReservations: Reservation[],
  getProjectName: (projectId: string) => string,
  getIntroducerInfo: (introducerId: string) => { name: string; email: string },
): Promise<EmailSendResult[]> {
  const results: EmailSendResult[] = [];

  for (const reservation of expiredReservations) {
    // Only send email for reservations that expired in WAITING_INVESTOR_SIGNATURE phase
    if (reservation.expiredFromPhase !== 'WAITING_INVESTOR_SIGNATURE') {
      continue;
    }

    const projectName = getProjectName(reservation.projectId);
    const investorName = reservation.investorName || 'Investor';
    const introducerInfo = getIntroducerInfo(reservation.introducerId);

    const result = await sendSLAExpiredNoSignatureEmail(
      reservation,
      projectName,
      investorName,
      introducerInfo.name,
      introducerInfo.email,
    );

    results.push(result);

    // Add delay between emails to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  console.log(`📧 [EMAIL] Processed ${results.length} SLA expired email notifications`);
  console.log(`✅ [EMAIL] Successful: ${results.filter(r => r.success).length}`);
  console.log(`❌ [EMAIL] Failed: ${results.filter(r => !r.success).length}`);

  return results;
}