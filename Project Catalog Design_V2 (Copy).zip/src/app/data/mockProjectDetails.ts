/**
 * MOCK PROJECT DETAILS DATA
 * Kompletní data pro detaily projektů
 */

export interface ProjectDetailData {
  projectId: string;
  projectName: string;
  location: string;
  projectImage: string;
  galleryImages: string[];
  
  // Developer
  developerName: string;
  developerLogo?: string;
  developerDescription: string;
  developerProjects: number;
  
  // Project Info
  projectType: string;
  projectStatus: 'Příprava' | 'Výstavba' | 'Kolaudace' | 'Prodej';
  description: string;
  landArea?: number; // m2
  buildingArea?: number; // m2
  units?: number;
  floors?: number;
  
  // Timeline
  startDate: string;
  expectedCompletion: string;
  currentPhase: string;
  
  // Financials
  totalProjectValue: number;
  totalFundingRequired: number;
  fundingSecured: number;
  
  // Documents
  documents: {
    id: string;
    name: string;
    type: 'PDF' | 'Excel' | 'Word' | 'Image';
    size: string;
    uploadDate: string;
    category: 'Právní' | 'Technická' | 'Finanční' | 'Marketing';
  }[];
  
  // Key Features
  keyFeatures: string[];
  
  // Location details
  locationDetails: {
    address: string;
    city: string;
    district: string;
    coordinates?: { lat: number; lng: number };
    publicTransport?: string[];
    nearbyAmenities?: string[];
  };
  
  // Risk Assessment
  riskLevel: 'Nízké' | 'Střední' | 'Vysoké';
  riskFactors: string[];
  
  // Contact
  contactPerson: string;
  contactEmail: string;
  contactPhone: string;
}

export const MOCK_PROJECT_DETAILS: Record<string, ProjectDetailData> = {
  'PRJ-001': {
    projectId: 'PRJ-001',
    projectName: 'Rezidence Viktoria Park',
    location: 'Praha 6',
    projectImage: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1200',
    galleryImages: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800',
    ],
    
    developerName: 'Premium Development Group',
    developerDescription: 'Prémiový developer s 15letou historií úspěšných rezidenčních projektů v Praze. Specializace na luxusní bytové komplexy a rodinné domy v žádaných lokalitách.',
    developerProjects: 23,
    
    projectType: 'Rezidenční',
    projectStatus: 'Výstavba',
    description: 'Exkluzivní rezidenční projekt v klidné části Prahy 6 nabízí 45 moderních bytových jednotek s důrazem na kvalitu a komfort. Projekt kombinuje moderní architekturu s respektem k okolní zástavbě a nabízí nadstandardní vybavení včetně podzemních garáží, fitness centra a dětského hřiště.\n\nRezidence je navržena s ohledem na energetickou účinnost a udržitelnost. Všechny byty budou mít minimálně třídu B energetické náročnosti budovy. Projekt zahrnuje i zelené střechy a retenční nádrže pro hospodaření s dešťovou vodou.',
    landArea: 3500,
    buildingArea: 4200,
    units: 45,
    floors: 5,
    
    startDate: '03/2024',
    expectedCompletion: '09/2026',
    currentPhase: 'Hrubá stavba - 3. nadzemní podlaží',
    
    totalProjectValue: 285000000,
    totalFundingRequired: 120000000,
    fundingSecured: 73000000,
    
    documents: [
      {
        id: 'DOC-001',
        name: 'Stavební povolení',
        type: 'PDF',
        size: '2.4 MB',
        uploadDate: '15.01.2024',
        category: 'Právní',
      },
      {
        id: 'DOC-002',
        name: 'Projektová dokumentace',
        type: 'PDF',
        size: '18.7 MB',
        uploadDate: '10.01.2024',
        category: 'Technická',
      },
      {
        id: 'DOC-003',
        name: 'Finanční model projektu',
        type: 'Excel',
        size: '856 KB',
        uploadDate: '20.01.2024',
        category: 'Finanční',
      },
      {
        id: 'DOC-004',
        name: 'Znalecký posudek',
        type: 'PDF',
        size: '3.1 MB',
        uploadDate: '08.01.2024',
        category: 'Finanční',
      },
      {
        id: 'DOC-005',
        name: 'Marketingové materiály',
        type: 'PDF',
        size: '12.3 MB',
        uploadDate: '25.01.2024',
        category: 'Marketing',
      },
    ],
    
    keyFeatures: [
      '45 bytových jednotek (1+kk až 4+kk)',
      'Podzemní parkoviště s 52 stáními',
      'Soukromé fitness centrum a wellness',
      'Dětské hřiště a relaxační zóna',
      'Recepce a kamerový systém 24/7',
      'Energetická třída B',
      'Zelené střechy a retenční nádrže',
      'Smart home systémy ve všech bytech',
    ],
    
    locationDetails: {
      address: 'Viktoria Park, Budovatelská 2140',
      city: 'Praha',
      district: 'Praha 6 - Dejvice',
      coordinates: { lat: 50.0995, lng: 14.3914 },
      publicTransport: ['Metro A - Dejvická (5 min)', 'Tram 20, 26 (2 min)', 'Bus 131, 143 (3 min)'],
      nearbyAmenities: [
        'Stromovka park (10 min chůze)',
        'Základní škola (5 min)',
        'Obchodní centrum Dejvice (7 min)',
        'Nemocnice Na Homolce (12 min)',
      ],
    },
    
    riskLevel: 'Nízké',
    riskFactors: [
      'Developer s prokázanou historií úspěšných projektů',
      'Výborná lokalita s dlouhodobě vysokou poptávkou',
      'Již zajištěno 61% financování projektu',
      'Prémiové stavební povolení platné do 2027',
    ],
    
    contactPerson: 'Ing. Martin Svoboda',
    contactEmail: 'martin.svoboda@premium-dev.cz',
    contactPhone: '+420 602 123 456',
  },
  
  'PRJ-002': {
    projectId: 'PRJ-002',
    projectName: 'Logistické centrum Průhonice',
    location: 'Praha-západ',
    projectImage: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=1200',
    galleryImages: [
      'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800',
      'https://images.unsplash.com/photo-1553413077-190dd305871c?w=800',
      'https://images.unsplash.com/photo-1587293852726-70cdb56c2866?w=800',
    ],
    
    developerName: 'Industrial Properties CZ',
    developerDescription: 'Přední developer průmyslových a logistických nemovitostí v České republice. Specializace na moderní sklady a distribuční centra pro mezinárodní klienty.',
    developerProjects: 17,
    
    projectType: 'Komerční - Logistika',
    projectStatus: 'Příprava',
    description: 'Moderní logistické centrum na strategické pozici u D1 s vynikající dostupností pro mezinárodní přepravu. Projekt nabízí 15,000 m² skladových prostor kategorie A s možností rozdělení pro více nájemců.\n\nObjekt je navržen dle nejnovějších standardů pro logistické nemovitosti s důrazem na efektivitu provozu a udržitelnost. Součástí projektu je také administrativní budova a sociální zázemí pro zaměstnance.',
    landArea: 22000,
    buildingArea: 15000,
    floors: 2,
    
    startDate: '06/2024',
    expectedCompletion: '12/2025',
    currentPhase: 'Příprava staveniště a základové práce',
    
    totalProjectValue: 420000000,
    totalFundingRequired: 180000000,
    fundingSecured: 95000000,
    
    documents: [
      {
        id: 'DOC-101',
        name: 'Územní rozhodnutí',
        type: 'PDF',
        size: '1.8 MB',
        uploadDate: '12.02.2024',
        category: 'Právní',
      },
      {
        id: 'DOC-102',
        name: 'Studie proveditelnosti',
        type: 'PDF',
        size: '5.2 MB',
        uploadDate: '05.02.2024',
        category: 'Technická',
      },
      {
        id: 'DOC-103',
        name: 'Předběžné nájemní smlouvy',
        type: 'PDF',
        size: '2.1 MB',
        uploadDate: '18.02.2024',
        category: 'Právní',
      },
    ],
    
    keyFeatures: [
      '15,000 m² skladových prostor kategorie A',
      'Světlá výška 10 metrů',
      '40 nakládacích ramp',
      'BREEAM certifikace',
      'Fotovoltaická elektrárna na střeše',
      'Moderní požární zabezpečení',
      'Administrativní zázemí 800 m²',
      '120 parkovacích míst',
    ],
    
    locationDetails: {
      address: 'Průmyslová zóna Průhonice',
      city: 'Průhonice',
      district: 'Praha-západ',
      publicTransport: ['Bus 323, 385 (5 min)'],
      nearbyAmenities: [
        'Sjezd D1 (2 km)',
        'Dálnice D1 směr Brno (3 km)',
        'Praha centrum (18 km)',
      ],
    },
    
    riskLevel: 'Střední',
    riskFactors: [
      'Předběžné závazky od 3 mezinárodních nájemců',
      'Strategická poloha u D1',
      'Vysoká poptávka po logistických prostorech',
      'Závislost na dokončení infrastruktury',
    ],
    
    contactPerson: 'Bc. Jana Nováková',
    contactEmail: 'jana.novakova@industrial-prop.cz',
    contactPhone: '+420 603 987 654',
  },
};
