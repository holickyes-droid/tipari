/**
 * MOCK RESERVATION & SLOT DATA
 * Tipari.cz B2B Investment Referral Platform
 * 
 * Simulates introducer "Jan Novák" with:
 * - 10 total global slots
 * - 4 active reservations (various phases)
 * - 6 free slots available
 */

import { 
  GlobalSlot, 
  SlotAllocation, 
  Reservation, 
  TicketReservationLimit 
} from '../types/reservation';

/**
 * Current Introducer (Demo User)
 */
export const CURRENT_INTRODUCER_ID = 'intro-jan-novak';
export const CURRENT_INTRODUCER_NAME = 'Jan Novák';

/**
 * Global Slots (10 total)
 */
export const mockGlobalSlots: GlobalSlot[] = [
  // FREE SLOTS (6)
  {
    id: 'slot-01',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'FREE',
  },
  {
    id: 'slot-02',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'FREE',
  },
  {
    id: 'slot-03',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'FREE',
  },
  {
    id: 'slot-04',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'FREE',
  },
  {
    id: 'slot-05',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'FREE',
  },
  {
    id: 'slot-06',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'FREE',
  },
  
  // LOCKED_WAITING SLOTS (2)
  {
    id: 'slot-07',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'LOCKED_WAITING',
    reservationId: 'res-001',
  },
  {
    id: 'slot-08',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'LOCKED_WAITING',
    reservationId: 'res-002',
  },
  
  // LOCKED_CONFIRMED SLOTS (2)
  {
    id: 'slot-09',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'LOCKED_CONFIRMED',
    reservationId: 'res-003',
  },
  {
    id: 'slot-10',
    introducerId: CURRENT_INTRODUCER_ID,
    state: 'LOCKED_CONFIRMED',
    reservationId: 'res-004',
  },
];

/**
 * Slot Allocation Summary
 */
export const mockSlotAllocation: SlotAllocation = {
  introducerId: CURRENT_INTRODUCER_ID,
  totalSlots: 10,
  freeSlots: 6,
  lockedWaitingSlots: 2,
  lockedConfirmedSlots: 2,
  releasedSlots: 0,
  usedSlots: 3, // Historical successful deals this month
};

/**
 * Active Reservations (4)
 */
export const mockReservations: Reservation[] = [
  // RES-001: Phase 1 - Waiting for Investor Signature
  {
    id: 'res-001',
    reservationNumber: 'RES-2024-001234',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-07',
    projectId: '1',
    ticketId: 't1-1',
    investorId: '1',
    investorName: 'Petr Novák',
    investorEmail: 'petr.novak@example.com',
    phase: 'WAITING_INVESTOR_SIGNATURE',
    status: 'waiting_investor_signature',
    nextActor: 'INVESTOR',
    createdAt: '2025-01-02T10:30:00Z',
    updatedAt: '2025-01-02T10:30:00Z',
    slaDeadline: '2025-01-04T10:30:00Z',
    estimatedProvision: 25000, // 2% z 1.25M
    auditLog: [
      {
        id: 'audit-res001-001',
        timestamp: '2025-01-02T10:30:00Z',
        eventType: 'reservation_created',
        reason: 'Nová rezervace vytvořena',
        effect: 'Rezervace vytvořena ve fázi WAITING_INVESTOR_SIGNATURE',
        performedBy: CURRENT_INTRODUCER_ID,
      },
      {
        id: 'audit-res001-002',
        timestamp: '2025-01-02T10:30:00Z',
        eventType: 'slot_locked',
        reason: 'Slot uzamčen pro rezervaci',
        effect: 'Slot slot-07 uzamčen jako LOCKED_WAITING',
        performedBy: 'SYSTEM',
      },
    ],
  },
  
  // RES-002: Phase 2 - Waiting for Developer Decision
  {
    id: 'res-002',
    reservationNumber: 'RES-2024-001235',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-08',
    projectId: '2',
    ticketId: 't2-1',
    investorId: '2',
    investorName: 'Jana Nováková',
    investorEmail: 'jana.novakova@example.com',
    phase: 'WAITING_DEVELOPER_DECISION',
    status: 'waiting_developer_decision',
    nextActor: 'DEVELOPER',
    createdAt: '2024-12-28T09:00:00Z',
    updatedAt: '2024-12-29T14:00:00Z',
    investorSignedAt: '2024-12-29T14:00:00Z',
    slaDeadline: '2025-01-01T14:00:00Z',
    estimatedProvision: 18000, // 2% z 900k
  },
  
  // RES-003: Phase 4 - Meeting Confirmed (ACTIVE)
  {
    id: 'res-003',
    reservationNumber: 'RES-2024-001236',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-09',
    projectId: '3',
    ticketId: 't3-1',
    investorId: '3',
    investorName: 'Martin Svoboda',
    investorEmail: 'martin.svoboda@example.com',
    phase: 'MEETING_CONFIRMED',
    status: 'meeting_confirmed',
    nextActor: 'NONE',
    createdAt: '2024-12-20T11:00:00Z',
    updatedAt: '2025-01-02T09:00:00Z',
    investorSignedAt: '2024-12-21T10:00:00Z',
    developerApprovedAt: '2024-12-22T15:00:00Z',
    meetingConfirmedAt: '2025-01-02T09:00:00Z',
    selectedMeetingDate: '2025-01-15T14:00:00Z',
    meetingScheduledDate: '2025-01-15T14:00:00Z',
    meetingLocation: 'Konferenční centrum Praha',
    estimatedProvision: 30000, // 2% z 1.5M
  },
  
  // RES-004: Phase 5 - Meeting Completed
  {
    id: 'res-004',
    reservationNumber: 'RES-2024-001237',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-10',
    projectId: '4',
    ticketId: 't4-1',
    investorId: '4',
    investorName: 'Lucie Černá',
    investorEmail: 'lucie.cerna@example.com',
    phase: 'MEETING_COMPLETED',
    status: 'meeting_completed',
    nextActor: 'ADMIN',
    createdAt: '2024-12-01T08:00:00Z',
    updatedAt: '2024-12-20T16:00:00Z',
    investorSignedAt: '2024-12-02T10:00:00Z',
    developerApprovedAt: '2024-12-03T14:00:00Z',
    meetingConfirmedAt: '2024-12-05T09:00:00Z',
    meetingCompletedAt: '2024-12-20T16:00:00Z',
    selectedMeetingDate: '2024-12-20T15:00:00Z',
    meetingScheduledDate: '2024-12-20T15:00:00Z',
    meetingLocation: 'Developer Office Brno',
    estimatedProvision: 40000, // 2% z 2M
  },
  
  // RES-005: SUCCESS (completed, slot released)
  {
    id: 'res-005',
    reservationNumber: 'RES-2024-001100',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-released-01',
    projectId: '5',
    ticketId: 't5-1',
    investorId: '5',
    investorName: 'Tomáš Novotný',
    investorEmail: 'tomas.novotny@example.com',
    phase: 'SUCCESS',
    status: 'successful',
    nextActor: 'NONE',
    createdAt: '2024-11-10T08:00:00Z',
    updatedAt: '2024-12-15T16:00:00Z',
    investorSignedAt: '2024-11-11T10:00:00Z',
    developerApprovedAt: '2024-11-12T14:00:00Z',
    meetingConfirmedAt: '2024-11-13T09:00:00Z',
    meetingCompletedAt: '2024-11-20T11:00:00Z',
    selectedMeetingDate: '2024-11-20T10:00:00Z',
    meetingScheduledDate: '2024-11-20T10:00:00Z',
    closedAt: '2024-12-15T16:00:00Z',
    estimatedProvision: 35000, // Final commission confirmed
    dealSuccessful: true,
  },
  
  // RES-006: NO_DEAL (completed, slot released)
  {
    id: 'res-006',
    reservationNumber: 'RES-2024-001045',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-released-02',
    projectId: '6',
    ticketId: 't6-1',
    investorId: '6',
    investorName: 'Eva Marková',
    investorEmail: 'eva.markova@example.com',
    phase: 'NO_DEAL',
    status: 'closed_no_deal',
    nextActor: 'NONE',
    createdAt: '2024-10-15T09:00:00Z',
    updatedAt: '2024-11-30T12:00:00Z',
    investorSignedAt: '2024-10-16T11:00:00Z',
    developerApprovedAt: '2024-10-17T15:00:00Z',
    meetingConfirmedAt: '2024-10-18T10:00:00Z',
    meetingCompletedAt: '2024-10-25T14:00:00Z',
    selectedMeetingDate: '2024-10-25T13:00:00Z',
    meetingScheduledDate: '2024-10-25T13:00:00Z',
    closedAt: '2024-11-30T12:00:00Z',
    outcomeNotes: 'Investor rozhodl pro jinou investiční příležitost',
  },
  
  // RES-007: Phase 3 - Waiting Meeting Selection
  {
    id: 'res-007',
    reservationNumber: 'RES-2024-001260',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-11',
    projectId: '7',
    ticketId: 't7-1',
    investorId: '7',
    investorName: 'Pavel Dvořák',
    investorEmail: 'pavel.dvorak@example.com',
    phase: 'WAITING_MEETING_SELECTION',
    status: 'waiting_meeting_selection',
    nextActor: 'INVESTOR',
    createdAt: '2024-12-15T14:00:00Z',
    updatedAt: '2024-12-18T10:00:00Z',
    investorSignedAt: '2024-12-16T09:00:00Z',
    developerApprovedAt: '2024-12-18T10:00:00Z',
    proposedMeetingDates: [
      '2025-01-10T10:00:00Z',
      '2025-01-12T14:00:00Z',
      '2025-01-15T09:00:00Z',
    ],
    slaDeadline: '2025-01-20T10:00:00Z',
    estimatedProvision: 22000, // 2% estimated
  },
  
  // RES-008: EXPIRED - Investor did not sign contract
  {
    id: 'res-008',
    reservationNumber: 'RES-2024-001280',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-released-03',
    projectId: '1',
    ticketId: 't1-2',
    investorId: '8',
    investorName: 'Kateřina Procházková',
    investorEmail: 'katerina.prochazkova@example.com',
    phase: 'EXPIRED',
    status: 'expired',
    nextActor: 'NONE',
    createdAt: '2024-12-28T09:00:00Z',
    updatedAt: '2025-01-02T10:30:00Z',
    slaDeadline: '2025-01-02T10:30:00Z',
    closedAt: '2025-01-02T10:30:00Z',
    expiredFromPhase: 'WAITING_INVESTOR_SIGNATURE', // Track what phase it expired from
    outcomeNotes: 'Investor nepodepsal smlouvu v dané lhůtě - automaticky ukončeno systémem',
    slaViolation: true,
    auditLog: [
      {
        id: 'audit-res008-001',
        timestamp: '2024-12-28T09:00:00Z',
        eventType: 'reservation_created',
        reason: 'New reservation created by introducer',
        effect: 'Reservation created in WAITING_INVESTOR_SIGNATURE phase',
        performedBy: CURRENT_INTRODUCER_ID,
        metadata: {
          initialPhase: 'WAITING_INVESTOR_SIGNATURE',
          slaDeadline: '2025-01-02T10:30:00Z',
        }
      },
      {
        id: 'audit-res008-002',
        timestamp: '2024-12-28T09:00:00Z',
        eventType: 'slot_locked',
        reason: 'Slot locked for new reservation',
        effect: 'Slot slot-released-03 locked as LOCKED_WAITING',
        performedBy: 'SYSTEM',
        metadata: {
          slotId: 'slot-released-03',
          slotState: 'LOCKED_WAITING',
        }
      },
      {
        id: 'audit-res008-003',
        timestamp: '2025-01-02T10:30:00Z',
        eventType: 'reservation_expired',
        reason: 'SLA deadline exceeded - investor did not sign',
        effect: 'Reservation automatically expired and slot released',
        performedBy: 'SYSTEM',
        metadata: {
          expiredFromPhase: 'WAITING_INVESTOR_SIGNATURE',
          slaViolation: true,
        }
      },
      {
        id: 'audit-res008-004',
        timestamp: '2025-01-02T10:30:00Z',
        eventType: 'slot_released',
        reason: 'Reservation expired - slot automatically released',
        effect: 'Slot slot-released-03 released from LOCKED_WAITING to FREE',
        performedBy: 'SYSTEM',
        metadata: {
          slotId: 'slot-released-03',
          previousState: 'LOCKED_WAITING',
          newState: 'FREE',
        }
      }
    ],
  },
  
  // RES-009: URGENT - Investor signature CRITICAL (deadline za 3 hodiny)
  {
    id: 'res-009',
    reservationNumber: 'RES-2025-001290',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-12',
    projectId: '2',
    ticketId: 't2-2',
    investorId: '9',
    investorName: 'Jiří Malý',
    investorEmail: 'jiri.maly@example.com',
    phase: 'WAITING_INVESTOR_SIGNATURE',
    status: 'waiting_investor_signature',
    nextActor: 'INVESTOR',
    createdAt: '2025-01-03T08:00:00Z',
    updatedAt: '2025-01-03T08:00:00Z',
    slaDeadline: '2025-01-05T14:00:00Z', // 3h from "now" (assuming now is ~11:00)
    estimatedProvision: 18000,
  },
  
  // RES-010: FRESH - Investor signature (čerstvě vytvořeno, deadline 48h)
  {
    id: 'res-010',
    reservationNumber: 'RES-2025-001291',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-13',
    projectId: '3',
    ticketId: 't3-2',
    investorId: '10',
    investorName: 'Michaela Horáková',
    investorEmail: 'michaela.horakova@example.com',
    phase: 'WAITING_INVESTOR_SIGNATURE',
    status: 'waiting_investor_signature',
    nextActor: 'INVESTOR',
    createdAt: '2025-01-05T09:00:00Z',
    updatedAt: '2025-01-05T09:00:00Z',
    slaDeadline: '2025-01-07T09:00:00Z', // 48h deadline
    estimatedProvision: 30000,
  },
  
  // RES-011: DEVELOPER DECISION - EXPIRED deadline (urgentní)
  {
    id: 'res-011',
    reservationNumber: 'RES-2025-001292',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-14',
    projectId: '4',
    ticketId: 't4-2',
    investorId: '11',
    investorName: 'Radek Novotný',
    investorEmail: 'radek.novotny@example.com',
    phase: 'WAITING_DEVELOPER_DECISION',
    status: 'waiting_developer_decision',
    nextActor: 'DEVELOPER',
    createdAt: '2024-12-30T10:00:00Z',
    updatedAt: '2024-12-31T11:00:00Z',
    investorSignedAt: '2024-12-31T11:00:00Z',
    slaDeadline: '2025-01-03T11:00:00Z', // Již vypršelo!
    estimatedProvision: 40000,
  },
  
  // RES-012: MEETING SELECTION - URGENT (akce vyžadována ASAP)
  {
    id: 'res-012',
    reservationNumber: 'RES-2025-001293',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-15',
    projectId: '5',
    ticketId: 't5-2',
    investorId: '12',
    investorName: 'Alena Nováková',
    investorEmail: 'alena.novakova@example.com',
    phase: 'WAITING_MEETING_SELECTION',
    status: 'waiting_meeting_selection',
    nextActor: 'INVESTOR',
    createdAt: '2025-01-01T14:00:00Z',
    updatedAt: '2025-01-03T10:00:00Z',
    investorSignedAt: '2025-01-02T09:00:00Z',
    developerApprovedAt: '2025-01-03T10:00:00Z',
    proposedMeetingDates: [
      '2025-01-08T10:00:00Z',
      '2025-01-09T14:00:00Z',
      '2025-01-10T16:00:00Z',
    ],
    slaDeadline: '2025-01-06T10:00:00Z', // Blíží se!
    estimatedProvision: 35000,
  },
  
  // RES-013: MEETING CONFIRMED - Schůzka DNES
  {
    id: 'res-013',
    reservationNumber: 'RES-2025-001294',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-16',
    projectId: '6',
    ticketId: 't6-2',
    investorId: '13',
    investorName: 'Tomáš Veselý',
    investorEmail: 'tomas.vesely@example.com',
    phase: 'MEETING_CONFIRMED',
    status: 'meeting_confirmed',
    nextActor: 'NONE',
    createdAt: '2024-12-28T08:00:00Z',
    updatedAt: '2025-01-02T16:00:00Z',
    investorSignedAt: '2024-12-29T10:00:00Z',
    developerApprovedAt: '2024-12-30T14:00:00Z',
    meetingConfirmedAt: '2025-01-02T16:00:00Z',
    selectedMeetingDate: '2025-01-05T15:00:00Z', // DNES! 
    meetingScheduledDate: '2025-01-05T15:00:00Z',
    meetingLocation: 'Kancelář developera, Praha 2',
    estimatedProvision: 22000,
  },
  
  // RES-014: MEETING CONFIRMED - Schůzka za týden
  {
    id: 'res-014',
    reservationNumber: 'RES-2025-001295',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-17',
    projectId: '7',
    ticketId: 't7-2',
    investorId: '14',
    investorName: 'Petra Kováčová',
    investorEmail: 'petra.kovacova@example.com',
    phase: 'MEETING_CONFIRMED',
    status: 'meeting_confirmed',
    nextActor: 'NONE',
    createdAt: '2024-12-22T09:00:00Z',
    updatedAt: '2025-01-03T11:00:00Z',
    investorSignedAt: '2024-12-23T10:00:00Z',
    developerApprovedAt: '2024-12-24T15:00:00Z',
    meetingConfirmedAt: '2025-01-03T11:00:00Z',
    selectedMeetingDate: '2025-01-12T10:00:00Z',
    meetingScheduledDate: '2025-01-12T10:00:00Z',
    meetingLocation: 'Online - Google Meet',
    estimatedProvision: 28000,
  },
  
  // RES-015: MEETING COMPLETED - Čeká na admin rozhodnutí
  {
    id: 'res-015',
    reservationNumber: 'RES-2025-001296',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-18',
    projectId: '1',
    ticketId: 't1-3',
    investorId: '15',
    investorName: 'David Procházka',
    investorEmail: 'david.prochazka@example.com',
    phase: 'MEETING_COMPLETED',
    status: 'meeting_completed',
    nextActor: 'ADMIN',
    createdAt: '2024-12-10T08:00:00Z',
    updatedAt: '2025-01-03T17:00:00Z',
    investorSignedAt: '2024-12-11T09:00:00Z',
    developerApprovedAt: '2024-12-12T14:00:00Z',
    meetingConfirmedAt: '2024-12-15T10:00:00Z',
    meetingCompletedAt: '2025-01-03T17:00:00Z',
    selectedMeetingDate: '2025-01-03T16:00:00Z',
    meetingScheduledDate: '2025-01-03T16:00:00Z',
    meetingLocation: 'Výstavba projektu - Rezidence Viktoria',
    estimatedProvision: 25000,
  },
  
  // RES-016: HISTORICAL SUCCESS (Released slot) - Fixed ticket ID
  {
    id: 'res-016',
    reservationNumber: 'RES-2024-001150',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-released-04',
    projectId: '2',
    ticketId: 't2-1', // Changed from t2-3 (which doesn't exist) to t2-1
    investorId: '16',
    investorName: 'Lenka Dvořáková',
    investorEmail: 'lenka.dvorakova@example.com',
    phase: 'SUCCESS',
    status: 'successful',
    nextActor: 'NONE',
    createdAt: '2024-10-20T08:00:00Z',
    updatedAt: '2024-12-01T15:00:00Z',
    investorSignedAt: '2024-10-21T10:00:00Z',
    developerApprovedAt: '2024-10-22T14:00:00Z',
    meetingConfirmedAt: '2024-10-25T09:00:00Z',
    meetingCompletedAt: '2024-11-15T14:00:00Z',
    selectedMeetingDate: '2024-11-15T13:00:00Z',
    meetingScheduledDate: '2024-11-15T13:00:00Z',
    closedAt: '2024-12-01T15:00:00Z',
    estimatedProvision: 18000,
    dealSuccessful: true,
  },
  
  // RES-017: NO_DEAL - Investor odmítl po schůzce
  {
    id: 'res-017',
    reservationNumber: 'RES-2024-001080',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-released-05',
    projectId: '3',
    ticketId: 't3-3',
    investorId: '17',
    investorName: 'Karel Svoboda',
    investorEmail: 'karel.svoboda@example.com',
    phase: 'NO_DEAL',
    status: 'closed_no_deal',
    nextActor: 'NONE',
    createdAt: '2024-09-10T09:00:00Z',
    updatedAt: '2024-11-05T16:00:00Z',
    investorSignedAt: '2024-09-11T10:00:00Z',
    developerApprovedAt: '2024-09-12T15:00:00Z',
    meetingConfirmedAt: '2024-09-15T11:00:00Z',
    meetingCompletedAt: '2024-10-05T13:00:00Z',
    selectedMeetingDate: '2024-10-05T12:00:00Z',
    meetingScheduledDate: '2024-10-05T12:00:00Z',
    closedAt: '2024-11-05T16:00:00Z',
    outcomeNotes: 'Investor požadoval jiné podmínky zajištění než developer mohl nabídnout',
  },
  
  // RES-018: EXPIRED - Developer neschválil včas - Fixed ticket ID
  {
    id: 'res-018',
    reservationNumber: 'RES-2024-001285',
    introducerId: CURRENT_INTRODUCER_ID,
    slotId: 'slot-released-06',
    projectId: '4',
    ticketId: 't4-1', // Changed from t4-3 (which doesn't exist) to t4-1
    investorId: '18',
    investorName: 'Barbora Horáková',
    investorEmail: 'barbora.horakova@example.com',
    phase: 'EXPIRED',
    status: 'expired',
    nextActor: 'NONE',
    createdAt: '2024-12-25T10:00:00Z',
    updatedAt: '2025-01-01T09:00:00Z',
    investorSignedAt: '2024-12-26T11:00:00Z',
    slaDeadline: '2025-01-01T09:00:00Z',
    closedAt: '2025-01-01T09:00:00Z',
    expiredFromPhase: 'WAITING_DEVELOPER_DECISION',
    outcomeNotes: 'Developer nepodal rozhodnutí v SLA lhůtě - rezervace automaticky ukončena',
    slaViolation: true,
  },
];

/**
 * Ticket Reservation Limits (3 per ticket max)
 */
export const mockTicketLimits: TicketReservationLimit[] = [
  {
    ticketId: 'TKT-001',
    introducerId: CURRENT_INTRODUCER_ID,
    currentReservations: 1,
    maxReservations: 3,
  },
  {
    ticketId: 'TKT-002',
    introducerId: CURRENT_INTRODUCER_ID,
    currentReservations: 2,
    maxReservations: 3,
  },
];

/**
 * MOCK: Unresponsive Investors (nereagující na smlouvu)
 * Investoři, kteří dlouho nereagují na rezervační smlouvu
 */
export const mockUnresponsiveReservations = [
  {
    id: 'res-001',
    reservationNumber: 'RES-2024-001234',
    investorName: 'Petr Novák',
    investorEmail: 'petr.novak@example.com',
    investorPhone: '+420 603 456 789',
    projectName: 'Rezidence Viktoria Park',
    ticketId: 'TKT-001',
    contractSentAt: '2025-01-03T08:00:00Z', // 38h bez odpovědi (1 den 14h)
    hoursElapsed: 38,
    slaDeadline: '2025-01-04T10:30:00Z',
  },
  {
    id: 'res-008',
    reservationNumber: 'RES-2024-001299',
    investorName: 'Petr Král',
    investorEmail: 'petr.kral@example.com',
    investorPhone: '+420 604 123 456',
    projectName: 'Bytový komplex Libeň',
    ticketId: 'TKT-008',
    contractSentAt: '2025-01-02T14:00:00Z', // 56h bez odpovědi (2 dny 8h) - kritické
    hoursElapsed: 56,
    slaDeadline: '2025-01-04T14:00:00Z',
  },
  {
    id: 'res-009',
    reservationNumber: 'RES-2024-001301',
    investorName: 'Jana Procházková',
    investorEmail: 'jana.prochazkova@example.com',
    investorPhone: '+420 605 987 654',
    projectName: 'Administrativní centrum Smíchov',
    ticketId: 'TKT-012',
    contractSentAt: '2025-01-03T16:00:00Z', // 20h bez odpovědi
    hoursElapsed: 20,
    slaDeadline: '2025-01-05T16:00:00Z',
  },
];

/**
 * MOCK: Duplicate Investor Detections
 * Detekce kdy investor již má rezervaci od jiného obchodníka
 */
export const mockDuplicateDetections = [
  {
    investorId: '1',
    investorName: 'Petr Novák',
    existingReservations: [
      {
        reservationNumber: 'RES-2024-001180',
        tiparName: 'Petra Nováková',
        tiparId: 'tipar-002',
        projectName: 'Rezidence Green Valley',
        ticketId: 'TKT-045',
        sentAt: '2025-01-02T10:00:00Z',
        phase: 'Čeká na podpis investora',
      },
    ],
  },
  {
    investorId: '2',
    investorName: 'Jana Nováková',
    existingReservations: [
      {
        reservationNumber: 'RES-2024-001165',
        tiparName: 'Martin Svoboda',
        tiparId: 'tipar-003',
        projectName: 'Bytový komplex Žižkov',
        ticketId: 'TKT-032',
        sentAt: '2025-01-01T14:30:00Z',
        phase: 'Čeká na rozhodnutí developera',
      },
      {
        reservationNumber: 'RES-2024-001201',
        tiparName: 'Lucie Černá',
        tiparId: 'tipar-004',
        projectName: 'Komerční park Holešovice',
        ticketId: 'TKT-056',
        sentAt: '2024-12-30T09:15:00Z',
        phase: 'Schůzka potvrzena',
      },
    ],
  },
];

/**
 * HELPER FUNCTIONS
 */

/**
 * Get reservations for a specific ticket by current introducer
 */
export function getReservationsByTicket(ticketId: string): Reservation[] {
  return mockReservations.filter(
    r => r.ticketId === ticketId && r.introducerId === CURRENT_INTRODUCER_ID
  );
}

/**
 * Get reservations for a specific project by current introducer
 */
export function getReservationsByProject(projectId: string): Reservation[] {
  return mockReservations.filter(
    r => r.projectId === projectId && r.introducerId === CURRENT_INTRODUCER_ID
  );
}

/**
 * Check if investor has existing reservations with other Tipars
 */
export function checkDuplicateInvestor(investorId: string) {
  return mockDuplicateDetections.find(d => d.investorId === investorId);
}