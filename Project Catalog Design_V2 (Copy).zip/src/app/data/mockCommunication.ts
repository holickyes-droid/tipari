/**
 * MOCK COMMUNICATION DATA
 * Sample communication activities and notes for development
 */

import { CommunicationActivity, InvestorNote } from '../types/communication';

export const mockCommunicationActivities: CommunicationActivity[] = [
  {
    id: 'comm-001',
    reservationId: 'res-001',
    activityType: 'TICKET_OFFERED',
    channel: 'EMAIL',
    title: 'Tiket TKT-001 nabídnut investorovi',
    description: 'Investorovi Petrovi Novákovi byl nabídnut investiční tiket TKT-001 pro projekt Rezidence Viktoria Park.',
    notes: 'Investor projevil zájem o ekvitní investice v Praze 6',
    createdAt: '2025-01-02T09:15:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    emailSubject: 'Nová investiční příležitost - Rezidence Viktoria Park',
  },
  {
    id: 'comm-002',
    reservationId: 'res-001',
    activityType: 'PHONE_CALL',
    channel: 'PHONE',
    title: 'Telefonní konzultace',
    description: 'Proběhla 15minutová konzultace ohledně struktury investice a zajištění.',
    notes: 'Investor se ptal na LTV a formu zajištění. Vysvětlil jsem strukturu ekvitní investice.',
    createdAt: '2025-01-02T14:30:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    phoneNumber: '+420 603 123 456',
  },
  {
    id: 'comm-003',
    reservationId: 'res-001',
    activityType: 'CONTRACT_SENT',
    channel: 'EMAIL',
    title: 'Rezervační smlouva (RA) zaslána',
    description: 'Rezervační smlouva byla zaslána investorovi k podpisu.',
    createdAt: '2025-01-02T15:45:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    documentUrl: '/documents/RA_RES-2024-001234.pdf',
    documentName: 'RA_RES-2024-001234.pdf',
    emailSubject: 'Rezervační smlouva - Rezidence Viktoria Park',
  },
  {
    id: 'comm-004',
    reservationId: 'res-001',
    activityType: 'FOLLOW_UP',
    channel: 'EMAIL',
    title: 'Follow-up k podpisu smlouvy',
    description: 'Připomenutí investorovi ohledně podpisu rezervační smlouvy.',
    notes: 'SLA deadline se blíží, potřeba urgence',
    createdAt: '2025-01-03T10:00:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    emailSubject: 'Připomínka - Podpis rezervační smlouvy',
  },
  {
    id: 'comm-005',
    reservationId: 'res-001',
    activityType: 'CONTRACT_SIGNED',
    channel: 'PLATFORM',
    title: 'Rezervační smlouva podepsána',
    description: 'Investor podepsal rezervační smlouvu elektronicky.',
    createdAt: '2025-01-03T16:20:00Z',
    createdBy: 'investor-001',
    createdByName: 'Petr Novák (Investor)',
  },
  {
    id: 'comm-006',
    reservationId: 'res-001',
    activityType: 'NOTE_ADDED',
    channel: 'PLATFORM',
    title: 'Interní poznámka',
    description: 'Investor je velmi profesionální, rychlá komunikace. Má zkušenosti s developerskými projekty.',
    notes: 'Doporučuji pro budoucí projekty v Praze',
    createdAt: '2025-01-03T16:30:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
  },
  {
    id: 'comm-007',
    reservationId: 'res-002',
    activityType: 'TICKET_OFFERED',
    channel: 'EMAIL',
    title: 'Tiket TKT-002 nabídnut investorovi',
    description: 'Investorovi Janě Novotné byl nabídnut investiční tiket TKT-002.',
    createdAt: '2024-12-28T11:00:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    emailSubject: 'Investiční příležitost - Bytový komplex Libeň',
  },
  {
    id: 'comm-008',
    reservationId: 'res-002',
    activityType: 'EMAIL_SENT',
    channel: 'EMAIL',
    title: 'Zaslány dodatečné dokumenty',
    description: 'Zaslán business plán a finanční model projektu.',
    documentUrl: '/documents/business-plan.pdf',
    documentName: 'Business_Plan_Liben.pdf',
    createdAt: '2024-12-29T09:30:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    emailSubject: 'Dodatečné dokumenty k projektu Libeň',
  },
  {
    id: 'comm-009',
    reservationId: 'res-002',
    activityType: 'MEETING_SCHEDULED',
    channel: 'PLATFORM',
    title: 'Schůzka naplánována',
    description: 'Schůzka s developerem naplánována na 15. ledna 2025 v 14:00.',
    meetingDate: '2025-01-15T14:00:00Z',
    createdAt: '2025-01-02T13:00:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
  },
  // RES-008: SLA Expiration Event
  {
    id: 'comm-010',
    reservationId: 'res-008',
    activityType: 'CONTRACT_SENT',
    channel: 'EMAIL',
    title: 'Rezervační smlouva (RA) zaslána',
    description: 'Rezervační smlouva byla zaslána investorovi k podpisu.',
    createdAt: '2024-12-20T10:00:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    documentUrl: '/documents/RA_RES-2024-001280.pdf',
    documentName: 'RA_RES-2024-001280.pdf',
    emailSubject: 'Rezervační smlouva - Business Center Praha',
  },
  {
    id: 'comm-011',
    reservationId: 'res-008',
    activityType: 'FOLLOW_UP',
    channel: 'EMAIL',
    title: 'Připomínka k podpisu smlouvy',
    description: 'Zaslána připomínka investorovi ohledně podpisu rezervační smlouvy.',
    notes: 'SLA deadline se blíží',
    createdAt: '2024-12-22T14:30:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    emailSubject: 'Připomínka - Podpis rezervační smlouvy',
  },
  {
    id: 'comm-012',
    reservationId: 'res-008',
    activityType: 'SLA_EXPIRED',
    channel: 'PLATFORM',
    title: 'Rezervace ukončena',
    description: 'Investor nepodepsal rezervační smlouvu ve stanovené lhůtě. Rezervace byla automaticky ukončena systémem.',
    notes: 'Trigger: System | SLA expired | Slot released',
    createdAt: '2024-12-24T23:59:59Z',
    createdBy: 'system',
    createdByName: 'Systém Tipari.cz',
  },
];

export const mockInvestorNotes: InvestorNote[] = [
  {
    id: 'note-001',
    investorId: '1',
    reservationId: 'res-001',
    content: 'Investor preferuje projekty v Praze 6 a okolí. Má zkušenosti s ekvitními investicemi do nemovitostí. Velmi profesionální přístup, rychlá komunikace.',
    category: 'PREFERENCE',
    isImportant: true,
    createdAt: '2025-01-02T09:30:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    tags: ['praha-6', 'ekvita', 'profesionální'],
  },
  {
    id: 'note-002',
    investorId: '1',
    content: 'Upřednostňuje LTV do 70%, konzervativní přístup k rizikovosti. Nemá zájem o projekty bez zajištění.',
    category: 'RISK',
    isImportant: true,
    createdAt: '2025-01-02T14:45:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    tags: ['ltv-70', 'konzervativní', 'zajištění'],
  },
  {
    id: 'note-003',
    investorId: '2',
    content: 'Family office s velkým portfoliem. Preferuje větší investiční objemy (10M+). Dlouhodobý investor s rozsáhlými zkušenostmi.',
    category: 'GENERAL',
    isImportant: true,
    createdAt: '2024-12-28T11:15:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    tags: ['family-office', 'velký-objem', 'zkušený'],
  },
  {
    id: 'note-004',
    investorId: '2',
    content: 'Potřebuje detailní due diligence před každým rozhodnutím. Má vlastní tým právníků.',
    category: 'PREFERENCE',
    createdAt: '2024-12-29T10:00:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    tags: ['due-diligence', 'právníci'],
  },
  {
    id: 'note-005',
    investorId: '3',
    content: 'Zavolat příští týden ohledně nového projektu na Vinohradech. Projevil zájem při poslední schůzce.',
    category: 'FOLLOW_UP',
    isImportant: true,
    createdAt: '2025-01-03T16:00:00Z',
    createdBy: 'tipar-001',
    createdByName: 'Jan Novák (Tipar)',
    tags: ['follow-up', 'vinohrady'],
  },
];

/**
 * Helper function to get activities for specific reservation
 */
export function getActivitiesForReservation(reservationId: string): CommunicationActivity[] {
  return mockCommunicationActivities.filter(a => a.reservationId === reservationId);
}

/**
 * Helper function to get notes for specific investor
 */
export function getNotesForInvestor(investorId: string): InvestorNote[] {
  return mockInvestorNotes.filter(n => n.investorId === investorId);
}

/**
 * Helper function to get notes for specific reservation
 */
export function getNotesForReservation(reservationId: string): InvestorNote[] {
  return mockInvestorNotes.filter(n => n.reservationId === reservationId);
}