/**
 * MOCK INVESTOR DATA
 * Tipari.cz B2B Investment Referral Platform
 * 
 * Investors are clients of the introducer (intermediary/banker)
 * Introducer facilitates connections between investors and developers
 */

import type { AvatarType } from '../components/InvestorAvatar';

export type InvestorStatus = 
  | 'ACTIVE'        // Currently has active reservations
  | 'PROSPECT'      // Has reservations in waiting phase
  | 'INACTIVE'      // No active reservations
  | 'DORMANT';      // Historical activity only

export type InvestorType = 
  | 'INDIVIDUAL'    // Fyzická osoba
  | 'LEGAL_ENTITY'; // Právnická osoba

export interface Investor {
  id: string;
  name: string;
  type: InvestorType;
  avatar?: AvatarType;  // Avatar type - auto-assigned if not provided
  gender?: 'male' | 'female';  // For INDIVIDUAL - used for avatar selection
  contactPersonGender?: 'male' | 'female';  // For LEGAL_ENTITY - gender of contact person
  
  // Contact info
  email: string;
  phone: string;
  location: string;  // City/region
  
  // Legal entity specific fields
  companyName?: string;        // For LEGAL_ENTITY - official company name
  ico?: string;                // For LEGAL_ENTITY - IČO (Company ID)
  contactPerson?: string;      // For LEGAL_ENTITY - contact person name
  
  // Status
  status: InvestorStatus;
  
  // Activity metrics
  totalReservations: number;
  activeReservations: number;
  completedDeals: number;
  
  // Investment profile
  preferredAssetTypes?: string[];  // Residential, Commercial, Industrial, etc.
  preferredLocations?: string[];   // Prague, Brno, Ostrava, etc.
  investmentRange?: {
    min: number;  // CZK
    max: number;  // CZK
  };
  expectedYield?: string;  // Expected yield e.g. "8% p.a."
  
  // Extended investment preferences
  investmentForm?: string[];  // Juniorní zápůjčka, Seniorní zápůjčka, etc.
  securityType?: string[];    // Zástava 1. pořadí, Zástava 2. pořadí, etc.
  interestPayment?: string[]; // měsíční, kvartální, pololetní, etc.
  profitShare?: {
    enabled: boolean;
    percentage?: number;  // 0-100
  };
  projectType?: string[];     // Rezidenční, Logistika, Komerční, etc. (same as preferredAssetTypes)
  locationRegions?: string[]; // Kraje
  locationCities?: string[];  // Města
  decisionSpeed?: string;     // okamžitě, do několika dnů, etc.
  investmentFrequency?: string; // jednorázově, opakovaně, příležitostně
  investorContext?: string;   // soukromý investor, rodinný kapitál, etc.
  
  // Relationship
  createdAt: string;        // When added to portfolio
  introducedDate: string;   // Legacy field - same as createdAt
  lastActivity?: string;    // Last reservation or meeting
  
  // Notes
  notes?: string;
}

/**
 * Mock Investors
 * Based on reservation data from mockReservations.ts
 */
export const mockInvestors: Investor[] = [
  {
    id: 'inv-petr-novak',
    name: 'Petr Novák',
    type: 'INDIVIDUAL',
    gender: 'male',
    email: 'petr.novak@email.cz',
    phone: '+420 603 123 456',
    location: 'Praha',
    status: 'INACTIVE',
    totalReservations: 3,
    activeReservations: 0,
    completedDeals: 2,
    preferredAssetTypes: ['Rezidenční', 'Komerční'],
    preferredLocations: ['Praha', 'Brno'],
    investmentRange: {
      min: 3000000,
      max: 10000000,
    },
    expectedYield: '7-9% p.a.',
    investmentForm: ['Juniorní zápůjčka', 'Seniorní zápůjčka'],
    securityType: ['Zástava 1. pořadí', 'Notářský zápis s přímou vykonatelností'],
    interestPayment: ['měsíční', 'kvartální'],
    profitShare: { enabled: false },
    projectType: ['Rezidenční', 'Komerční'],
    locationRegions: ['Hlavní město Praha', 'Jihomoravský kraj'],
    locationCities: ['Praha', 'Brno'],
    decisionSpeed: 'okamžitě',
    investmentFrequency: 'opakovaně',
    investorContext: 'soukromý investor',
    createdAt: '2024-01-15',
    introducedDate: '2024-01-15',
    lastActivity: '2024-12-20',
    notes: 'Preferuje projekty v centru Prahy, rychlé rozhodování',
  },
  {
    id: 'inv-jana-novotna',
    name: 'Jana Novotná',
    type: 'INDIVIDUAL',
    gender: 'female',
    email: 'jana.novotna@email.cz',
    phone: '+420 608 234 567',
    location: 'Brno',
    status: 'ACTIVE',
    totalReservations: 2,
    activeReservations: 1,
    completedDeals: 0,
    preferredAssetTypes: ['Rezidenční', 'Hotel'],
    preferredLocations: ['Ostrava', 'Brno'],
    investmentRange: {
      min: 5000000,
      max: 15000000,
    },
    expectedYield: '6-8% p.a.',
    investmentForm: ['Seniorní zápůjčka'],
    securityType: ['Zástava 1. pořadí', 'Notářský zápis', 'Ručitelský závazek'],
    interestPayment: ['kvartální', 'pololetní'],
    profitShare: { enabled: false },
    projectType: ['Rezidenční', 'Hotel'],
    locationRegions: ['Jihomoravský kraj', 'Moravskoslezský kraj'],
    locationCities: ['Brno', 'Ostrava'],
    decisionSpeed: 'po prostudování podkladů',
    investmentFrequency: 'příležitostně',
    investorContext: 'soukromý investor',
    createdAt: '2024-08-10',
    introducedDate: '2024-08-10',
    lastActivity: '2025-01-15',
    notes: 'Konzervativní investor, důkladná due diligence',
  },
  {
    id: 'inv-martin-kral',
    name: 'Martin Král',
    type: 'INDIVIDUAL',
    gender: 'male',
    email: 'martin.kral@email.cz',
    phone: '+420 777 345 678',
    location: 'Praha',
    status: 'ACTIVE',
    totalReservations: 2,
    activeReservations: 1,
    completedDeals: 0,
    preferredAssetTypes: ['Hotel', 'Komerční'],
    preferredLocations: ['Karlovy Vary', 'Praha'],
    investmentRange: {
      min: 8000000,
      max: 25000000,
    },
    expectedYield: '8-12% p.a.',
    investmentForm: ['Minoritní ekvita', 'Majoritní ekvita', 'Juniorní zápůjčka'],
    securityType: ['Zástava 1. pořadí', 'Zástava k OP, KL, Akcie', 'Firemní směnka'],
    interestPayment: ['měsíční', 'kvartální', 'na konci období'],
    profitShare: { enabled: true, percentage: 20 },
    projectType: ['Hotel', 'Komerční', 'Retail'],
    locationRegions: ['Hlavní město Praha', 'Karlovarský kraj', 'Plzeňský kraj'],
    locationCities: ['Praha', 'Karlovy Vary', 'Plzeň'],
    decisionSpeed: 'do několika dnů',
    investmentFrequency: 'opakovaně',
    investorContext: 'soukromý investor',
    createdAt: '2024-09-05',
    introducedDate: '2024-09-05',
    lastActivity: '2025-01-14',
    notes: 'Zaměření na prémiové projekty, hotelnictví',
  },
  {
    id: 'inv-marie-svobodova',
    name: 'Marie Svobodová',
    type: 'INDIVIDUAL',
    gender: 'female',
    email: 'marie.svobodova@email.cz',
    phone: '+420 724 456 789',
    location: 'Brno',
    status: 'INACTIVE',
    totalReservations: 2,
    activeReservations: 0,
    completedDeals: 1,
    preferredAssetTypes: ['Logistika'],
    preferredLocations: ['Brno', 'Ostrava'],
    investmentRange: {
      min: 10000000,
      max: 30000000,
    },
    expectedYield: '9-11% p.a.',
    investmentForm: ['Seniorní zápůjčka', 'Minoritní ekvita', 'Mezaninové financování'],
    securityType: ['Zástava 1. pořadí', 'Zástava 2. pořadí', 'Ručitelský závazek', 'Postoupení pohledávek'],
    interestPayment: ['kvartální', 'pololetní'],
    profitShare: { enabled: true, percentage: 15 },
    projectType: ['Logistika', 'Komerční'],
    locationRegions: ['Jihomoravský kraj', 'Moravskoslezský kraj', 'Zlínský kraj'],
    locationCities: ['Brno', 'Ostrava', 'Zlín'],
    decisionSpeed: 'po prostudování podkladů',
    investmentFrequency: 'opakovaně',
    investorContext: 'rodinný kapitál',
    createdAt: '2024-03-20',
    introducedDate: '2024-03-20',
    lastActivity: '2024-11-15',
    notes: 'Zkušený investor s rodinným kapitálem, zaměření na logistiku. Preferuje dlouhodobé projekty s možností podílu na zisku. Portfolio diverzifikace napříč Moravou.',
  },
  {
    id: 'inv-jan-dvorak',
    name: 'Jan Dvořák',
    type: 'LEGAL_ENTITY',
    contactPersonGender: 'male',
    companyName: 'Invest Holding s.r.o.',
    ico: '12345678',
    contactPerson: 'Jan Dvořák',
    email: 'dvorak@investholding.cz',
    phone: '+420 731 567 890',
    location: 'Praha',
    status: 'INACTIVE',
    totalReservations: 1,
    activeReservations: 0,
    completedDeals: 1,
    preferredAssetTypes: ['Komerční'],
    preferredLocations: ['Praha'],
    investmentRange: {
      min: 15000000,
      max: 50000000,
    },
    expectedYield: '7-10% p.a.',
    investmentForm: ['Seniorní zápůjčka', 'Majoritní ekvita', 'Prodej projektu'],
    securityType: ['Zástava 1. pořadí', 'Notářský zápis s přímou vykonatelností', 'Zajišťovací blankosměnka'],
    interestPayment: ['měsíční', 'na konci období'],
    profitShare: { enabled: false },
    projectType: ['Komerční', 'Retail', 'Smíšený'],
    locationRegions: ['Hlavní město Praha', 'Středočeský kraj'],
    locationCities: ['Praha'],
    decisionSpeed: 'okamžitě',
    investmentFrequency: 'jednorázově',
    investorContext: 'firma / holding',
    createdAt: '2024-02-10',
    introducedDate: '2024-02-10',
    lastActivity: '2024-10-08',
    notes: 'Invest Holding s.r.o. - profesionální holding zaměřený na komerční nemovitosti v Praze. Velmi rychlé rozhodování, preferuje senior pozice s maximálním zajištěním. Hledá hlavně větší projekty nad 15M.',
  },
  {
    id: 'inv-anna-kralova',
    name: 'Anna Králová',
    type: 'INDIVIDUAL',
    gender: 'female',
    email: 'anna.kralova@email.cz',
    phone: '+420 605 678 901',
    location: 'Brno',
    status: 'PROSPECT',
    totalReservations: 1,
    activeReservations: 0,
    completedDeals: 0,
    preferredAssetTypes: ['Rezidenční'],
    preferredLocations: ['Brno'],
    investmentRange: {
      min: 4000000,
      max: 12000000,
    },
    expectedYield: '6-8% p.a.',
    investmentForm: ['Seniorní zápůjčka', 'Juniorní zápůjčka'],
    securityType: ['Zástava 1. pořadí', 'Notářský zápis'],
    interestPayment: ['měsíční'],
    profitShare: { enabled: false },
    projectType: ['Rezidenční'],
    locationRegions: ['Jihomoravský kraj'],
    locationCities: ['Brno'],
    decisionSpeed: 'po prostudování podkladů',
    investmentFrequency: 'příležitostně',
    investorContext: 'soukromý investor',
    createdAt: '2024-07-15',
    introducedDate: '2024-07-15',
    lastActivity: '2024-09-20',
    notes: 'Nebyla dosažena dohoda po schůzce, hledá jiné příležitosti',
  },
  {
    id: 'inv-tomas-novotny',
    name: 'Tomáš Novotný',
    type: 'INDIVIDUAL',
    gender: 'male',
    email: 'tomas.novotny@email.cz',
    phone: '+420 776 789 012',
    location: 'Praha',
    status: 'PROSPECT',
    totalReservations: 1,
    activeReservations: 0,
    completedDeals: 0,
    preferredAssetTypes: ['Rezidenční', 'Komerční'],
    preferredLocations: ['Praha', 'Brno'],
    investmentRange: {
      min: 6000000,
      max: 20000000,
    },
    expectedYield: '8-10% p.a.',
    investmentForm: ['Seniorní zápůjčka', 'Minoritní ekvita'],
    securityType: ['Zástava 1. pořadí', 'Ručitelský závazek', 'Notářský zápis s přímou vykonatelností'],
    interestPayment: ['kvartální', 'pololetní'],
    profitShare: { enabled: true, percentage: 10 },
    projectType: ['Rezidenční', 'Komerční'],
    locationRegions: ['Hlavní město Praha', 'Jihomoravský kraj', 'Středočeský kraj'],
    locationCities: ['Praha', 'Brno'],
    decisionSpeed: 'do několika dnů',
    investmentFrequency: 'opakovaně',
    investorContext: 'soukromý investor',
    createdAt: '2024-11-01',
    introducedDate: '2024-11-01',
    lastActivity: '2025-01-10',
    notes: 'Čeká na rozhodnutí developera',
  },
  {
    id: 'inv-eva-novakova',
    name: 'Eva Nováková',
    type: 'INDIVIDUAL',
    gender: 'female',
    email: 'eva.novakova@email.cz',
    phone: '+420 602 890 123',
    location: 'Praha',
    status: 'DORMANT',
    totalReservations: 0,
    activeReservations: 0,
    completedDeals: 0,
    preferredAssetTypes: ['Rezidenční'],
    preferredLocations: ['Praha'],
    investmentRange: {
      min: 5000000,
      max: 15000000,
    },
    expectedYield: '7-9% p.a.',
    investmentForm: ['Seniorní zápůjčka'],
    securityType: ['Zástava 1. pořadí', 'Notářský zápis s přímou vykonatelností'],
    interestPayment: ['kvartální', 'pololetní'],
    profitShare: { enabled: false },
    projectType: ['Rezidenční'],
    locationRegions: ['Hlavní město Praha'],
    locationCities: ['Praha'],
    decisionSpeed: 'individuálně',
    investmentFrequency: 'příležitostně',
    investorContext: 'soukromý investor',
    createdAt: '2024-04-10',
    introducedDate: '2024-04-10',
    notes: 'Zatím žádná aktivita, sleduje trh',
  },
];

// Helper to generate investor initials
export function getInvestorInitials(investor: Investor): string {
  if (investor.type === 'LEGAL_ENTITY' && investor.companyName) {
    // For legal entities, use company name initials
    const words = investor.companyName.split(' ');
    if (words.length >= 2) {
      return (words[0][0] + words[1][0]).toUpperCase();
    }
    return investor.companyName.substring(0, 2).toUpperCase();
  }
  
  // For individuals, use name initials
  const names = investor.name.split(' ');
  if (names.length >= 2) {
    return (names[0][0] + names[1][0]).toUpperCase();
  }
  return investor.name.substring(0, 2).toUpperCase();
}

// Add initials, type display, and other computed properties to investors
export const mockInvestorsEnriched = mockInvestors.map(inv => ({
  ...inv,
  initials: getInvestorInitials(inv),
  typeDisplay: inv.type === 'LEGAL_ENTITY' ? 'Právnická osoba' : 'Fyzická osoba',
  preferredAmount: inv.investmentRange ? (inv.investmentRange.min + inv.investmentRange.max) / 2 : 0,
  preferredYield: inv.expectedYield || '0% p.a.',
  portfolioValue: inv.investmentRange ? inv.investmentRange.max * 1.5 : 0, // Simulated
  isActive: inv.status === 'ACTIVE' || inv.status === 'PROSPECT',
}));

/**
 * Helper: Get investors by status
 */
export function getInvestorsByStatus(status: InvestorStatus): Investor[] {
  return mockInvestors.filter(inv => inv.status === status);
}

/**
 * Helper: Calculate investor summary
 */
export function calculateInvestorSummary() {
  const total = mockInvestors.length;
  const active = mockInvestors.filter(inv => inv.status === 'ACTIVE').length;
  const prospect = mockInvestors.filter(inv => inv.status === 'PROSPECT').length;
  const inactive = mockInvestors.filter(inv => inv.status === 'INACTIVE').length;
  const dormant = mockInvestors.filter(inv => inv.status === 'DORMANT').length;
  
  const totalReservations = mockInvestors.reduce((sum, inv) => sum + inv.totalReservations, 0);
  const totalDeals = mockInvestors.reduce((sum, inv) => sum + inv.completedDeals, 0);
  const conversionRate = totalReservations > 0 ? Math.round((totalDeals / totalReservations) * 100) : 0;
  
  return {
    total,
    active,
    prospect,
    inactive,
    dormant,
    totalReservations,
    totalDeals,
    conversionRate,
  };
}