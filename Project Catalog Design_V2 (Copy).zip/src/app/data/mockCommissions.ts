/**
 * MOCK COMMISSION DATA
 * Tipari.cz B2B Investment Referral Platform
 * 
 * Commission structure:
 * - Earned when reservation reaches SUCCESS phase (Phase 6A)
 * - Tied to successful investor-developer introductions
 * - Commission status follows reservation lifecycle
 */

export type CommissionStatus = 
  | 'EXPECTED'      // Reservation in progress (phases 1-5)
  | 'EARNED'        // Reservation SUCCESS
  | 'LOST'          // Reservation NO_DEAL or EXPIRED
  | 'PENDING_PAYMENT' // Earned but not yet paid
  | 'PAID';         // Commission paid out

export interface Commission {
  id: string;
  reservationId: string;
  reservationNumber: string;
  introducerId: string;
  projectId: string;
  projectName: string;
  ticketId: string;
  investorId: string;
  
  // Commission details
  status: CommissionStatus;
  amount: number; // CZK
  currency: 'CZK';
  commissionRate: number; // Percentage (e.g., 2.5%)
  investmentAmount?: number; // Total investment amount (if known)
  
  // Dates
  expectedDate?: string; // When we expect SUCCESS
  earnedDate?: string; // When reservation reached SUCCESS
  paidDate?: string; // When commission was paid
  
  // Payment details
  invoiceNumber?: string;
  paymentReference?: string;
  
  // Metadata
  notes?: string;
}

/**
 * Mock Commissions
 * Based on mockReservations from mockReservations.ts
 */
export const mockCommissions: Commission[] = [
  // EXPECTED - Active reservation (res-003: MEETING_CONFIRMED)
  {
    id: 'comm-001',
    reservationId: 'res-003',
    reservationNumber: 'RES-2024-001189',
    introducerId: 'intro-jan-novak',
    projectId: '5',
    projectName: 'Bytový dům Ostrava Centrum',
    ticketId: 'T2',
    investorId: 'inv-jana-novotna',
    status: 'EXPECTED',
    amount: 125000,
    currency: 'CZK',
    commissionRate: 2.5,
    investmentAmount: 5000000,
    expectedDate: '2025-02-15',
  },
  
  // EXPECTED - Active reservation (res-004: MEETING_COMPLETED)
  {
    id: 'comm-002',
    reservationId: 'res-004',
    reservationNumber: 'RES-2024-001156',
    introducerId: 'intro-jan-novak',
    projectId: '7',
    projectName: 'Hotel Karlovy Vary',
    ticketId: 'T1',
    investorId: 'inv-martin-kral',
    status: 'EXPECTED',
    amount: 200000,
    currency: 'CZK',
    commissionRate: 2.0,
    investmentAmount: 10000000,
    expectedDate: '2025-02-01',
  },
  
  // EARNED - Historical success (mock)
  {
    id: 'comm-003',
    reservationId: 'res-hist-001',
    reservationNumber: 'RES-2024-000987',
    introducerId: 'intro-jan-novak',
    projectId: '1',
    projectName: 'Rezidenční komplex Praha 9',
    ticketId: 'T3',
    investorId: 'inv-petr-novak',
    status: 'PENDING_PAYMENT',
    amount: 180000,
    currency: 'CZK',
    commissionRate: 3.0,
    investmentAmount: 6000000,
    earnedDate: '2024-12-20',
    invoiceNumber: 'INV-2024-0145',
  },
  
  // PAID - Historical success (mock)
  {
    id: 'comm-004',
    reservationId: 'res-hist-002',
    reservationNumber: 'RES-2024-000823',
    introducerId: 'intro-jan-novak',
    projectId: '4',
    projectName: 'Logistický park Brno-sever',
    ticketId: 'T2',
    investorId: 'inv-marie-svobodova',
    status: 'PAID',
    amount: 250000,
    currency: 'CZK',
    commissionRate: 2.5,
    investmentAmount: 10000000,
    earnedDate: '2024-11-15',
    paidDate: '2024-12-01',
    invoiceNumber: 'INV-2024-0132',
    paymentReference: 'PAY-2024-0098',
  },
  
  // PAID - Historical success (mock)
  {
    id: 'comm-005',
    reservationId: 'res-hist-003',
    reservationNumber: 'RES-2024-000756',
    introducerId: 'intro-jan-novak',
    projectId: '2',
    projectName: 'Kancelářský komplex Prague City',
    ticketId: 'T1',
    investorId: 'inv-jan-dvorak',
    status: 'PAID',
    amount: 300000,
    currency: 'CZK',
    commissionRate: 3.0,
    investmentAmount: 10000000,
    earnedDate: '2024-10-08',
    paidDate: '2024-10-30',
    invoiceNumber: 'INV-2024-0119',
    paymentReference: 'PAY-2024-0087',
  },
  
  // LOST - Historical no deal (mock)
  {
    id: 'comm-006',
    reservationId: 'res-hist-004',
    reservationNumber: 'RES-2024-000654',
    introducerId: 'intro-jan-novak',
    projectId: '3',
    projectName: 'Residential Tower Brno',
    ticketId: 'T1',
    investorId: 'inv-anna-kralova',
    status: 'LOST',
    amount: 0,
    currency: 'CZK',
    commissionRate: 2.5,
    notes: 'Investor withdrew after meeting',
  },
];

/**
 * Helper: Get commissions by project
 */
export function getCommissionsByProject(projectId: string): Commission[] {
  return mockCommissions.filter(c => c.projectId === projectId);
}

/**
 * Helper: Get commissions by status
 */
export function getCommissionsByStatus(status: CommissionStatus): Commission[] {
  return mockCommissions.filter(c => c.status === status);
}

/**
 * Helper: Calculate total commission amounts
 */
export function calculateCommissionSummary() {
  const expected = mockCommissions
    .filter(c => c.status === 'EXPECTED')
    .reduce((sum, c) => sum + c.amount, 0);
  
  const earned = mockCommissions
    .filter(c => c.status === 'EARNED' || c.status === 'PENDING_PAYMENT')
    .reduce((sum, c) => sum + c.amount, 0);
  
  const paid = mockCommissions
    .filter(c => c.status === 'PAID')
    .reduce((sum, c) => sum + c.amount, 0);
  
  const total = expected + earned + paid;
  
  return {
    expected,
    earned,
    paid,
    total,
  };
}
