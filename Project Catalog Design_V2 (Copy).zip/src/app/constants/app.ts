/**
 * APPLICATION CONSTANTS
 * Centralized configuration and constants
 * Genius pattern: Single source of truth, easy maintenance
 */

// Brand Colors
export const BRAND_COLORS = {
  primary: '#215EF8',
  primaryHover: '#1a4bc7',
  primaryLight: '#215EF8/10',
  success: '#14AE6B',
  successHover: '#0D7A4A',
  successLight: '#14AE6B/10',
  dark: '#040F2A',
  border: '#EAEAEA',
  mutedText: '#6B7280',
} as const;

// Reservation Settings
export const RESERVATION_SETTINGS = {
  MAX_RESERVATIONS_PER_TICKET: 3,
  RESERVATION_EXPIRY_HOURS: 48,
  ELECTRONIC_SIGNATURE_DELAY_MS: 3000,
  UPLOAD_DEADLINE_HOURS: 24,
} as const;

// Slot Settings (based on Tipar levels)
export const SLOT_SETTINGS = {
  ASSOCIATE: 3,
  PROFESSIONAL: 6,
  ELITE: 10,
} as const;

// File Upload Settings
export const UPLOAD_SETTINGS = {
  MAX_FILE_SIZE_MB: 10,
  ALLOWED_DOCUMENT_TYPES: ['PDF', 'DOCX', 'XLSX', 'ZIP'] as const,
  ALLOWED_MIME_TYPES: [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/zip',
  ] as const,
} as const;

// Pagination Settings
export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 20,
  PAGE_SIZE_OPTIONS: [10, 20, 50, 100] as const,
} as const;

// Toast Notification Durations
export const TOAST_DURATION = {
  SHORT: 2000,
  MEDIUM: 4000,
  LONG: 6000,
} as const;

// Date Format Patterns
export const DATE_FORMATS = {
  DISPLAY: 'DD.MM.YYYY',
  DISPLAY_WITH_TIME: 'DD.MM.YYYY HH:mm',
  ISO: 'YYYY-MM-DD',
} as const;

// API Endpoints (for future implementation)
export const API_ENDPOINTS = {
  PROJECTS: '/api/projects',
  TICKETS: '/api/tickets',
  RESERVATIONS: '/api/reservations',
  INVESTORS: '/api/investors',
  AUTH: '/api/auth',
  DOCUMENTS: '/api/documents',
} as const;

// Local Storage Keys
export const STORAGE_KEYS = {
  USER_PREFERENCES: 'tipari_user_preferences',
  DRAFT_RESERVATIONS: 'tipari_draft_reservations',
  FILTERS: 'tipari_filters',
  VIEWED_PROJECTS: 'tipari_viewed_projects',
} as const;

// Animation Durations (ms)
export const ANIMATION_DURATION = {
  FAST: 150,
  NORMAL: 300,
  SLOW: 500,
} as const;

// Breakpoints (matches Tailwind)
export const BREAKPOINTS = {
  SM: 640,
  MD: 768,
  LG: 1024,
  XL: 1280,
  '2XL': 1536,
} as const;

// Yield Thresholds
export const YIELD_THRESHOLDS = {
  HIGH: 7,
  MEDIUM: 5,
  LOW: 0,
} as const;

// LTV Thresholds
export const LTV_THRESHOLDS = {
  SAFE: 60,
  MODERATE: 75,
  RISKY: 100,
} as const;

// Commission Range
export const COMMISSION_RANGE = {
  MIN: 0,
  MAX: 10,
  DEFAULT: 2,
} as const;

// Table Column Widths (for TicketsPage)
export const TICKET_TABLE_COLUMNS = {
  IMAGE: 50,
  NAME: 140,
  INVESTMENT: 130,
  LTV: 75,
  MATCHES: 60,
  ACTIVE_RESERVATIONS: 70,
  SLOTS_OTHERS: 75,
  COMMISSION: 115,
  ACTIONS: 185,
} as const;

// Validation Rules
export const VALIDATION = {
  MIN_INVESTMENT_AMOUNT: 100000,
  MAX_INVESTMENT_AMOUNT: 100000000,
  MIN_PROJECT_NAME_LENGTH: 3,
  MAX_PROJECT_NAME_LENGTH: 100,
  MIN_INVESTOR_NAME_LENGTH: 2,
  MAX_INVESTOR_NAME_LENGTH: 100,
  EMAIL_REGEX: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  PHONE_REGEX: /^(\+420)?[0-9]{9}$/,
} as const;

// Feature Flags (for gradual rollout)
export const FEATURES = {
  ENABLE_ELECTRONIC_SIGNATURE: true,
  ENABLE_PHYSICAL_SIGNATURE: true,
  ENABLE_DRAFT_RESERVATIONS: true,
  ENABLE_ADVANCED_FILTERS: true,
  ENABLE_PROJECT_RECOMMENDATIONS: true,
  ENABLE_INVESTOR_MATCHING: true,
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  GENERIC: 'Něco se pokazilo. Zkuste to prosím znovu.',
  NETWORK: 'Chyba připojení. Zkontrolujte internetové připojení.',
  UNAUTHORIZED: 'Nemáte oprávnění pro tuto akci.',
  NOT_FOUND: 'Požadovaný zdroj nebyl nalezen.',
  VALIDATION: 'Zkontrolujte prosím vyplněné údaje.',
  FILE_TOO_LARGE: 'Soubor je příliš velký.',
  INVALID_FILE_TYPE: 'Nepodporovaný formát souboru.',
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  RESERVATION_CREATED: 'Rezervace byla úspěšně vytvořena.',
  RESERVATION_UPDATED: 'Rezervace byla úspěšně aktualizována.',
  RESERVATION_CANCELLED: 'Rezervace byla zrušena.',
  DRAFT_SAVED: 'Rezervace byla uložena.',
  INVESTOR_ADDED: 'Investor byl úspěšně přidán.',
  DOCUMENT_UPLOADED: 'Dokument byl úspěšně nahrán.',
  CONTRACT_SENT: 'Smlouva byla odeslána.',
} as const;
