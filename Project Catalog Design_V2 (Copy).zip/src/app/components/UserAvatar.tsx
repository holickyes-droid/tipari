import { Bell, User, Settings, LogOut, HelpCircle, Upload } from 'lucide-react';
import { useState } from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { NotificationPanel } from './NotificationPanel';
import { FAQModal } from './FAQModal';
import { useNotifications } from '../contexts/NotificationContext';

interface UserAvatarProps {
  userName: string;
  userLevel: string;
  remainingSlots: number;
  unreadNotifications?: number; // Made optional since we're using context
  onNewProject?: () => void;
  totalSlots?: number;
}

export function UserAvatar({
  userName,
  userLevel,
  remainingSlots,
  onNewProject,
  totalSlots,
}: UserAvatarProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showFAQ, setShowFAQ] = useState(false);
  const { unreadCount } = useNotifications();

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getLevelDescription = (level: string) => {
    const descriptions: Record<string, string> = {
      'Junior': 'Do 5 rezervací měsíčně',
      'Senior': 'Do 15 rezervací měsíčně',
      'Partner': 'Neomezený počet rezervací',
    };
    return descriptions[level] || '';
  };

  return (
    <div className="flex items-center gap-4">
      {/* Notifications */}
      <div className="relative">
        <button
          onClick={() => setShowNotifications(!showNotifications)}
          className="relative p-2 hover:bg-gray-50 rounded-lg transition-colors"
        >
          <Bell className="w-5 h-5 text-gray-600" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 w-4 h-4 bg-[#215EF8] rounded-full flex items-center justify-center text-[10px] text-white font-semibold">
              {unreadCount}
            </span>
          )}
        </button>

        <NotificationPanel
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)}
        />
      </div>

      {/* User Menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-3 hover:bg-muted px-3 py-2 rounded-lg transition-colors">
            <div className="w-9 h-9 rounded-full bg-[#215EF8] flex items-center justify-center">
              <span className="text-sm text-white font-medium">{getInitials(userName)}</span>
            </div>
            <span className="text-base text-[#040F2A]">{userName}</span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel>
            <div className="space-y-3">
              <div className="text-sm font-medium text-[#040F2A]">{userName}</div>
              
              {/* Level Badge */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Úroveň:</span>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-1.5 px-2.5 py-1 bg-[#215EF8]/10 rounded">
                        <span className="text-xs font-bold text-[#215EF8]">{userLevel}</span>
                        <HelpCircle className="w-3 h-3 text-[#215EF8]/60" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">{getLevelDescription(userLevel)}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              
              {/* Slots Card */}
              <div className="p-3 bg-gradient-to-br from-[#14AE6B]/5 to-[#14AE6B]/10 border border-[#14AE6B]/20 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-medium text-gray-500 uppercase tracking-wide">Vaše sloty</span>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-lg font-bold text-[#14AE6B]">{remainingSlots}</span>
                      {totalSlots && (
                        <span className="text-xs text-gray-500">/ {totalSlots}</span>
                      )}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    volných
                  </div>
                </div>
              </div>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
            <User className="w-4 h-4 mr-2" />
            Můj profil
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Settings className="w-4 h-4 mr-2" />
            Nastavení
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Bell className="w-4 h-4 mr-2" />
            Notifikace
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setShowFAQ(true)}>
            <HelpCircle className="w-4 h-4 mr-2" />
            FAQ
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={() => {
              if (onNewProject) {
                onNewProject();
              }
            }}
            className="text-[#14AE6B] font-medium"
          >
            <Upload className="w-4 h-4 mr-2" />
            Nahrát projekt
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-destructive">
            <LogOut className="w-4 h-4 mr-2" />
            Odhlásit se
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* FAQ Modal */}
      <FAQModal isOpen={showFAQ} onClose={() => setShowFAQ(false)} />
    </div>
  );
}