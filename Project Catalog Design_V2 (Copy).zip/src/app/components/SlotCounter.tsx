/**
 * SLOT COUNTER COMPONENT
 * Displays global slot allocation in header
 */

import { Circle, Lock, CheckCircle } from 'lucide-react';
import { SlotAllocation } from '../types/reservation';
import { formatSlotCount } from '../utils/reservationHelpers';

interface SlotCounterProps {
  allocation: SlotAllocation;
  onClick?: () => void; // Optional: Click to see detail
}

export function SlotCounter({ allocation, onClick }: SlotCounterProps) {
  const { totalSlots, freeSlots, lockedWaitingSlots, lockedConfirmedSlots } = allocation;
  const usedSlots = lockedWaitingSlots + lockedConfirmedSlots;
  
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 px-4 py-2 rounded-lg border border-border bg-white hover:bg-gray-50 transition-colors"
    >
      {/* Free Slots */}
      <div className="flex items-center gap-2">
        <Circle className="w-4 h-4 text-[#14AE6B]" />
        <div className="text-left">
          <div className="text-xs text-muted-foreground">Volné sloty</div>
          <div className="text-sm font-semibold text-[#040F2A]">{freeSlots}</div>
        </div>
      </div>
      
      {/* Divider */}
      <div className="w-px h-8 bg-border" />
      
      {/* Locked Waiting */}
      <div className="flex items-center gap-2">
        <Lock className="w-4 h-4 text-yellow-600" />
        <div className="text-left">
          <div className="text-xs text-muted-foreground">Čeká</div>
          <div className="text-sm font-semibold text-[#040F2A]">{lockedWaitingSlots}</div>
        </div>
      </div>
      
      {/* Divider */}
      <div className="w-px h-8 bg-border" />
      
      {/* Locked Confirmed (Active) */}
      <div className="flex items-center gap-2">
        <CheckCircle className="w-4 h-4 text-[#215EF8]" />
        <div className="text-left">
          <div className="text-xs text-muted-foreground">Aktivní</div>
          <div className="text-sm font-semibold text-[#040F2A]">{lockedConfirmedSlots}</div>
        </div>
      </div>
      
      {/* Divider */}
      <div className="w-px h-8 bg-border" />
      
      {/* Total Summary */}
      <div className="text-left">
        <div className="text-xs text-muted-foreground">Celkem</div>
        <div className="text-sm font-semibold text-[#040F2A]">
          {usedSlots}/{totalSlots}
        </div>
      </div>
    </button>
  );
}

/**
 * Compact Slot Counter (for mobile/smaller spaces)
 */
export function SlotCounterCompact({ allocation }: { allocation: SlotAllocation }) {
  const { totalSlots, freeSlots } = allocation;
  const usedSlots = totalSlots - freeSlots;
  
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-white">
      <Circle className={`w-3.5 h-3.5 ${freeSlots > 0 ? 'text-[#14AE6B]' : 'text-gray-400'}`} />
      <span className="text-sm font-medium text-[#040F2A]">
        {freeSlots}/{totalSlots}
      </span>
    </div>
  );
}