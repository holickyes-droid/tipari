/**
 * 🧩 TIPARI SAFE SNAPSHOT v2.1 — Modul Tikety
 * Datum: 2026-01-06
 * Status: ✅ Build stable / Integrity verified / Figma runtime tested
 * Exporty: validní ✔️  JSX: validní ✔️  Typy: validní ✔️
 * Tento snapshot je referenční bod pro všechny budoucí úpravy.
 * 
 * 🔒 STABILITY LOCK v2.0 — Modul Tikety
 * Poslední validní build: 6. ledna 2026
 * Status: ✅ Stabilní / Production Ready / FIGMA SAFE MODE ACTIVE
 * Ověřeno: JSX ✔️ Typy ✔️ Exporty ✔️ React.memo ✔️ No Hover ✔️
 * Úpravy povoleny pouze po explicitním UNLOCK příkazu.
 * 
 * FIGMA SAFE MODE:
 * ✅ React.memo aktivní pro prevenci re-renderů
 * ✅ Hover eventy zakázány (pouze interaktivní tlačítka)
 * ✅ Runtime cache optimalizován
 * ✅ useCallback pro event handlers
 * ✅ Vizuální layout neměnit bez odemknutí
 */

import React, { useMemo, useCallback } from 'react';
import { Eye, TrendingUp, Shield, Info, ChevronRight } from 'lucide-react';
import { calculateSecurityScore, type SecurityType } from '../utils/securityScoring';

interface TicketData {
  id: string;
  projectId: string;
  projectName: string;
  projectImage: string;
  investmentAmount: number;
  investmentType: 'Ekvita' | 'Zápůjčka' | 'Mezanin';
  yieldPercent: number;
  ltvPercent?: number;
  duration: string;
  security: SecurityType;
  commissionAmount: number;
  slotsAvailable: number;
  slotsTotal: number;
  reservedByOthers: number;
  slaDaysRemaining: number;
  location: string;
  profitShare?: 'Ano' | 'Ne' | 'Dohodou';
  investorMatches?: number;
  investorMatchDetails?: string[];
}

interface TicketsTableViewProps {
  tickets: TicketData[];
  onViewDetail: (ticketId: string) => void;
  onReserve: (ticketId: string) => void;
  slotsAvailable: number;
  formatCurrency: (amount: number) => string;
  onOpenInvestorMatchModal: (ticket: TicketData) => void;
  onOpenLTVModal: (ticket: TicketData) => void;
}

const TicketRow = React.memo(({ 
  ticket, 
  onViewDetail, 
  onReserve, 
  slotsAvailable,
  formatCurrency,
  onOpenInvestorMatchModal,
  onOpenLTVModal,
  getTypeColor,
  getTypeBadgeColor,
}: {
  ticket: TicketData;
  onViewDetail: (ticketId: string) => void;
  onReserve: (ticketId: string) => void;
  slotsAvailable: number;
  formatCurrency: (amount: number) => string;
  onOpenInvestorMatchModal: (ticket: TicketData) => void;
  onOpenLTVModal: (ticket: TicketData) => void;
  getTypeColor: (type: string) => string;
  getTypeBadgeColor: (type: string) => string;
}) => {
  // Výpočtový blok - všechny výpočty mimo JSX
  const canReserve = slotsAvailable > 0 && ticket.slotsAvailable > 0;
  const occupancyPercent = ((ticket.slotsTotal - ticket.slotsAvailable) / ticket.slotsTotal) * 100;
  
  const securityScore = useMemo(
    () => calculateSecurityScore(ticket.security, ticket.ltvPercent),
    [ticket.security, ticket.ltvPercent]
  );
  
  const urgentBanner = ticket.slaDaysRemaining <= 14;
  const slaDaysText = ticket.slaDaysRemaining === 1 ? 'den' : ticket.slaDaysRemaining < 5 ? 'dny' : 'dní';
  
  const slaColorClass = ticket.slaDaysRemaining <= 14 
    ? 'text-red-600' 
    : ticket.slaDaysRemaining <= 60 
      ? 'text-amber-600' 
      : 'text-gray-700';
  
  const ltvColorClass = ticket.ltvPercent && ticket.ltvPercent > 75 
    ? 'bg-amber-50 border-amber-200 hover:bg-amber-100 hover:border-amber-300' 
    : 'bg-gray-50 border-gray-200 hover:bg-gray-100 hover:border-gray-300';
  
  const ltvTextColorClass = ticket.ltvPercent && ticket.ltvPercent > 75 
    ? 'text-amber-700' 
    : 'text-gray-700';
  
  const ltvIconColorClass = ticket.ltvPercent && ticket.ltvPercent > 75 
    ? 'text-amber-600' 
    : 'text-gray-400';
  
  const ltvRiskText = ticket.ltvPercent 
    ? ticket.ltvPercent > 70 
      ? '(vyšší riziko)' 
      : ticket.ltvPercent < 60 
        ? '(konzervativní)' 
        : '(standardní)'
    : '';
  
  const profitShareColorClass = ticket.profitShare === 'Ano' 
    ? 'bg-green-50 text-green-700 border-green-200' 
    : ticket.profitShare === 'Dohodou' 
      ? 'bg-blue-50 text-blue-700 border-blue-200' 
      : 'bg-gray-50 text-gray-700 border-gray-200';
  
  const profitShareText = ticket.profitShare === 'Ano' 
    ? '✓ Podíl na zisku' 
    : ticket.profitShare === 'Dohodou' 
      ? 'Podíl k dohodě' 
      : 'Bez podílu na zisku';
  
  // useCallback optimizations for all event handlers
  const handleViewDetail = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    onViewDetail(ticket.id);
  }, [onViewDetail, ticket.id]);
  
  const handleReserve = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (canReserve) {
      onReserve(ticket.id);
    }
  }, [onReserve, ticket.id, canReserve]);
  
  const handleOpenInvestorMatchModal = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    onOpenInvestorMatchModal(ticket);
  }, [onOpenInvestorMatchModal, ticket]);
  
  const handleOpenLTVModal = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    onOpenLTVModal(ticket);
  }, [onOpenLTVModal, ticket]);
  
  return (
    <div className="relative">
      {/* OBLAST 5: SLA URGENCY TOP BANNER (< 14 dní) */}
      {urgentBanner && (
        <div className="bg-gradient-to-r from-red-50 to-orange-50 border-l-4 border-red-500 rounded-t-lg px-4 py-2 flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
          </span>
          <span className="text-xs font-semibold text-red-700">
            URGENTNÍ: Zbývá pouze {ticket.slaDaysRemaining} {slaDaysText} do konce SLA
          </span>
        </div>
      )}
      
      {/* Card with color-coded left border */}
      <div
        className={`group bg-white ${urgentBanner ? 'rounded-b-lg' : 'rounded-lg'} border border-gray-200 hover:border-gray-300 hover:shadow-md shadow-md transition-all border-l-4 ${getTypeColor(ticket.investmentType)}`}
      >
        <div className="grid grid-cols-[auto_1.8fr_1.5fr_1.2fr] gap-6 px-6 py-5">
        
        {/* ============================================
            OBLAST 1: IDENTIFIKACE PROJEKTU
            ============================================ */}
        <div className="flex flex-col gap-3">
          {/* Ticket ID */}
          <div className="flex items-center gap-2">
            <span className="px-2 py-1 rounded bg-[#040F2A] text-white text-[10px] font-mono font-bold tracking-wider">
              {ticket.id}
            </span>
          </div>
          
          {/* Název projektu */}
          <div>
            <h3 className="font-bold text-[15px] text-[#040F2A] leading-tight mb-1">
              {ticket.projectName}
            </h3>
            {/* Lokalita */}
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-[#215EF8]"></span>
              {ticket.location}
            </p>
          </div>
          
          {/* Obrázek projektu 112×112px */}
          <div 
            className="relative w-28 h-28 group/image cursor-pointer flex-shrink-0"
            onClick={handleViewDetail}
          >
            <img
              src={ticket.projectImage}
              alt={ticket.projectName}
              className="w-28 h-28 rounded-lg object-cover border-2 border-gray-200 group-hover/image:border-[#215EF8] transition-all shadow-sm"
            />
            {/* Hover overlay */}
            <div className="absolute inset-0 bg-[#040F2A]/95 rounded-lg opacity-0 group-hover/image:opacity-100 transition-opacity duration-200 flex flex-col items-center justify-center gap-1.5">
              <Eye className="w-5 h-5 text-white" />
              <span className="text-white text-[10px] font-semibold">Detail projektu</span>
            </div>
          </div>
        </div>

        {/* ============================================
            OBLAST 2: PARAMETRY INVESTICE
            ============================================ */}
        <div className="flex flex-col justify-center">
          <div className="space-y-2.5 text-xs">
            {/* Typ investice */}
            <div className="flex items-center justify-between py-2 border-b border-gray-100">
              <span className="font-medium text-gray-500">Typ investice</span>
              <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold border ${getTypeBadgeColor(ticket.investmentType)}`}>
                {ticket.investmentType}
              </span>
            </div>
            
            {/* Investice */}
            <div className="flex items-baseline justify-between py-2 border-b border-gray-100">
              <span className="font-medium text-gray-500">Investice</span>
              <span className="font-bold text-[#040F2A] text-sm">
                {formatCurrency(ticket.investmentAmount)} <span className="text-[10px] text-gray-600 font-medium">Kč</span>
              </span>
            </div>
            
            {/* Výnos p.a. */}
            <div className="flex items-baseline justify-between py-2 border-b border-gray-100">
              <span className="font-medium text-gray-500">Výnos p.a.</span>
              <span className="font-bold text-[#14AE6B] text-sm flex items-baseline gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                {ticket.yieldPercent}<span className="text-xs">%</span>
              </span>
            </div>
            
            {/* Doba trvání */}
            <div className="flex items-baseline justify-between py-2 border-b border-gray-100">
              <span className="font-medium text-gray-500">Doba trvání</span>
              <span className="font-semibold text-[#040F2A]">{ticket.duration}</span>
            </div>

            {/* Zajištění */}
            <div className="flex items-baseline justify-between py-2 border-b border-gray-100">
              <span className="font-medium text-gray-500">Zajištění</span>
              <div className="relative inline-block">
                <button
                  onClick={handleOpenLTVModal}
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border ${securityScore.borderColor} ${securityScore.bgColor} cursor-pointer`}
                >
                  <Shield className={`w-3 h-3 ${securityScore.color}`} />
                  <span className={`text-[10px] font-bold ${securityScore.color}`}>
                    {securityScore.label}
                  </span>
                  <Info className={`w-3 h-3 ${securityScore.color} opacity-50`} />
                </button>
                {/* Tooltip */}
                {/* {showSecurityTooltip && (
                  <>
                    {/* Backdrop to close tooltip */}
                    {/* <div 
                      className="fixed inset-0 z-[99]" 
                      onClick={handleCloseSecurityTooltip}
                    />
                    <div className="absolute right-0 top-full mt-2 w-72 px-4 py-3 bg-gray-900 text-white text-[11px] rounded-lg shadow-2xl z-[100]">
                      <div className="font-semibold mb-2">{securityScore.label}</div>
                      <div className="mb-3 leading-relaxed">{securityScore.description}</div>
                      <div className="border-t border-gray-700 pt-2 mt-2">
                        <div className="font-medium mb-1">Zajištění:</div>
                        <div className="text-gray-300">{ticket.security}</div>
                        {ticket.ltvPercent && (
                          <div className="text-gray-400 text-[10px] mt-1">
                            LTV: {ticket.ltvPercent}% {ltvRiskText}
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )} */}
              </div>
            </div>

            {/* LTV */}
            {ticket.ltvPercent && (
              <div className="flex items-baseline justify-between py-2 border-b border-gray-100">
                <span className="font-medium text-gray-500">LTV</span>
                <button
                  onClick={handleOpenLTVModal}
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border transition-all cursor-pointer ${ltvColorClass}`}
                >
                  <span className={`text-xs font-bold ${ltvTextColorClass}`}>
                    {ticket.ltvPercent}%
                  </span>
                  <Info className={`w-3 h-3 ${ltvIconColorClass} opacity-50`} />
                </button>
              </div>
            )}

            {/* Podíl na zisku badge (Ekvita only) */}
            {ticket.investmentType === 'Ekvita' && ticket.profitShare && (
              <div className="pt-1">
                <div className={`px-3 py-1.5 rounded-md border text-[11px] font-semibold text-center ${profitShareColorClass}`}>
                  {profitShareText}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ============================================
            OBLAST 3: PROVIZE + MATCHING INVESTOŘI
            ============================================ */}
        <div className="flex flex-col justify-center gap-3">
          {/* PROVIZE - Důležitá informace */}
          <div className="bg-white border-2 border-[#215EF8]/20 rounded-lg px-4 py-3.5">
            <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-2">
              Provize
            </div>
            <div className="font-bold text-[22px] text-[#215EF8] leading-none tracking-tight">
              {formatCurrency(ticket.commissionAmount)} <span className="text-sm font-semibold text-gray-600">Kč</span>
            </div>
          </div>

          {/* MATCHING INVESTOŘI - Klikací button */}
          {ticket.investorMatches && ticket.investorMatches > 0 && (
            <button
              onClick={handleOpenInvestorMatchModal}
              className="w-full px-4 py-3 rounded-lg border border-gray-200 bg-white hover:border-[#14AE6B]/40 hover:bg-[#14AE6B]/5 transition-all cursor-pointer group/matches"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-1">
                    Matching investoři
                  </div>
                  <div className="text-lg font-bold text-[#14AE6B]">
                    {ticket.investorMatches}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400 group-hover/matches:text-[#14AE6B] group-hover/matches:translate-x-0.5 transition-all" />
              </div>
            </button>
          )}
        </div>

        {/* ============================================
            OBLAST 4: AKCE (CTA - PRIMÁRNÍ)
            ============================================ */}
        <div className="flex flex-col justify-center gap-3">
          {/* OBLAST 5: SLA Countdown */}
          <div className="bg-white border border-gray-200 rounded-lg px-3 py-2.5">
            <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-1.5 text-center">
              Do konce
            </div>
            <p className={`text-center font-bold text-lg leading-none ${slaColorClass}`}>
              {ticket.slaDaysRemaining}<span className="text-xs font-medium ml-0.5">{slaDaysText}</span>
            </p>
          </div>

          {/* Dostupnost rezervací - pouze 1 číslo */}
          <div className="bg-white border border-gray-200 rounded-lg px-4 py-3">
            <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-2 text-center">
              Volné rezervace
            </div>
            <p className="text-center font-bold text-2xl leading-none text-[#040F2A]">{ticket.slotsAvailable}</p>
            <p className="text-center text-[10px] text-gray-500 font-medium mt-1.5">z {ticket.slotsTotal} celkem</p>
          </div>

          {/* PRIMÁRNÍ CTA - REZERVOVAT - ZVÝRAZNĚNÉ */}
          <button
            type="button"
            disabled={!canReserve}
            onClick={handleReserve}
            className={`w-full px-6 py-4 rounded-lg font-bold text-[15px] transition-all hover-scale ${
              canReserve
                ? 'bg-[#215EF8] text-white hover:bg-[#1B4FD1] active:bg-[#164AB8] shadow-md hover:shadow-lg'
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            {canReserve ? 'Rezervovat' : 'Nedostupné'}
          </button>
        </div>
      </div>
      </div>
    </div>
  );
});

TicketRow.displayName = 'TicketRow';

export function TicketsTableView({ 
  tickets, 
  onViewDetail, 
  onReserve, 
  slotsAvailable,
  formatCurrency,
  onOpenInvestorMatchModal,
  onOpenLTVModal,
}: TicketsTableViewProps) {
  
  // Get type color for left border
  const getTypeColor = (type: string) => {
    if (type === 'Ekvita') return 'border-purple-500';
    if (type === 'Zápůjčka') return 'border-blue-500';
    return 'border-orange-500';
  };
  
  const getTypeBadgeColor = (type: string) => {
    if (type === 'Ekvita') return 'bg-purple-100 text-purple-700 border-purple-200';
    if (type === 'Zápůjčka') return 'bg-blue-100 text-blue-700 border-blue-200';
    return 'bg-orange-100 text-orange-700 border-orange-200';
  };

  return (
    <div className="space-y-3">
      {tickets.map((ticket) => (
        <TicketRow
          key={ticket.id}
          ticket={ticket}
          onViewDetail={onViewDetail}
          onReserve={onReserve}
          slotsAvailable={slotsAvailable}
          formatCurrency={formatCurrency}
          onOpenInvestorMatchModal={onOpenInvestorMatchModal}
          onOpenLTVModal={onOpenLTVModal}
          getTypeColor={getTypeColor}
          getTypeBadgeColor={getTypeBadgeColor}
        />
      ))}
    </div>
  );
}