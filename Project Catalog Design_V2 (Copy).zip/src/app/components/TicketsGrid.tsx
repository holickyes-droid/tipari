import { Check, Lock, Users, Star, AlertCircle } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Ticket } from '../types/project';
import { ReservationFlow } from './ReservationFlow';
import { ClientMatchesModal } from './ClientMatchesModal';
import { SecurityDetailsModal } from './SecurityDetailsModal';
import { LTVDetailsModal } from './LTVDetailsModal';
import { mockSlotAllocation, getReservationsByTicket } from '../data/mockReservations';
import { checkSlotAvailability } from '../utils/reservationHelpers';

interface TicketsGridProps {
  tickets: Ticket[];
  projectStatus: 'Active' | 'Last slots available' | 'Sold out' | 'Inactive';
  projectName: string;
  projectId?: string;
  onTicketSelect?: (ticket: Ticket) => void;
}

export function TicketsGrid({ tickets, projectStatus, projectName, projectId, onTicketSelect }: TicketsGridProps) {
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [showReservationModal, setShowReservationModal] = useState(false);
  const [showClientMatchesModal, setShowClientMatchesModal] = useState(false);
  const [currentMatchTicket, setCurrentMatchTicket] = useState<Ticket | null>(null);
  const [showAllTickets, setShowAllTickets] = useState(false);
  const [showSecurityDetailsModal, setShowSecurityDetailsModal] = useState(false);
  const [showLTVDetailsModal, setShowLTVDetailsModal] = useState(false);

  const INITIAL_DISPLAY_COUNT = 6; // Show first 6 tickets initially

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('cs-CZ', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const handleReserveClick = (ticket: Ticket) => {
    if (onTicketSelect) {
      onTicketSelect(ticket);
    } else {
      setSelectedTicket(ticket);
      setShowReservationModal(true);
    }
  };

  const handleClientMatchesClick = (ticket: Ticket) => {
    setCurrentMatchTicket(ticket);
    setShowClientMatchesModal(true);
  };

  const handleReserveFromMatches = (clientId: string) => {
    console.log('Reserve for client:', clientId);
    setShowClientMatchesModal(false);
  };

  const getTicketState = (ticket: Ticket): 'active' | 'nearly-full' | 'full' | 'inactive' => {
    const available = ticket.occupancy.total - ticket.occupancy.current;
    
    if (projectStatus === 'Sold out' || projectStatus === 'Inactive') {
      return 'inactive';
    }
    
    if (available === 0) {
      return 'full';
    }
    
    if (available === 1 || projectStatus === 'Last slots available') {
      return 'nearly-full';
    }
    
    return 'active';
  };

  const getStatusHeaderConfig = (state: string) => {
    switch (state) {
      case 'active':
        return {
          label: 'Dostupný tiket',
          bgColor: 'bg-[#14AE6B]/10',
          textColor: 'text-[#14AE6B]',
          borderColor: 'border-[#14AE6B]/20',
        };
      case 'nearly-full':
        return {
          label: 'Poslední slot',
          bgColor: 'bg-orange-50',
          textColor: 'text-orange-700',
          borderColor: 'border-orange-200',
        };
      case 'full':
        return {
          label: 'Vyprodáno',
          bgColor: 'bg-muted',
          textColor: 'text-muted-foreground',
          borderColor: 'border-border',
        };
      case 'inactive':
        return {
          label: 'Nedostupné',
          bgColor: 'bg-muted',
          textColor: 'text-muted-foreground',
          borderColor: 'border-border',
        };
      default:
        return {
          label: 'Dostupný tiket',
          bgColor: 'bg-white',
          textColor: 'text-[#040F2A]',
          borderColor: 'border-border',
        };
    }
  };

  const groupedTickets = tickets.reduce((acc, ticket) => {
    const state = getTicketState(ticket);
    if (!acc[state]) acc[state] = [];
    acc[state].push(ticket);
    return acc;
  }, {} as Record<string, Ticket[]>);

  // Mock client matches data
  const getClientMatches = (ticket: Ticket) => {
    if (ticket.recommendedInvestors.length === 0) return [];
    
    return [
      {
        id: 'INV-001',
        name: 'Petr Novák',
        type: 'Fyzická osoba',
        matchPercentage: 92,
        reservedSlots: 0,
        totalSlots: 3,
      },
      {
        id: 'INV-023',
        name: 'Jana Novotná',
        type: 'Fyzická osoba',
        matchPercentage: 88,
        reservedSlots: 1,
        totalSlots: 2,
      },
      {
        id: 'INV-045',
        name: 'Martin Král',
        type: 'Fyzická osoba',
        matchPercentage: 76,
        reservedSlots: 2,
        totalSlots: 2,
      },
    ];
  };

  const renderTicketCard = (ticket: Ticket) => {
    const state = getTicketState(ticket);
    const available = ticket.occupancy.total - ticket.occupancy.current;
    const occupancyPercentage = (ticket.occupancy.current / ticket.occupancy.total) * 100;
    const statusConfig = getStatusHeaderConfig(state);
    const commissionAmount = (ticket.investmentAmount * ticket.commission) / 100;
    
    // Check slot availability (NEW - MASTER SPEC COMPLIANCE)
    const userTicketReservations = getReservationsByTicket(ticket.id);
    const slotCheck = checkSlotAvailability(
      ticket,
      mockSlotAllocation.freeSlots,
      mockSlotAllocation.totalSlots,
      userTicketReservations.length
    );

    const cardBorderStyle = {
      active: 'border-[#14AE6B]/30 hover:border-[#14AE6B]/50 hover:shadow-sm',
      'nearly-full': 'border-orange-200 hover:border-orange-300 hover:shadow-sm',
      full: 'border-border',
      inactive: 'border-border',
    };

    return (
      <div
        key={ticket.id}
        className={`relative rounded-lg border bg-white overflow-hidden transition-all ${cardBorderStyle[state]}`}
      >
        {/* Status Header */}
        <div
          className={`px-3 py-1.5 border-b ${statusConfig.borderColor} ${statusConfig.bgColor}`}
        >
          <div className="flex items-center justify-between">
            <span className={`text-xs font-medium ${statusConfig.textColor}`}>
              {statusConfig.label}
            </span>
            <span className="font-mono text-[10px] text-muted-foreground">
              {ticket.ticketNumber}
            </span>
          </div>
        </div>

        {/* Card Content - KOMPAKTNÍ PRO MACBOOK 14 */}
        <div className="p-3 space-y-2.5">
          {/* Investment Amount - Zmenšeno */}
          <div>
            <div className="text-[10px] text-muted-foreground mb-0.5">Výše investice</div>
            <div className="text-xl font-semibold text-[#040F2A]">
              {formatCurrency(ticket.investmentAmount)} Kč
            </div>
          </div>

          {/* Key Parameters Grid - Kompaktnější */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <div>
              <div className="text-[10px] text-muted-foreground mb-0.5">Výnos p.a.</div>
              <div className="text-sm font-semibold text-[#14AE6B]">
                {ticket.yieldPA.toFixed(1)}%
              </div>
            </div>
            <div>
              <div className="text-[10px] text-muted-foreground mb-0.5">Doba trvání</div>
              <div className="text-sm font-semibold text-[#040F2A]">
                {ticket.duration} měs.
              </div>
            </div>
            {ticket.ltv !== undefined && (
              <div>
                <div className="text-[10px] text-muted-foreground mb-0.5">LTV</div>
                <button
                  onClick={() => {
                    setSelectedTicket(ticket);
                    setShowLTVDetailsModal(true);
                  }}
                  className="text-sm font-semibold text-[#215EF8] hover:underline cursor-pointer"
                >
                  {ticket.ltv}%
                </button>
              </div>
            )}
          </div>

          {/* Indicators - Kompaktnější */}
          <div className="flex items-center gap-3 pt-1 text-xs border-t border-gray-100">
            <div className="flex items-center gap-1.5">
              {ticket.secured && ticket.securedTypes && ticket.securedTypes.length > 0 ? (
                <button
                  onClick={() => {
                    setSelectedTicket(ticket);
                    setShowSecurityDetailsModal(true);
                  }}
                  className="flex items-center gap-1 text-[#040F2A] hover:text-[#215EF8] transition-colors cursor-pointer"
                >
                  <div className="w-3 h-3 rounded-full bg-[#14AE6B]/10 flex items-center justify-center">
                    <Check className="w-2 h-2 text-[#14AE6B]" />
                  </div>
                  <span className="hover:underline text-[10px]">Zajištěno</span>
                </button>
              ) : ticket.secured ? (
                <>
                  <div className="w-3 h-3 rounded-full bg-[#14AE6B]/10 flex items-center justify-center">
                    <Check className="w-2 h-2 text-[#14AE6B]" />
                  </div>
                  <span className="text-[#040F2A] text-[10px]">Zajištěno</span>
                </>
              ) : (
                <span className="text-muted-foreground text-[10px]">Nezajištěno</span>
              )}
            </div>

            {ticket.recommendedInvestors.length > 0 && (
              <button
                onClick={() => handleClientMatchesClick(ticket)}
                className="flex items-center gap-1 text-[#215EF8] hover:underline ml-auto"
              >
                <Users className="w-3 h-3" />
                <span className="text-[10px]">Shody ({ticket.recommendedInvestors.length})</span>
              </button>
            )}
          </div>

          {/* Commission Highlight - Kompaktnější */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-2.5">
            <div className="flex items-center gap-1.5 mb-1">
              <Star className="w-3 h-3 text-amber-600 fill-amber-600" />
              <span className="text-[10px] font-medium text-amber-900">Vaše provize</span>
            </div>
            <div className="text-lg font-bold text-amber-900 mb-0.5">
              {formatCurrency(commissionAmount)} Kč
            </div>
            <div className="text-[10px] text-amber-700">
              {ticket.commission.toFixed(1)}% z investované částky
            </div>
          </div>

          {/* Occupancy - Kompaktnější */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] text-muted-foreground">Obsazenost</span>
              <span className="text-xs font-medium text-[#040F2A]">
                {ticket.occupancy.current} / {ticket.occupancy.total}
              </span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  state === 'active' 
                    ? 'bg-[#14AE6B]' 
                    : state === 'nearly-full' 
                    ? 'bg-orange-500' 
                    : 'bg-muted-foreground/30'
                }`}
                style={{ width: `${occupancyPercentage}%` }}
              />
            </div>
          </div>

          {/* User Reservation Indicator - Kompaktnější */}
          {userTicketReservations.length > 0 && (
            <div className="bg-[#215EF8]/10 border border-[#215EF8]/20 rounded-lg p-2">
              <div className="flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-[#215EF8]" />
                <span className="text-xs font-medium text-[#215EF8]">
                  Máte zde {userTicketReservations.length} {userTicketReservations.length === 1 ? 'rezervaci' : userTicketReservations.length < 5 ? 'rezervace' : 'rezervací'}
                </span>
              </div>
            </div>
          )}

          {/* CTA - Updated with Slot Logic - Kompaktnější */}
          <TooltipProvider>
            <div className="flex items-center gap-2 pt-1">
              {slotCheck.canReserve ? (
                <Button
                  className="flex-1 bg-[#215EF8] hover:bg-[#1a4bc7] text-white h-9 text-sm"
                  onClick={() => handleReserveClick(ticket)}
                >
                  Rezervovat
                </Button>
              ) : (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="flex-1">
                      <Button
                        className="w-full bg-muted text-muted-foreground cursor-not-allowed h-9 text-sm"
                        disabled
                      >
                        <Lock className="w-3 h-3 mr-1.5" />
                        {state === 'full' ? 'Obsazeno' : 'Rezervovat'}
                      </Button>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <div className="space-y-2">
                      <p className="font-medium text-sm">{slotCheck.blockingReason}</p>
                      <div className="text-xs space-y-1 text-muted-foreground">
                        <div className="flex justify-between">
                          <span>Globální sloty:</span>
                          <span className={slotCheck.hasGlobalSlots ? 'text-[#14AE6B]' : 'text-red-600'}>
                            {slotCheck.globalSlotsFree}/{slotCheck.globalSlotsTotal}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Rezervace na tiketu:</span>
                          <span className={slotCheck.hasTicketSlots ? 'text-[#14AE6B]' : 'text-red-600'}>
                            {slotCheck.ticketReservations}/{slotCheck.ticketMaxReservations}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Kapacita tiketu:</span>
                          <span className={slotCheck.hasTicketCapacity ? 'text-[#14AE6B]' : 'text-red-600'}>
                            {slotCheck.ticketOccupancy.current}/{slotCheck.ticketOccupancy.total}
                          </span>
                        </div>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              )}
              {slotCheck.canReserve && available > 0 && (
                <div className="text-xs text-muted-foreground whitespace-nowrap">
                  {available} {available === 1 ? 'slot' : available < 5 ? 'sloty' : 'slotů'}
                </div>
              )}
            </div>
          </TooltipProvider>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="space-y-6">
        {/* Active Tickets */}
        {groupedTickets.active && groupedTickets.active.length > 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {groupedTickets.active.slice(0, showAllTickets ? undefined : INITIAL_DISPLAY_COUNT).map(renderTicketCard)}
            </div>
            {groupedTickets.active.length > INITIAL_DISPLAY_COUNT && !showAllTickets && (
              <div className="text-center pt-2">
                <Button
                  variant="outline"
                  className="bg-[#215EF8] hover:bg-[#1a4bc7] text-white border-[#215EF8]"
                  onClick={() => setShowAllTickets(true)}
                >
                  Zobrazit všech {groupedTickets.active.length} tiketů
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Nearly Full Tickets */}
        {groupedTickets['nearly-full'] && groupedTickets['nearly-full'].length > 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {groupedTickets['nearly-full'].slice(0, showAllTickets ? undefined : INITIAL_DISPLAY_COUNT).map(renderTicketCard)}
            </div>
            {groupedTickets['nearly-full'].length > INITIAL_DISPLAY_COUNT && !showAllTickets && (
              <div className="text-center">
                <Button
                  className="bg-[#215EF8] hover:bg-[#1a4bc7] text-white"
                  onClick={() => setShowAllTickets(true)}
                >
                  Zobrazit všechny tikety
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Full Tickets */}
        {groupedTickets.full && groupedTickets.full.length > 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {groupedTickets.full.slice(0, showAllTickets ? undefined : INITIAL_DISPLAY_COUNT).map(renderTicketCard)}
            </div>
            {groupedTickets.full.length > INITIAL_DISPLAY_COUNT && !showAllTickets && (
              <div className="text-center">
                <Button
                  className="bg-[#215EF8] hover:bg-[#1a4bc7] text-white"
                  onClick={() => setShowAllTickets(true)}
                >
                  Zobrazit všechny tikety
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Inactive Tickets */}
        {groupedTickets.inactive && groupedTickets.inactive.length > 0 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {groupedTickets.inactive.slice(0, showAllTickets ? undefined : INITIAL_DISPLAY_COUNT).map(renderTicketCard)}
            </div>
            {groupedTickets.inactive.length > INITIAL_DISPLAY_COUNT && !showAllTickets && (
              <div className="text-center">
                <Button
                  className="bg-[#215EF8] hover:bg-[#1a4bc7] text-white"
                  onClick={() => setShowAllTickets(true)}
                >
                  Zobrazit všechny tikety
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      <ReservationFlow
        isOpen={showReservationModal}
        onClose={() => setShowReservationModal(false)}
        ticket={selectedTicket}
        projectName={projectName}
        projectId={projectId}
      />

      <ClientMatchesModal
        isOpen={showClientMatchesModal}
        onClose={() => setShowClientMatchesModal(false)}
        ticketNumber={currentMatchTicket?.ticketNumber || ''}
        ticket={currentMatchTicket}
        projectName={projectName}
        matches={currentMatchTicket ? getClientMatches(currentMatchTicket) : []}
        onReserve={handleReserveFromMatches}
      />

      <SecurityDetailsModal
        isOpen={showSecurityDetailsModal}
        onClose={() => setShowSecurityDetailsModal(false)}
        ticketNumber={selectedTicket?.ticketNumber || ''}
        projectName={projectName}
        projectId={projectId || ''}
        securedTypes={selectedTicket?.securedTypes || []}
      />

      <LTVDetailsModal
        isOpen={showLTVDetailsModal}
        onClose={() => setShowLTVDetailsModal(false)}
        ticketNumber={selectedTicket?.ticketNumber || ''}
        projectName={projectName}
        ltvDetails={selectedTicket?.ltvDetails || {
          value: selectedTicket?.ltv || 0,
          appraisalType: 'externí',
          appraiserName: 'Není k dispozici',
          appraiserCompany: 'Není k dispozici',
        }}
      />
    </>
  );
}