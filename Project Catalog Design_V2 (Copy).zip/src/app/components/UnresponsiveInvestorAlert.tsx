/**
 * UNRESPONSIVE INVESTOR ALERT
 * 
 * Alert komponenta pro zobrazení rezervací kde investor dlouho nereaguje.
 * Umožňuje obchodníkovi rychle identifikovat a připomenout investory.
 */

import { useState } from 'react';
import { Clock, Send, AlertCircle, ChevronDown, ChevronUp, Mail, Phone } from 'lucide-react';
import { toast } from 'sonner';

interface UnresponsiveReservation {
  id: string;
  reservationNumber: string;
  investorName: string;
  investorEmail: string;
  investorPhone: string;
  projectName: string;
  ticketId: string;
  contractSentAt: string;
  hoursElapsed: number;
  slaDeadline?: string;
}

interface UnresponsiveInvestorAlertProps {
  reservations: UnresponsiveReservation[];
  onResendContract: (reservationId: string) => void;
  onViewDetail: (reservationId: string) => void;
}

export function UnresponsiveInvestorAlert({
  reservations,
  onResendContract,
  onViewDetail
}: UnresponsiveInvestorAlertProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [resending, setResending] = useState<string | null>(null);

  if (!reservations || reservations.length === 0) return null;

  const formatTimeSince = (dateStr: string): string => {
    const now = new Date();
    const sent = new Date(dateStr);
    const hours = Math.floor((now.getTime() - sent.getTime()) / (1000 * 60 * 60));
    
    if (hours < 24) {
      return `Bez reakce ${hours} h`;
    } else if (hours < 48) {
      const remainingHours = hours - 24;
      return `Bez reakce 1 den ${remainingHours} h`;
    } else if (hours < 72) {
      const days = Math.floor(hours / 24);
      const remainingHours = hours % 24;
      return `Bez reakce ${days} dny ${remainingHours} h`;
    } else {
      // For reservations past 72h, use SLA-relative phrasing
      return 'Po SLA – bez reakce investora';
    }
  };

  const getSeverityColor = (hours: number): string => {
    if (hours >= 48) return 'text-red-600 bg-red-50 border-red-200';
    if (hours >= 24) return 'text-orange-600 bg-orange-50 border-orange-200';
    return 'text-amber-600 bg-amber-50 border-amber-200';
  };

  const getSeverityBadge = (hours: number): { color: string; label: string } => {
    if (hours >= 48) return { color: 'bg-red-100 text-red-700', label: 'Kritické' };
    if (hours >= 24) return { color: 'bg-orange-100 text-orange-700', label: 'Urgentní' };
    return { color: 'bg-amber-100 text-amber-700', label: 'Připomínka' };
  };

  const handleResendContract = async (reservationId: string, investorEmail: string) => {
    setResending(reservationId);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    onResendContract(reservationId);
    toast.success(`Rezervační smlouva znovu odeslána na ${investorEmail}`);
    setResending(null);
  };

  // Sort by hours elapsed (most critical first)
  const sortedReservations = [...reservations].sort((a, b) => b.hoursElapsed - a.hoursElapsed);

  return (
    <div className="bg-white border-2 border-orange-300 rounded-lg overflow-hidden shadow-sm">
      {/* Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full bg-gradient-to-r from-orange-50 to-amber-50 px-5 py-4 flex items-center justify-between hover:from-orange-100 hover:to-amber-100 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-orange-600" />
          </div>
          <div className="text-left">
            <div className="font-semibold text-[#040F2A] flex items-center gap-2">
              Investoři nereagující na smlouvu
              <span className="px-2 py-0.5 text-xs font-bold bg-orange-600 text-white rounded-full">
                {reservations.length}
              </span>
            </div>
            <p className="text-sm text-gray-600 mt-0.5">
              {reservations.length === 1 
                ? 'Investor' 
                : `${reservations.length} investorů`} 
              {' '}nereagoval na rezervační smlouvu déle než 12 hodin
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-orange-700 bg-orange-100 px-3 py-1 rounded-full">
            Vyžaduje akci
          </span>
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-gray-600" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-600" />
          )}
        </div>
      </button>

      {/* Content */}
      {isExpanded && (
        <div className="border-t border-orange-200">
          <div className="p-5 space-y-3 max-h-[400px] overflow-y-auto">
            {sortedReservations.map((reservation) => {
              const severity = getSeverityBadge(reservation.hoursElapsed);
              
              return (
                <div
                  key={reservation.id}
                  className={`border-2 rounded-lg p-4 transition-all hover:shadow-md ${getSeverityColor(reservation.hoursElapsed)}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-[#040F2A]">
                          {reservation.investorName}
                        </h4>
                        <span className={`px-2 py-0.5 text-xs font-semibold rounded ${severity.color}`}>
                          {severity.label}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 font-mono">
                        {reservation.reservationNumber}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1.5 text-sm font-bold text-orange-700">
                        <Clock className="w-4 h-4" />
                        <span>{formatTimeSince(reservation.contractSentAt)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div>
                      <p className="text-xs text-gray-600 mb-0.5">Projekt</p>
                      <p className="text-sm font-medium text-[#040F2A]">
                        {reservation.projectName}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-600 mb-0.5">Tiket</p>
                      <p className="text-sm font-mono text-[#040F2A]">
                        {reservation.ticketId}
                      </p>
                    </div>
                  </div>

                  <div className="bg-white/60 rounded px-3 py-2 mb-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-600">Smlouva odeslána:</span>
                      <span className="font-medium text-gray-900">
                        {new Date(reservation.contractSentAt).toLocaleString('cs-CZ', {
                          day: '2-digit',
                          month: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                    {reservation.slaDeadline && (
                      <div className="flex items-center justify-between text-xs mt-1">
                        <span className="text-gray-600">SLA deadline:</span>
                        <span className="font-medium text-red-600">
                          {new Date(reservation.slaDeadline).toLocaleString('cs-CZ', {
                            day: '2-digit',
                            month: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleResendContract(reservation.id, reservation.investorEmail)}
                      disabled={resending === reservation.id}
                      className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-semibold text-white bg-[#215EF8] rounded-lg hover:bg-[#1B4FD1] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <Send className="w-4 h-4" />
                      {resending === reservation.id ? 'Odesílám...' : 'Připomenout'}
                    </button>
                    <button
                      onClick={() => window.location.href = `mailto:${reservation.investorEmail}`}
                      className="px-3 py-2 text-sm font-semibold text-[#040F2A] bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      title="Napsat e-mail"
                    >
                      <Mail className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => window.location.href = `tel:${reservation.investorPhone}`}
                      className="px-3 py-2 text-sm font-semibold text-[#040F2A] bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      title="Zavolat"
                    >
                      <Phone className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onViewDetail(reservation.id)}
                      className="px-3 py-2 text-sm font-medium text-[#215EF8] hover:text-[#1B4FD1] transition-colors"
                    >
                      Detail
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer Help */}
          <div className="bg-blue-50 border-t border-blue-200 px-5 py-3">
            <p className="text-xs text-gray-700 leading-relaxed">
              <strong>💡 Tip:</strong> Doporučujeme připomenout investorovi do 24 hodin od odeslání smlouvy. 
              Po 48 hodinách bez odpovědi zvažte telefonický kontakt. Pokud investor nereaguje ani po opakovaném připomenutí, rezervace je po vypršení SLA automaticky ukončena.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}