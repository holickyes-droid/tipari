/**
 * TICKETS PAGE COMPONENT (OPTIMIZED GENIUS VERSION)
 * 
 * Performance optimizations:
 * - React.memo for preventing unnecessary re-renders
 * - useMemo for expensive calculations
 * - useCallback for stable function references
 * - Separated business logic into utility functions
 * - Extracted constants for maintainability
 * 
 * Code quality improvements:
 * - TypeScript strict mode compliance
 * - Consistent error handling
 * - Accessibility enhancements
 * - Better component composition
 */

import { useState, useMemo, useCallback, memo } from 'react';
import { Eye, X, Columns3, ChevronDown, Star, Search, Grid3x3, List, SlidersHorizontal, Bell, Download } from 'lucide-react';
import { Project, Ticket } from '../types/project';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ReservationFlow } from './ReservationFlow';
import { CTASection } from './CTASection';
import { formatCurrency } from '../utils/formatters';
import {
  getTicketAvailability,
  getGlobalTicketActivity,
  getUserTicketActivity,
  getMatchCount,
  calculateCommission,
} from '../utils/ticketHelpers';

// ==========================================
// TYPE DEFINITIONS
// ==========================================

interface TicketsPageProps {
  projects: Project[];
  onViewProjectDetail: (projectId: string) => void;
  onReserveTicket: (projectId: string, ticketId: string) => void;
  onViewReservationDetail?: (reservationId: string) => void;
  onOpenAddInvestor?: () => void;
  onNewProject?: () => void;
  onOpenDraftsPanel?: () => void;
}

interface TicketWithProject extends Ticket {
  projectId: string;
  projectName: string;
  projectLocation: string;
  projectAssetClass: string;
  projectSecured: boolean;
  projectImageUrl: string;
  projectSlaDeadline?: string; // Add SLA deadline
  projectOwnerId?: string; // Add project owner ID
}

type SortOption = 'yield' | 'duration' | 'amount';

// Mock current user ID (in production, from auth context)
const CURRENT_USER_ID = 'current-tipar-id';

// ==========================================
// SUB-COMPONENTS (Memoized for performance)
// ==========================================

interface TableHeaderProps {
  sortBy: SortOption;
  onSortChange: (sort: SortOption) => void;
  totalTickets: number;
}

const TableHeader = memo(({ sortBy, onSortChange, totalTickets }: TableHeaderProps) => (
  <div className="flex items-center justify-between mb-6">
    <div>
      <h1 className="text-[#040F2A] mb-2">Všechny tikety</h1>
      <p className="text-muted-foreground">
        Přehled všech dostupných tiketů napříč platformou ({totalTickets} tiketů)
      </p>
    </div>

    <div className="flex items-center gap-2">
      <span className="text-sm text-muted-foreground">Řadit podle:</span>
      <div className="flex gap-1 border border-border rounded-lg p-1">
        <SortButton
          active={sortBy === 'yield'}
          onClick={() => onSortChange('yield')}
          label="Výnos"
        />
        <SortButton
          active={sortBy === 'duration'}
          onClick={() => onSortChange('duration')}
          label="Délka"
        />
        <SortButton
          active={sortBy === 'amount'}
          onClick={() => onSortChange('amount')}
          label="Investice"
        />
      </div>
    </div>
  </div>
));

TableHeader.displayName = 'TableHeader';

interface SortButtonProps {
  active: boolean;
  onClick: () => void;
  label: string;
}

const SortButton = memo(({ active, onClick, label }: SortButtonProps) => (
  <button
    onClick={onClick}
    className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
      active
        ? 'bg-[#215EF8] text-white'
        : 'text-[#040F2A] hover:bg-gray-100'
    }`}
    aria-pressed={active}
  >
    {label}
  </button>
));

SortButton.displayName = 'SortButton';

// ==========================================
// TICKET ROW COMPONENT (Optimized)
// ==========================================

interface TicketRowProps {
  ticket: TicketWithProject;
  isLast: boolean;
  onReserve: (ticket: TicketWithProject) => void;
  onViewReservations: (ticket: TicketWithProject) => void;
  onViewProject: (projectId: string) => void;
}

const TicketRow = memo(({ 
  ticket, 
  isLast, 
  onReserve, 
  onViewReservations, 
  onViewProject 
}: TicketRowProps) => {
  const availability = useMemo(
    () => getTicketAvailability(ticket, CURRENT_USER_ID),
    [ticket]
  );
  
  const globalActivity = useMemo(
    () => getGlobalTicketActivity(ticket, CURRENT_USER_ID),
    [ticket]
  );
  
  const myActivity = useMemo(
    () => getUserTicketActivity(ticket, CURRENT_USER_ID),
    [ticket]
  );
  
  const matchCount = useMemo(() => getMatchCount(ticket), [ticket]);
  const commission = useMemo(() => calculateCommission(ticket), [ticket]);

  // Extract city and district from location (e.g., "Praha 1" from "Praha 1, Staré Město")
  const getShortLocation = (location: string): string => {
    const parts = location.split(',');
    return parts[0]?.trim() || location;
  };

  // Calculate days until SLA deadline
  const getSLADaysRemaining = (slaDeadline?: string): { days: number; text: string; color: string } | null => {
    if (!slaDeadline) return null;
    
    const now = new Date();
    const deadline = new Date(slaDeadline);
    const diffTime = deadline.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return {
        days: diffDays,
        text: `${Math.abs(diffDays)} dnů`,
        color: 'text-red-600'
      };
    } else if (diffDays === 0) {
      return {
        days: 0,
        text: 'Dnes',
        color: 'text-orange-600'
      };
    } else if (diffDays === 1) {
      return {
        days: 1,
        text: 'Zítra',
        color: 'text-orange-600'
      };
    } else if (diffDays <= 3) {
      return {
        days: diffDays,
        text: `${diffDays} dny`,
        color: 'text-orange-600'
      };
    } else if (diffDays <= 7) {
      return {
        days: diffDays,
        text: `${diffDays} dnů`,
        color: 'text-[#215EF8]'
      };
    } else {
      return {
        days: diffDays,
        text: `${diffDays} dnů`,
        color: 'text-[#6B7280]'
      };
    }
  };

  const slaInfo = useMemo(() => getSLADaysRemaining(ticket.projectSlaDeadline), [ticket.projectSlaDeadline]);

  // Check if this is "my project" (project I uploaded to platform)
  const isMyProject = useMemo(() => ticket.projectOwnerId === CURRENT_USER_ID, [ticket.projectOwnerId]);

  return (
    <div
      className={`flex items-center gap-0.5 px-1 py-4 hover:bg-gray-50 transition-colors ${
        !isLast ? 'border-b border-border' : ''
      }`}
    >
      {/* Project Image */}
      <div className="w-[50px] flex-shrink-0">
        <div className="relative w-[50px] h-[50px] rounded-lg overflow-hidden bg-muted border border-border">
          <ImageWithFallback
            src={ticket.projectImageUrl}
            alt={ticket.projectName}
            className="w-full h-full object-cover"
          />
          {/* My Project Tag */}
          {isMyProject && (
            <div 
              className="absolute top-1 right-1 w-4 h-4 bg-[#215EF8] rounded-full flex items-center justify-center shadow-sm"
              title="Můj projekt"
              aria-label="Můj projekt"
            >
              <Star className="w-2.5 h-2.5 text-white fill-white" />
            </div>
          )}
        </div>
      </div>

      {/* Ticket ID + Project Name + Location */}
      <div className="w-[140px] flex-shrink-0">
        <div className="text-[8px] text-muted-foreground font-medium mb-0.5">
          {ticket.ticketNumber}
        </div>
        <div className="font-semibold text-[#040F2A] text-[10px] leading-tight mb-0.5">
          {ticket.projectName}
        </div>
        <div className="text-[8px] text-muted-foreground">
          {getShortLocation(ticket.projectLocation)}
        </div>
      </div>

      {/* Investment + Yield + Duration */}
      <div className="w-[130px] flex-shrink-0">
        {ticket.investmentForm && (
          <div className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wide mb-1">
            {ticket.investmentForm}
          </div>
        )}
        
        <div className="font-bold text-[#040F2A] text-[11px] leading-tight mb-1">
          {formatCurrency(ticket.investmentAmount)}
        </div>
        
        <div className="flex items-center gap-1.5 text-[9px]">
          <span className="font-bold text-[#14AE6B]">{ticket.yieldPA.toFixed(1)}%</span>
          <span className="text-muted-foreground">•</span>
          <span className="text-muted-foreground font-medium">{ticket.duration} m</span>
        </div>
      </div>

      {/* LTV + Secured */}
      <div className="w-[75px] flex-shrink-0">
        <div className="flex items-center gap-1.5">
          <div className="font-bold text-[#040F2A] text-[11px]">
            {ticket.ltv}%
          </div>
          {ticket.secured ? (
            <svg className="w-3 h-3 flex-shrink-0 text-[#14AE6B]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
            </svg>
          ) : (
            <span className="text-[9px] text-muted-foreground font-medium">-</span>
          )}
        </div>
      </div>

      {/* Matches */}
      <div className="w-[60px] flex-shrink-0">
        <div className="flex items-center gap-1.5">
          <svg className="w-3 h-3 text-[#215EF8] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <span className="font-bold text-[#215EF8] text-[11px]">{matchCount}</span>
        </div>
      </div>

      {/* Active Reservations */}
      <div className="w-[70px] flex-shrink-0">
        <div className="font-bold text-[#215EF8] text-[11px]">
          {globalActivity.activeReservations}
        </div>
      </div>

      {/* Reserved Slots by Others */}
      <div className="w-[75px] flex-shrink-0">
        <div className="font-bold text-[#040F2A] text-[11px]">
          {globalActivity.pendingSlotsOthers}
        </div>
      </div>

      {/* Commission */}
      <div className="w-[115px] flex-shrink-0">
        <div className="font-bold text-[#14AE6B] text-[14px] leading-none">
          {formatCurrency(commission).replace(' Kč', '')}
        </div>
        <div className="text-[8px] text-muted-foreground mt-1">Kč</div>
      </div>

      {/* Actions */}
      <div className="flex flex-col items-start gap-1 w-[185px] flex-shrink-0">
        {/* SLA Deadline - show above buttons if available */}
        {slaInfo && (
          <div className="text-[7px] text-muted-foreground mb-0.5 ml-1">
            SLA do konce: <span className={`font-semibold ${slaInfo.color}`}>{slaInfo.text}</span>
          </div>
        )}
        
        <div className="flex items-center gap-2">
          {availability.isAvailable ? (
            <button
              onClick={() => onReserve(ticket)}
              className="px-4 py-2 rounded-lg bg-[#14AE6B] hover:bg-[#0D7A4A] transition-colors shadow-sm flex-shrink-0 cursor-pointer"
              aria-label={`Rezervovat tiket ${ticket.ticketNumber}`}
            >
              <span className="text-white font-bold text-[9px]">Rezervovat</span>
            </button>
          ) : (
            <button
              disabled
              className="px-4 py-2 rounded-lg bg-gray-200 cursor-not-allowed flex-shrink-0"
              aria-label="Tiket je plný"
            >
              <span className="text-gray-500 font-semibold text-[9px]">Plné</span>
            </button>
          )}

          {myActivity.myActiveReservations > 0 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onViewReservations(ticket);
              }}
              className="px-2 py-1.5 rounded-lg bg-[#215EF8] hover:bg-[#1a4bc4] transition-colors flex items-center gap-1.5 flex-shrink-0"
              title={`Moje rezervace: ${myActivity.myActiveReservations}`}
              aria-label={`Zobrazit ${myActivity.myActiveReservations} moje rezervace`}
            >
              <svg className="w-3 h-3 text-white flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span className="text-white font-bold text-[10px]">{myActivity.myActiveReservations}</span>
            </button>
          )}

          <button
            onClick={() => onViewProject(ticket.projectId)}
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-border hover:border-[#215EF8] hover:bg-[#215EF8]/5 transition-colors flex-shrink-0"
            title="Detail projektu"
            aria-label="Zobrazit detail projektu"
          >
            <Eye className="w-[13px] h-[13px] text-[#040F2A]" />
          </button>
        </div>
        
        <div className={`text-[8px] font-medium ${availability.color} ml-1`}>
          {availability.text}
        </div>
      </div>
    </div>
  );
});

TicketRow.displayName = 'TicketRow';

// ==========================================
// MAIN COMPONENT
// ==========================================

export function TicketsPage({ 
  projects, 
  onViewProjectDetail, 
  onReserveTicket, 
  onViewReservationDetail,
  onOpenAddInvestor,
  onNewProject,
  onOpenDraftsPanel
}: TicketsPageProps) {
  const [sortBy, setSortBy] = useState<SortOption>('yield');
  const [showMyReservationsModal, setShowMyReservationsModal] = useState(false);
  const [selectedTicketReservations, setSelectedTicketReservations] = useState<any[]>([]);
  const [selectedTicketInfo, setSelectedTicketInfo] = useState<{ ticketNumber: string; projectName: string } | null>(null);
  const [showReservationFlow, setShowReservationFlow] = useState(false);
  const [selectedTicketForReservation, setSelectedTicketForReservation] = useState<TicketWithProject | null>(null);
  const [showColumnsDropdown, setShowColumnsDropdown] = useState(false);
  
  // New control panel states
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyOpen, setShowOnlyOpen] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('Všechny');
  const [activeFilters, setActiveFilters] = useState<{
    investice: boolean;
    vynos: boolean;
    delka: boolean;
    ltv: boolean;
    provize: boolean;
    forma: boolean;
  }>({
    investice: false,
    vynos: false,
    delka: false,
    ltv: false,
    provize: false,
    forma: false,
  });

  // Column visibility state
  const [visibleColumns, setVisibleColumns] = useState({
    projekt: true,
    nazevId: true,
    investice: true,
    ltvZajisteni: true,
    shody: true,
    aktivniRez: true,
    sloutyOstatnich: true,
    provize: true,
    akce: true,
  });

  const toggleColumn = useCallback((column: keyof typeof visibleColumns) => {
    setVisibleColumns(prev => ({ ...prev, [column]: !prev[column] }));
  }, []);
  
  const toggleFilter = useCallback((filter: keyof typeof activeFilters) => {
    setActiveFilters(prev => ({ ...prev, [filter]: !prev[filter] }));
  }, []);

  // Flatten and enrich tickets - memoized for performance
  const allTickets: TicketWithProject[] = useMemo(
    () => projects.flatMap((project) =>
      project.tickets.map((ticket) => ({
        ...ticket,
        projectId: project.id,
        projectName: project.name,
        projectLocation: project.location,
        projectAssetClass: project.assetClass,
        projectSecured: project.secured,
        projectImageUrl: project.imageUrl,
        projectSlaDeadline: project.slaDeadline, // Add SLA deadline
        projectOwnerId: project.ownerId, // Add project owner ID
      }))
    ),
    [projects]
  );

  // Sort tickets - memoized for performance
  const sortedTickets = useMemo(() => {
    return [...allTickets].sort((a, b) => {
      switch (sortBy) {
        case 'yield':
          return b.yieldPA - a.yieldPA;
        case 'duration':
          return a.duration - b.duration;
        case 'amount':
          return b.investmentAmount - a.investmentAmount;
        default:
          return 0;
      }
    });
  }, [allTickets, sortBy]);

  // Handlers with useCallback for stable references
  const handleViewMyReservations = useCallback((ticket: TicketWithProject) => {
    const myReservations = ticket.reservations?.filter(
      r => r.investorId === CURRENT_USER_ID && r.state === 'active'
    ) || [];
    setSelectedTicketReservations(myReservations);
    setSelectedTicketInfo({ 
      ticketNumber: ticket.ticketNumber, 
      projectName: ticket.projectName 
    });
    setShowMyReservationsModal(true);
  }, []);

  const handleReservationClick = useCallback((reservationId: string) => {
    setShowMyReservationsModal(false);
    onViewReservationDetail?.(reservationId);
  }, [onViewReservationDetail]);

  const handleReserveTicket = useCallback((ticket: TicketWithProject) => {
    setSelectedTicketForReservation(ticket);
    setShowReservationFlow(true);
  }, []);

  const handleCloseReservationFlow = useCallback(() => {
    setShowReservationFlow(false);
    setSelectedTicketForReservation(null);
  }, []);

  return (
    <div className="space-y-6">
      {/* 1. CTA Cards - TOP */}
      <CTASection 
        onOpenAddInvestor={onOpenAddInvestor}
        onNewProject={onNewProject}
        onOpenDraftsPanel={onOpenDraftsPanel}
      />

      {/* 2. Search + Dropdown + Filter Icon */}
      <div className="flex items-center gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Hledat..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent"
          />
        </div>

        {/* Right side: Dropdown + Filter Icon */}
        <div className="flex items-center gap-2">
          {/* Dropdown "Všechny" */}
          <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg hover:bg-gray-50 transition-colors">
            <span className="text-sm text-[#040F2A]">Všechny</span>
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          </button>

          {/* Filter Icon */}
          <button className="w-10 h-10 flex items-center justify-center border border-border rounded-lg hover:bg-gray-50 transition-colors">
            <SlidersHorizontal className="w-4 h-4 text-[#040F2A]" />
          </button>
        </div>
      </div>

      {/* 3. Filter Panel */}
      <div className="bg-white rounded-lg border border-border px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Left: View Toggle + Filter Buttons */}
          <div className="flex items-center gap-4">
            {/* View Toggle */}
            <div className="flex items-center gap-2 text-sm text-[#040F2A]">
              <Grid3x3 className="w-4 h-4" />
              <span className="font-medium">Tabulkový výpis</span>
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleFilter('investice')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeFilters.investice
                    ? 'bg-[#215EF8] text-white'
                    : 'bg-gray-100 text-[#040F2A] hover:bg-gray-200'
                }`}
              >
                Investice
              </button>
              <button
                onClick={() => toggleFilter('vynos')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeFilters.vynos
                    ? 'bg-[#215EF8] text-white'
                    : 'bg-gray-100 text-[#040F2A] hover:bg-gray-200'
                }`}
              >
                Výnos
              </button>
              <button
                onClick={() => toggleFilter('delka')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeFilters.delka
                    ? 'bg-[#215EF8] text-white'
                    : 'bg-gray-100 text-[#040F2A] hover:bg-gray-200'
                }`}
              >
                Délka
              </button>
              <button
                onClick={() => toggleFilter('ltv')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeFilters.ltv
                    ? 'bg-[#215EF8] text-white'
                    : 'bg-gray-100 text-[#040F2A] hover:bg-gray-200'
                }`}
              >
                LTV
              </button>
              <button
                onClick={() => toggleFilter('provize')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeFilters.provize
                    ? 'bg-[#215EF8] text-white'
                    : 'bg-gray-100 text-[#040F2A] hover:bg-gray-200'
                }`}
              >
                Provize
              </button>
              <button
                onClick={() => toggleFilter('forma')}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeFilters.forma
                    ? 'bg-[#215EF8] text-white'
                    : 'bg-gray-100 text-[#040F2A] hover:bg-gray-200'
                }`}
              >
                Forma
              </button>
            </div>
          </div>

          {/* Right: Toggle "Otevřené" */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowOnlyOpen(!showOnlyOpen)}
              className={`relative w-11 h-6 rounded-full transition-colors ${
                showOnlyOpen ? 'bg-[#14AE6B]' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                  showOnlyOpen ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </button>
            <span className="text-sm font-medium text-[#040F2A]">
              Otevřené <span className="text-muted-foreground">({sortedTickets.length})</span>
            </span>
          </div>
        </div>
      </div>

      {/* Sort Options */}
      <div className="flex items-center justify-end">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Řadit podle:</span>
          <div className="flex gap-1 border border-border rounded-lg p-1">
            <SortButton
              active={sortBy === 'yield'}
              onClick={() => setSortBy('yield')}
              label="Výnos"
            />
            <SortButton
              active={sortBy === 'duration'}
              onClick={() => setSortBy('duration')}
              label="Délka"
            />
            <SortButton
              active={sortBy === 'amount'}
              onClick={() => setSortBy('amount')}
              label="Investice"
            />
          </div>
        </div>
      </div>

      {/* Table Control Bar */}
      <div className="bg-white border border-border rounded-lg px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-[#040F2A]">Zobrazit sloupce:</span>
          <div className="relative">
            <button
              onClick={() => setShowColumnsDropdown(!showColumnsDropdown)}
              className="flex items-center gap-2 px-3 py-1.5 border border-border rounded-lg hover:bg-gray-50 transition-colors text-sm text-[#040F2A]"
            >
              <Columns3 className="w-4 h-4" />
              <span>Sloupce</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${showColumnsDropdown ? 'rotate-180' : ''}`} />
            </button>
            
            {/* Columns Dropdown */}
            {showColumnsDropdown && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-border rounded-lg shadow-lg z-10 py-2">
                <div className="px-3 py-2 border-b border-border">
                  <p className="text-xs font-semibold text-[#040F2A] uppercase tracking-wide">Viditelnost sloupců</p>
                </div>
                <div className="py-1">
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.projekt}
                      onChange={() => toggleColumn('projekt')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Projekt</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.nazevId}
                      onChange={() => toggleColumn('nazevId')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Název / ID</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.investice}
                      onChange={() => toggleColumn('investice')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Investice</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.ltvZajisteni}
                      onChange={() => toggleColumn('ltvZajisteni')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">LTV / Zajištění</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.shody}
                      onChange={() => toggleColumn('shody')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Shody</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.aktivniRez}
                      onChange={() => toggleColumn('aktivniRez')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Aktivní rez.</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.sloutyOstatnich}
                      onChange={() => toggleColumn('sloutyOstatnich')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Sloty ostatních</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.provize}
                      onChange={() => toggleColumn('provize')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Provize</span>
                  </label>
                  <label className="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={visibleColumns.akce}
                      onChange={() => toggleColumn('akce')}
                      className="w-4 h-4 rounded border-border text-[#215EF8] focus:ring-[#215EF8]"
                    />
                    <span className="ml-3 text-sm text-[#040F2A]">Akce</span>
                  </label>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="text-sm text-[#6B7280]">
          {sortedTickets.length} {sortedTickets.length === 1 ? 'tiket' : sortedTickets.length < 5 ? 'tikety' : 'tiketů'}
        </div>
      </div>

      {/* Tickets Table */}
      <div className="bg-white rounded-lg overflow-hidden">
        {/* Table Header Row */}
        <div className="flex items-center gap-0.5 px-1 py-3 border-b border-border">
          <div className="w-[50px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Projekt
            </span>
          </div>
          <div className="w-[140px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Název / ID
            </span>
          </div>
          <div className="w-[130px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Investice
            </span>
          </div>
          <div className="w-[75px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              LTV / Zajištění
            </span>
          </div>
          <div className="w-[60px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Shody
            </span>
          </div>
          <div className="w-[70px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Aktivní rez.
            </span>
          </div>
          <div className="w-[75px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Sloty ostatních
            </span>
          </div>
          <div className="w-[115px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Provize
            </span>
          </div>
          <div className="w-[185px] flex-shrink-0">
            <span className="text-[10px] font-medium text-[#6B7280]">
              Akce
            </span>
          </div>
        </div>

        {/* Table Body */}
        {sortedTickets.map((ticket, index) => (
          <TicketRow
            key={`${ticket.projectId}-${ticket.id}`}
            ticket={ticket}
            isLast={index === sortedTickets.length - 1}
            onReserve={handleReserveTicket}
            onViewReservations={handleViewMyReservations}
            onViewProject={onViewProjectDetail}
          />
        ))}
      </div>

      {/* Empty State */}
      {sortedTickets.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Žádné tikety k zobrazení</p>
        </div>
      )}

      {/* My Reservations Modal */}
      {showMyReservationsModal && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" 
          onClick={() => setShowMyReservationsModal(false)}
        >
          <div 
            className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4" 
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-6 border-b border-border">
              <div>
                <h2 className="font-bold text-[#040F2A] text-lg">Moje rezervace</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {selectedTicketInfo?.projectName} • {selectedTicketInfo?.ticketNumber}
                </p>
              </div>
              <button
                onClick={() => setShowMyReservationsModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors"
                aria-label="Zavřít"
              >
                <X className="w-5 h-5 text-[#040F2A]" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
              {selectedTicketReservations.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Žádné aktivní rezervace</p>
              ) : (
                selectedTicketReservations.map((reservation, idx) => (
                  <button
                    key={reservation.id || idx}
                    onClick={() => handleReservationClick(reservation.id)}
                    className="w-full p-4 border border-border rounded-lg hover:border-[#215EF8] hover:bg-[#215EF8]/5 transition-colors text-left"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-[#040F2A]">Rezervace #{reservation.id || idx + 1}</span>
                      <span className="text-xs font-medium text-[#14AE6B] bg-[#14AE6B]/10 px-2 py-1 rounded">
                        {reservation.state}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-muted-foreground text-xs">Částka:</span>
                        <p className="font-medium text-[#040F2A]">
                          {formatCurrency(reservation.amount || 0)}
                        </p>
                      </div>
                      <div>
                        <span className="text-muted-foreground text-xs">Datum vytvoření:</span>
                        <p className="font-medium text-[#040F2A]">{reservation.createdAt || 'N/A'}</p>
                      </div>
                    </div>
                    <p className="text-xs text-[#215EF8] mt-3 font-medium">Klikněte pro detail →</p>
                  </button>
                ))
              )}
            </div>

            <div className="flex items-center justify-end gap-3 p-6 border-t border-border">
              <button
                onClick={() => setShowMyReservationsModal(false)}
                className="px-4 py-2 rounded-lg border border-border hover:bg-gray-50 transition-colors text-sm font-medium text-[#040F2A]"
              >
                Zavřít
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reservation Flow Modal */}
      {showReservationFlow && selectedTicketForReservation && (
        <ReservationFlow
          isOpen={showReservationFlow}
          onClose={handleCloseReservationFlow}
          ticket={selectedTicketForReservation}
          projectName={selectedTicketForReservation.projectName}
          projectId={selectedTicketForReservation.projectId}
        />
      )}
    </div>
  );
}