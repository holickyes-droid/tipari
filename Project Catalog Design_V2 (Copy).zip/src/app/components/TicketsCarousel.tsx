import { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';

interface TicketsCarouselProps {
  totalTickets: number;
  availableTickets: number;
  lastSlotTickets: number;
  fullTickets: number;
  currentIndex: number;
  onIndexChange: (index: number) => void;
}

export function TicketsCarousel({
  totalTickets,
  availableTickets,
  lastSlotTickets,
  fullTickets,
  currentIndex,
  onIndexChange,
}: TicketsCarouselProps) {
  const canScrollLeft = currentIndex > 0;
  const canScrollRight = currentIndex < totalTickets - 1;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Tiket {currentIndex + 1} / {totalTickets}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onIndexChange(currentIndex - 1)}
            disabled={!canScrollLeft}
            className="w-8 h-8 p-0"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onIndexChange(currentIndex + 1)}
            disabled={!canScrollRight}
            className="w-8 h-8 p-0"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Visual indicator */}
      <div className="flex items-center gap-1.5">
        {Array.from({ length: totalTickets }).map((_, index) => {
          let bgColor = 'bg-muted';
          if (index < availableTickets) {
            bgColor = 'bg-[#14AE6B]';
          } else if (index < availableTickets + lastSlotTickets) {
            bgColor = 'bg-orange-500';
          } else {
            bgColor = 'bg-muted-foreground/30';
          }

          return (
            <button
              key={index}
              onClick={() => onIndexChange(index)}
              className={`h-1.5 rounded-full transition-all ${
                index === currentIndex ? 'w-8' : 'w-1.5'
              } ${bgColor} ${index === currentIndex ? 'opacity-100' : 'opacity-60 hover:opacity-80'}`}
              aria-label={`Přejít na tiket ${index + 1}`}
            />
          );
        })}
      </div>

      {/* Status legend */}
      <div className="flex items-center gap-4 text-xs text-muted-foreground pt-1">
        {availableTickets > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[#14AE6B]" />
            <span>Dostupné ({availableTickets})</span>
          </div>
        )}
        {lastSlotTickets > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-orange-500" />
            <span>Poslední slot ({lastSlotTickets})</span>
          </div>
        )}
        {fullTickets > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-muted-foreground/30" />
            <span>Obsazeno ({fullTickets})</span>
          </div>
        )}
      </div>
    </div>
  );
}
