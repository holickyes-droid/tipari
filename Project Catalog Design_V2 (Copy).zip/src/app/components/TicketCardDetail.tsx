import { Shield } from 'lucide-react';
import { Ticket } from '../types/project';
import { Button } from './ui/button';

interface TicketCardDetailProps {
  ticket: Ticket;
  ticketNumber: number;
  projectStatus: 'Open' | 'Fully reserved' | 'Paused' | 'Finished';
}

export function TicketCardDetail({ ticket, ticketNumber, projectStatus }: TicketCardDetailProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('cs-CZ', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getRecommendationBadge = () => {
    if (!ticket.recommendation) return null;
    
    switch (ticket.recommendation) {
      case 'Nejlepší':
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-[#14AE6B]/10 text-[#14AE6B] border border-[#14AE6B]/20">
            ⭐ {ticket.recommendation}
          </div>
        );
      case 'Vhodný':
        return (
          <div className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
            {ticket.recommendation}
          </div>
        );
      default:
        return null;
    }
  };

  // Get status color for left border
  const getStatusColor = () => {
    switch (projectStatus) {
      case 'Open':
        return 'border-l-[#14AE6B]'; // Green for active/open
      case 'Paused':
        return 'border-l-amber-500'; // Orange for paused
      case 'Fully reserved':
        return 'border-l-[#215EF8]'; // Blue for fully reserved
      case 'Finished':
        return 'border-l-gray-400'; // Gray for finished
      default:
        return 'border-l-gray-300';
    }
  };

  // Výpočet CTA logiky
  const isReservationDisabled = projectStatus !== 'Open' || ticket.occupancy.current >= ticket.occupancy.total;
  const availableSlots = ticket.occupancy.total - ticket.occupancy.current;
  
  // Počet investor count
  const investorCount = ticket.occupancy.current;

  return (
    <div className={`bg-gray-50 rounded-xl border border-border border-l-[6px] ${getStatusColor()} overflow-hidden transition-shadow duration-300 hover:shadow-lg`}>
      <div className="p-6">
        {/* Header with Ticket Number */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="bg-white border border-border rounded-lg px-4 py-2">
              <div className="text-xs text-muted-foreground mb-0.5">Tiket</div>
              <div className="text-xl font-bold text-[#040F2A]">{ticketNumber}</div>
            </div>
            {getRecommendationBadge()}
          </div>
        </div>

        {/* Ticket Details Grid */}
        <div className="grid grid-cols-2 gap-x-6 gap-y-4 mb-6">
          {/* Výše (CZK) */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Výše (CZK)</div>
            <div className="font-semibold text-[#040F2A]">{formatCurrency(ticket.investmentAmount)}</div>
          </div>

          {/* LTV */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">LTV</div>
            <div className="inline-flex items-center px-2.5 py-1 rounded-md text-sm font-semibold bg-[#14AE6B]/10 text-[#14AE6B]">
              {ticket.ltv}%
            </div>
          </div>

          {/* Výnos (p.a.) */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Výnos (p.a.)</div>
            <div className="font-semibold text-[#040F2A]">{ticket.yield}%</div>
          </div>

          {/* Podíl na HV */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Podíl na (HV)</div>
            <div className="font-semibold text-[#040F2A]">
              {ticket.profitSharing && ticket.profitSharing !== 'Ne' 
                ? typeof ticket.profitSharing === 'string' 
                  ? ticket.profitSharing 
                  : `${ticket.profitSharing.percentage}%`
                : '—'
              }
            </div>
          </div>

          {/* Délka */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Délka</div>
            <div className="font-semibold text-[#040F2A]">{ticket.duration} měsíců</div>
          </div>

          {/* Forma */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Forma</div>
            <div className="font-semibold text-[#040F2A]">{ticket.investmentForm}</div>
          </div>

          {/* Zajištění */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Zajištění</div>
            <div>
              {ticket.secured ? (
                <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-[#14AE6B]/10 text-[#14AE6B]">
                  ANO
                </span>
              ) : (
                <span className="text-sm text-muted-foreground">NE</span>
              )}
            </div>
          </div>

          {/* Odměna (CZK) */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Odměna (CZK)</div>
            <div className="font-semibold text-[#14AE6B]">
              {formatCurrency((ticket.investmentAmount * ticket.commission) / 100)} Kč
            </div>
          </div>

          {/* Rezervací */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Rezervací</div>
            <div className="font-semibold text-[#040F2A]">
              {ticket.occupancy.current} / {ticket.occupancy.total}
            </div>
          </div>

          {/* Doporučeno */}
          <div>
            <div className="text-xs text-muted-foreground mb-1">Doporučeno</div>
            <div>
              {investorCount > 0 ? (
                <button className="text-sm font-medium text-[#215EF8] hover:underline">
                  {investorCount} {investorCount === 1 ? 'investor' : investorCount < 5 ? 'investoři' : 'investorů'}
                </button>
              ) : (
                <span className="text-sm text-muted-foreground">—</span>
              )}
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <Button
          className="w-full bg-[#14AE6B] hover:bg-[#0D7A4A] text-white disabled:bg-gray-300 disabled:text-gray-500"
          disabled={isReservationDisabled}
        >
          {isReservationDisabled 
            ? 'Nedostupné' 
            : `Rezervovat (${availableSlots} / ${ticket.occupancy.total})`
          }
        </Button>
      </div>
    </div>
  );
}