/**
 * TICKET DETAIL PAGE
 * Full page view of ticket details with reservation CTA
 */

import { ArrowLeft, Calendar, MapPin, TrendingUp, Shield, Clock, Users, Building2, FileText, Ticket } from 'lucide-react';
import { calculateSecurityScore, type SecurityType } from '../utils/securityScoring';

interface TicketData {
  id: string;
  projectName: string;
  projectImage: string;
  investmentAmount: number;
  investmentType: 'Ekvita' | 'Zápůjčka' | 'Mezanin';
  yieldPercent: number;
  ltvPercent?: number;
  duration: string;
  security: SecurityType;
  commissionAmount: number;
  slotsAvailable: number;
  slotsTotal: number;
  reservedByOthers: number;
  slaDaysRemaining: number;
  location: string;
}

interface TicketDetailPageProps {
  ticket: TicketData;
  onBack: () => void;
  onReserve: (ticketId: string) => void;
  userSlotsAvailable: number;
}

export function TicketDetailPage({ ticket, onBack, onReserve, userSlotsAvailable }: TicketDetailPageProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('cs-CZ', {
      style: 'decimal',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getRiskColor = (security: SecurityType) => {
    const score = calculateSecurityScore(security);
    if (score >= 80) return 'text-[#14AE6B] bg-[#14AE6B]/10';
    if (score >= 50) return 'text-amber-600 bg-amber-50';
    return 'text-red-600 bg-red-50';
  };

  const getSLAColor = (days: number) => {
    if (days <= 14) return 'text-red-600 bg-red-50';
    if (days <= 60) return 'text-amber-600 bg-amber-50';
    return 'text-gray-600 bg-gray-50';
  };

  const canReserve = ticket.slotsAvailable > 0 && userSlotsAvailable > 0;

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Back button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-[#215EF8] transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-sm font-medium">Zpět na tikety</span>
        </button>

        <div className="grid grid-cols-3 gap-6">
          {/* Left column - Main content */}
          <div className="col-span-2 space-y-6">
            {/* Hero section */}
            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              <img
                src={ticket.projectImage}
                alt={ticket.projectName}
                className="w-full h-80 object-cover"
              />
              <div className="p-8">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-3xl font-bold text-[#040F2A] mb-2">{ticket.projectName}</h1>
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{ticket.location}</span>
                    </div>
                  </div>
                  <span className="px-4 py-2 rounded-lg bg-blue-50 text-blue-700 text-sm font-semibold">
                    {ticket.investmentType}
                  </span>
                </div>

                {/* Key metrics */}
                <div className="grid grid-cols-4 gap-4 pt-6 border-t border-gray-200">
                  <div>
                    <p className="text-xs text-gray-600 mb-1">Investice</p>
                    <p className="text-xl font-bold text-[#040F2A]">{formatCurrency(ticket.investmentAmount)} Kč</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 mb-1">Výnos</p>
                    <p className="text-xl font-bold text-[#14AE6B]">{ticket.yieldPercent}%</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 mb-1">Provize</p>
                    <p className="text-xl font-bold text-[#14AE6B]">{formatCurrency(ticket.commissionAmount)} Kč</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 mb-1">Délka</p>
                    <p className="text-base font-semibold text-gray-900">{ticket.duration}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed information */}
            <div className="bg-white rounded-2xl border border-gray-200 p-8">
              <h2 className="text-xl font-bold text-[#040F2A] mb-6">Detailní informace</h2>
              
              <div className="space-y-6">
                {/* Investment details */}
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">Investiční parametry</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
                      <TrendingUp className="w-5 h-5 text-[#14AE6B]" />
                      <div>
                        <p className="text-xs text-gray-600">Očekávaný výnos</p>
                        <p className="text-base font-bold text-[#040F2A]">{ticket.yieldPercent}% p.a.</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
                      <Shield className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="text-xs text-gray-600">Zajištění</p>
                        <p className="text-sm font-semibold text-gray-900">{ticket.security}</p>
                      </div>
                    </div>
                    {ticket.ltvPercent && (
                      <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
                        <FileText className="w-5 h-5 text-amber-600" />
                        <div>
                          <p className="text-xs text-gray-600">LTV</p>
                          <p className="text-base font-bold text-[#040F2A]">{ticket.ltvPercent}%</p>
                        </div>
                      </div>
                    )}
                    <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
                      <Calendar className="w-5 h-5 text-purple-600" />
                      <div>
                        <p className="text-xs text-gray-600">Doba trvání</p>
                        <p className="text-sm font-semibold text-gray-900">{ticket.duration}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Project description */}
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">O projektu</h3>
                  <div className="prose prose-sm text-gray-600">
                    <p>
                      Tento projekt představuje atraktivní investiční příležitost v oblasti {ticket.location} 
                      s očekávaným výnosem {ticket.yieldPercent}% ročně. Investice je zajištěna {ticket.security.toLowerCase()}.
                    </p>
                    <p className="mt-3">
                      Jedná se o typ investice: <strong>{ticket.investmentType}</strong> s dobou trvání {ticket.duration}.
                      Developer má zkušenosti s realizací podobných projektů v regionu.
                    </p>
                  </div>
                </div>

                {/* Developer info */}
                <div>
                  <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">Developer</h3>
                  <div className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#215EF8] to-[#1B4FD1] flex items-center justify-center">
                      <Building2 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">Development Group s.r.o.</p>
                      <p className="text-xs text-gray-600">15+ let zkušeností • 50+ realizovaných projektů</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right column - Reservation panel */}
          <div className="space-y-6">
            {/* Reservation CTA */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 sticky top-6">
              <div className="space-y-6">
                {/* Availability */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-semibold text-gray-700">Dostupnost slotů</span>
                    <span className={`px-2.5 py-1 rounded-md text-xs font-semibold ${getSLAColor(ticket.slaDaysRemaining)}`}>
                      SLA: {ticket.slaDaysRemaining} dnů
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex items-center gap-1">
                      {Array.from({ length: ticket.slotsTotal }).map((_, i) => (
                        <div
                          key={i}
                          className={`w-3 h-3 rounded-full ${
                            i < ticket.slotsAvailable ? 'bg-[#14AE6B]' : 'bg-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm font-semibold text-gray-700">
                      {ticket.slotsAvailable}/{ticket.slotsTotal} volných
                    </span>
                  </div>

                  {ticket.reservedByOthers > 0 && (
                    <div className="flex items-center gap-2 text-xs text-gray-600 border border-gray-200 px-3 py-2 rounded-lg">
                      <Users className="w-4 h-4" />
                      <span>
                        {ticket.reservedByOthers} Tipar{ticket.reservedByOthers > 1 ? 'ů' : ''} již rezervoval{ticket.reservedByOthers > 1 ? 'o' : ''}
                      </span>
                    </div>
                  )}
                </div>

                {/* Security badge */}
                <div className={`px-4 py-3 rounded-lg ${getRiskColor(ticket.security)}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <Shield className="w-4 h-4" />
                    <span className="text-xs font-semibold uppercase">Zajištění</span>
                  </div>
                  <p className="text-sm font-bold">{ticket.security}</p>
                </div>

                {/* Commission highlight */}
                <div className="bg-gradient-to-br from-[#14AE6B]/5 to-[#14AE6B]/0 border border-[#14AE6B]/20 rounded-xl p-4">
                  <p className="text-xs text-gray-600 mb-1">Vaše provize</p>
                  <p className="text-2xl font-bold text-[#14AE6B]">{formatCurrency(ticket.commissionAmount)} Kč</p>
                  <p className="text-xs text-gray-600 mt-2">Po úspěšném uzavření investice</p>
                </div>

                {/* Reserve button */}
                <button
                  onClick={() => onReserve(ticket.id)}
                  disabled={!canReserve}
                  className={`w-full py-4 rounded-xl text-base font-semibold transition-all flex items-center justify-center gap-2 ${
                    canReserve
                      ? 'bg-gradient-to-r from-[#215EF8] to-[#1B4FD1] text-white hover:shadow-lg hover:shadow-[#215EF8]/30'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <Ticket className="w-5 h-5" />
                  {canReserve ? 'Rezervovat tiket' : 'Nedostupné'}
                </button>

                {!canReserve && userSlotsAvailable === 0 && (
                  <p className="text-xs text-center text-red-600">
                    Nemáte volné sloty pro rezervaci
                  </p>
                )}
                {!canReserve && ticket.slotsAvailable === 0 && (
                  <p className="text-xs text-center text-red-600">
                    Všechny sloty jsou obsazeny
                  </p>
                )}

                {/* Info note */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-xs text-blue-800">
                    <strong>Rezervace ≠ Investice:</strong> Rezervací získáváte právo vyjednávat s developerem. 
                    Není to závazek k investici.
                  </p>
                </div>
              </div>
            </div>

            {/* Additional info */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-amber-900 mb-1">SLA termín</h4>
                  <p className="text-xs text-amber-800">
                    Pokud do {ticket.slaDaysRemaining} dnů nevyužijete rezervaci, slot se automaticky uvolní.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}