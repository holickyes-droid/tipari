export function TicketsTableSkeleton() {
  return (
    <div className="space-y-4">
      <div className="overflow-hidden border border-border rounded-lg">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-muted/30">
              <th className="text-left px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Ticket
              </th>
              <th className="text-right px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Výše investice
              </th>
              <th className="text-right px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Výnos p.a.
              </th>
              <th className="text-right px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Doba trvání
              </th>
              <th className="text-center px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                LTV
              </th>
              <th className="text-center px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Zajištěno
              </th>
              <th className="text-right px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Provize
              </th>
              <th className="text-right px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Obsazenost
              </th>
              <th className="text-center px-4 py-3 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                Doporučení
              </th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {[1, 2, 3].map((index) => (
              <tr
                key={index}
                className={`bg-white ${index < 3 ? 'border-b border-border' : ''}`}
              >
                {/* Ticket Number */}
                <td className="px-4 py-5">
                  <div className="h-4 w-16 bg-muted/30 rounded animate-pulse" />
                </td>
                
                {/* Investment Amount */}
                <td className="px-4 py-5 text-right">
                  <div className="h-5 w-32 bg-muted/30 rounded ml-auto animate-pulse" />
                </td>
                
                {/* Yield */}
                <td className="px-4 py-5 text-right">
                  <div className="h-5 w-16 bg-muted/30 rounded ml-auto animate-pulse" />
                </td>
                
                {/* Duration */}
                <td className="px-4 py-5 text-right">
                  <div className="h-5 w-24 bg-muted/30 rounded ml-auto animate-pulse" />
                </td>
                
                {/* LTV */}
                <td className="px-4 py-5 text-center">
                  <div className="h-4 w-12 bg-muted/30 rounded mx-auto animate-pulse" />
                </td>
                
                {/* Secured */}
                <td className="px-4 py-5 text-center">
                  <div className="h-2.5 w-2.5 bg-muted/30 rounded-full mx-auto animate-pulse" />
                </td>
                
                {/* Commission */}
                <td className="px-4 py-5 text-right">
                  <div className="h-5 w-16 bg-muted/30 rounded ml-auto animate-pulse" />
                </td>
                
                {/* Occupancy */}
                <td className="px-4 py-5 text-right">
                  <div className="h-4 w-12 bg-muted/30 rounded ml-auto animate-pulse" />
                </td>
                
                {/* Recommendations */}
                <td className="px-4 py-5 text-center">
                  <div className="h-4 w-8 bg-muted/30 rounded mx-auto animate-pulse" />
                </td>
                
                {/* CTA Button */}
                <td className="px-4 py-5">
                  <div className="h-8 w-28 bg-muted/30 rounded ml-auto animate-pulse" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
