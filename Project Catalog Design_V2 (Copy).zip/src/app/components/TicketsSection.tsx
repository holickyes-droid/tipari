import { useState, useEffect } from 'react';
import { AlertCircle, ChevronDown, ChevronUp, Users, CheckCircle, Clock, Coins, CalendarCheck, HelpCircle, CheckCircle2, XCircle, Briefcase, Shield, FileCheck, UserCheck, Download, Timer, Eye } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { SLACountdown } from './SLACountdown';
import { ReservationFlow } from './ReservationFlow';
import clientMatchesIcon from 'figma:asset/5f53ead4646eaa97e73c20dedfc4aee34b30ea18.png';
import coinsIcon from 'figma:asset/c8948b78570fce52b189608d12db8512d73bb1cd.png';

type TicketType = 'Senior' | 'Mezzanine' | 'Junior' | 'Majoritní ekvita' | 'Minoritní ekvita' | 'Prodej projektu' | 'Zpětný leasing';

type InvestmentForm = 'Zápůjčka' | 'Majoritní ekvita' | 'Minoritní ekvita' | 'Prodej projektu' | 'Zpětný leasing' | 'Mezaninové financování';

type SecurityType = 
  | 'Zástava 1. pořadí'
  | 'Zástava 2. pořadí'
  | 'Zástava k OP, KL, Akcie'
  | 'Osobní směnka'
  | 'Firemní směnka'
  | 'Notářský zápis'
  | 'Notářský zápis s přímou vykonatelností'
  | 'Ručitelský závazek'
  | 'Postoupení pohledávek'
  | 'Zástava movitých věcí'
  | 'Zajištění nájmů'
  | 'Převedení vlastnictví se zpětným odkupem'
  | 'Zajišťovací blankosměnka'
  | 'Bez zajištění';

type AppraisalType = 'Vlastní' | 'Externí' | 'Ne';

interface Ticket {
  id: string;
  type: TicketType;
  tranche: string;
  amount: number;
  duration: number;
  yieldPa: number;
  payoutStructure: string;
  investmentForm: InvestmentForm;
  securityTypes: SecurityType[];
  ltv: number;
  commissionCzk: number;
  profitShare: boolean;
  hasCollateral: boolean;
  collateralDetails?: string;
  collateralValue?: number;
  appraisalType: AppraisalType;
  appraiserName?: string;
  appraiserCompany?: string;
  appraiserWebsite?: string;
  appraisalDocumentUrl?: string;
  myGlobalSlotsUsed: number;
  myActiveReservations: number;
  otherGlobalSlotsUsed: number;
  otherActiveReservations: number;
  clientMatches: number;
  matchingClients?: Array<{ 
    name: string; 
    initials: string;
    type: string;
    amount: number; 
    matchScore: number;
    portfolioUsed: number;
    portfolioTotal: number;
  }>;
  projectName?: string;
  expiresAt: number; // timestamp
  currentViewers: number; // kolik makléřů právě prohlíží tiket
}

const mockTickets: Ticket[] = [
  {
    id: 'T-001',
    type: 'Senior',
    tranche: 'Tranche A - nejvyšší priorita',
    amount: 125000000,
    duration: 24,
    yieldPa: 8.5,
    payoutStructure: 'Čtvrtletně',
    investmentForm: 'Zápůjčka',
    securityTypes: ['Zástava 1. pořadí'],
    ltv: 50,
    commissionCzk: 175000,
    profitShare: false,
    hasCollateral: true,
    collateralValue: 250000000,
    collateralDetails: 'Zástavní právo I. řádu k bytovým jednotkám v 1. a 2. NP',
    appraisalType: 'Externí',
    appraiserName: 'Ing. František Omáčka',
    appraiserCompany: 'Odhadní kancelář soudního znalce Franty Omáčky',
    appraiserWebsite: 'www.frantaomacka.cz',
    appraisalDocumentUrl: '/documents/appraisal-t001.pdf',
    myGlobalSlotsUsed: 0,
    myActiveReservations: 0,
    otherGlobalSlotsUsed: 1,
    otherActiveReservations: 2,
    clientMatches: 3,
    projectName: 'Rezidence Nová Vinohrady',
    matchingClients: [
      { name: 'Petr Novák', initials: 'PN', type: 'Fyzická osoba', amount: 5000000, matchScore: 92, portfolioUsed: 0, portfolioTotal: 3 },
      { name: 'Jana Novotná', initials: 'JN', type: 'Fyzická osoba', amount: 10000000, matchScore: 88, portfolioUsed: 1, portfolioTotal: 2 },
      { name: 'Martin Král', initials: 'MK', type: 'Fyzická osoba', amount: 8000000, matchScore: 76, portfolioUsed: 2, portfolioTotal: 2 },
    ],
    expiresAt: Math.floor(Date.now() / 1000) + (18 * 60 * 60), // 18 hours - CRITICAL (red)
    currentViewers: 2,
  },
  {
    id: 'T-002',
    type: 'Senior',
    tranche: 'Tranche A - nejvyšší priorita',
    amount: 125000000,
    duration: 24,
    yieldPa: 8.5,
    payoutStructure: 'Čtvrtletně',
    investmentForm: 'Zápůjčka',
    securityTypes: ['Zástava 1. pořadí'],
    ltv: 50,
    commissionCzk: 175000,
    profitShare: false,
    hasCollateral: true,
    collateralValue: 250000000,
    collateralDetails: 'Zástavní právo I. řádu k bytovým jednotkám ve 3. a 4. NP',
    appraisalType: 'Externí',
    appraiserName: 'Ing. František Omáčka',
    appraiserCompany: 'Odhadní kancelář soudního znalce Franty Omáčky',
    appraiserWebsite: 'www.frantaomacka.cz',
    appraisalDocumentUrl: '/documents/appraisal-t002.pdf',
    myGlobalSlotsUsed: 1,
    myActiveReservations: 2,
    otherGlobalSlotsUsed: 0,
    otherActiveReservations: 1,
    clientMatches: 4,
    projectName: 'Rezidence Nová Vinohrady',
    matchingClients: [
      { name: 'Marie Svobodová', initials: 'MS', type: 'Právnická osoba', amount: 4000000, matchScore: 85, portfolioUsed: 1, portfolioTotal: 3 },
      { name: 'Jana Novotná', initials: 'JN', type: 'Fyzická osoba', amount: 7000000, matchScore: 82, portfolioUsed: 0, portfolioTotal: 3 },
      { name: 'Petr Novák', initials: 'PN', type: 'Fyzická osoba', amount: 5500000, matchScore: 79, portfolioUsed: 2, portfolioTotal: 3 },
      { name: 'Martin Král', initials: 'MK', type: 'Fyzická osoba', amount: 9000000, matchScore: 73, portfolioUsed: 1, portfolioTotal: 2 },
    ],
    expiresAt: Math.floor(Date.now() / 1000) + (2 * 24 * 60 * 60) + (14 * 60 * 60), // 2 days 14 hours - WARNING (orange)
    currentViewers: 1,
  },
  {
    id: 'T-003',
    type: 'Senior',
    tranche: 'Tranche A - nejvyšší priorita',
    amount: 125000000,
    duration: 24,
    yieldPa: 8.5,
    payoutStructure: 'Čtvrtletně',
    investmentForm: 'Zápůjčka',
    securityTypes: ['Zástava 1. pořadí'],
    ltv: 50,
    commissionCzk: 175000,
    profitShare: false,
    hasCollateral: true,
    collateralValue: 250000000,
    collateralDetails: 'Zástavní právo I. řádu k bytovým jednotkám v 5. NP',
    appraisalType: 'Externí',
    appraiserName: 'Ing. František Omáčka',
    appraiserCompany: 'Odhadní kancelář soudního znalce Franty Omáčky',
    appraiserWebsite: 'www.frantaomacka.cz',
    appraisalDocumentUrl: '/documents/appraisal-t003.pdf',
    myGlobalSlotsUsed: 0,
    myActiveReservations: 0,
    otherGlobalSlotsUsed: 2,
    otherActiveReservations: 1,
    clientMatches: 2,
    projectName: 'Rezidence Nová Vinohrady',
    matchingClients: [
      { name: 'Karel Bílý', initials: 'KB', type: 'Privátní investor', amount: 8000000, matchScore: 81, portfolioUsed: 0, portfolioTotal: 3 },
      { name: 'Eva Zelená', initials: 'EZ', type: 'Family office', amount: 6000000, matchScore: 78, portfolioUsed: 1, portfolioTotal: 3 },
    ],
    expiresAt: Math.floor(Date.now() / 1000) + (5 * 24 * 60 * 60) + (8 * 60 * 60), // 5 days 8 hours - GOOD (green)
    currentViewers: 0,
  },
  {
    id: 'T-004',
    type: 'Mezzanine',
    tranche: 'Mezaninový kapitál',
    amount: 125000000,
    duration: 24,
    yieldPa: 10.5,
    payoutStructure: 'Při splatnosti',
    investmentForm: 'Mezaninové financování',
    securityTypes: ['Zástava 2. pořadí'],
    ltv: 50,
    commissionCzk: 210000,
    profitShare: false,
    hasCollateral: true,
    collateralValue: 1000000000,
    collateralDetails: 'Zástavní právo II. řádu ke všem bytovým jednotkám',
    appraisalType: 'Externí',
    appraiserName: 'Ing. František Omáčka',
    appraiserCompany: 'Odhadní kancelář soudního znalce Franty Omáčky',
    appraiserWebsite: 'www.frantaomacka.cz',
    appraisalDocumentUrl: '/documents/appraisal-t004.pdf',
    myGlobalSlotsUsed: 0,
    myActiveReservations: 0,
    otherGlobalSlotsUsed: 0,
    otherActiveReservations: 0,
    clientMatches: 1,
    projectName: 'Rezidence Nová Vinohrady',
    matchingClients: [
      { name: 'David Šedý', initials: 'DŠ', type: 'Privátní investor', amount: 3000000, matchScore: 68, portfolioUsed: 2, portfolioTotal: 3 },
    ],
    expiresAt: Math.floor(Date.now() / 1000) + (6 * 24 * 60 * 60) + (20 * 60 * 60), // 6 days 20 hours - GOOD (green)
    currentViewers: 0,
  },
];

type AvailabilityFilter = 'all' | 'available' | 'my-reservations';

export function TicketsSection() {
  const [showFiltersPanel, setShowFiltersPanel] = useState(false);
  const [availabilityFilter, setAvailabilityFilter] = useState<AvailabilityFilter>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [expandedTicket, setExpandedTicket] = useState<string | null>(null);
  const [clientMatchesModal, setClientMatchesModal] = useState<string | null>(null);
  const [tooltipActive, setTooltipActive] = useState<{ type: string; id: string } | null>(null);
  const [reservationFlowTicket, setReservationFlowTicket] = useState<Ticket | null>(null);
  
  const [amountRange, setAmountRange] = useState<string>('all');
  const [durationRange, setDurationRange] = useState<string>('all');
  const [yieldRange, setYieldRange] = useState<string>('all');
  const [collateralFilter, setCollateralFilter] = useState<string>('all');
  const [profitShareFilter, setProfitShareFilter] = useState<string>('all');
  const [ltvRange, setLtvRange] = useState<string>('all');
  const [commissionRange, setCommissionRange] = useState<string>('all');
  const [clientMatchesFilter, setClientMatchesFilter] = useState<string>('all');

  const resetAllFilters = () => {
    setAvailabilityFilter('all');
    setSelectedType('all');
    setAmountRange('all');
    setDurationRange('all');
    setYieldRange('all');
    setCollateralFilter('all');
    setProfitShareFilter('all');
    setLtvRange('all');
    setCommissionRange('all');
    setClientMatchesFilter('all');
  };

  const hasActiveFilters = () => {
    return availabilityFilter !== 'all' ||
           selectedType !== 'all' ||
           amountRange !== 'all' ||
           durationRange !== 'all' ||
           yieldRange !== 'all' ||
           collateralFilter !== 'all' ||
           profitShareFilter !== 'all' ||
           ltvRange !== 'all' ||
           commissionRange !== 'all' ||
           clientMatchesFilter !== 'all';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('cs-CZ', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatCurrencyCompact = (amount: number) => {
    if (amount >= 1000000) {
      return `${(amount / 1000000).toFixed(0)} mil. Kč`;
    }
    return formatCurrency(amount) + ' Kč';
  };

  const getClientMatchText = (count: number): string => {
    if (count === 1) return 'klient';
    if (count >= 2 && count <= 4) return 'klienty';
    return 'klientů';
  };

  const getTypeLabel = (type: string): string => {
    if (type === 'all') return 'Všechny typy';
    return type;
  };

  const canReserve = (ticket: Ticket): boolean => {
    const totalActiveReservations = ticket.myActiveReservations + ticket.otherActiveReservations;
    return totalActiveReservations < 3;
  };

  const filteredTickets = mockTickets.filter(ticket => {
    if (availabilityFilter === 'available' && !canReserve(ticket)) return false;
    if (availabilityFilter === 'my-reservations' && ticket.myActiveReservations === 0 && ticket.myGlobalSlotsUsed === 0) return false;
    if (selectedType !== 'all' && ticket.type !== selectedType) return false;
    
    if (amountRange !== 'all') {
      const amountM = ticket.amount / 1000000;
      if (amountRange === '0-10m' && amountM > 10) return false;
      if (amountRange === '10m-30m' && (amountM < 10 || amountM > 30)) return false;
      if (amountRange === '30m+' && amountM < 30) return false;
    }
    
    if (durationRange !== 'all') {
      if (durationRange === '0-18' && ticket.duration > 18) return false;
      if (durationRange === '18-24' && (ticket.duration < 18 || ticket.duration > 24)) return false;
      if (durationRange === '24+' && ticket.duration < 24) return false;
    }
    
    if (yieldRange !== 'all') {
      if (yieldRange === '0-8' && ticket.yieldPa > 8) return false;
      if (yieldRange === '8-12' && (ticket.yieldPa < 8 || ticket.yieldPa > 12)) return false;
      if (yieldRange === '12+' && ticket.yieldPa < 12) return false;
    }
    
    if (collateralFilter !== 'all') {
      if (collateralFilter === 'yes' && !ticket.hasCollateral) return false;
      if (collateralFilter === 'no' && ticket.hasCollateral) return false;
    }
    
    if (profitShareFilter !== 'all') {
      if (profitShareFilter === 'yes' && !ticket.profitShare) return false;
      if (profitShareFilter === 'no' && ticket.profitShare) return false;
    }
    
    if (ltvRange !== 'all') {
      if (ltvRange === '0-50' && ticket.ltv > 50) return false;
      if (ltvRange === '50-70' && (ticket.ltv < 50 || ticket.ltv > 70)) return false;
      if (ltvRange === '70+' && ticket.ltv < 70) return false;
    }
    
    if (commissionRange !== 'all') {
      const commissionK = ticket.commissionCzk / 1000;
      if (commissionRange === '0-100k' && commissionK > 100) return false;
      if (commissionRange === '100k-200k' && (commissionK < 100 || commissionK > 200)) return false;
      if (commissionRange === '200k+' && commissionK < 200) return false;
    }
    
    if (clientMatchesFilter !== 'all') {
      if (clientMatchesFilter === 'high' && ticket.clientMatches < 5) return false;
      if (clientMatchesFilter === 'medium' && (ticket.clientMatches < 2 || ticket.clientMatches > 4)) return false;
      if (clientMatchesFilter === 'low' && ticket.clientMatches !== 1) return false;
      if (clientMatchesFilter === 'none' && ticket.clientMatches > 0) return false;
    }
    
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600">
          Zobrazeno <span className="font-semibold text-[#040F2A]">{filteredTickets.length}</span> {filteredTickets.length === 1 ? 'tiket' : filteredTickets.length < 5 ? 'tikety' : 'tiketů'}
        </p>

        <div className="flex items-center gap-3">
          <Select value={selectedType} onValueChange={(value) => setSelectedType(value)}>
            <SelectTrigger className="border-0 shadow-none bg-transparent px-0 py-0 h-auto gap-1.5 text-sm hover:text-[#215EF8] w-auto">
              <SelectValue>{getTypeLabel(selectedType)}</SelectValue>
            </SelectTrigger>
            <SelectContent align="end">
              <SelectItem value="all">Všechny typy</SelectItem>
              <SelectItem value="Senior">Senior</SelectItem>
              <SelectItem value="Mezzanine">Mezzanine</SelectItem>
              <SelectItem value="Junior">Junior</SelectItem>
              <SelectItem value="Majoritní ekvita">Majoritní ekvita</SelectItem>
              <SelectItem value="Minoritní ekvita">Minoritní ekvita</SelectItem>
              <SelectItem value="Prodej projektu">Prodej projektu</SelectItem>
              <SelectItem value="Zpětný leasing">Zpětný leasing</SelectItem>
            </SelectContent>
          </Select>

          <button
            onClick={() => setShowFiltersPanel(!showFiltersPanel)}
            className="p-2.5 border border-gray-200 hover:bg-gray-50 rounded-lg transition-colors"
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 6H17" stroke="#040F2A" strokeWidth="1.5" strokeLinecap="round"/>
              <path d="M6 10H14" stroke="#040F2A" strokeWidth="1.5" strokeLinecap="round"/>
              <path d="M8 14H12" stroke="#040F2A" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </button>
        </div>
      </div>

      {showFiltersPanel && (
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-[#040F2A]">Pokročilé filtry</h3>
            <div className="flex items-center gap-3">
              {hasActiveFilters() && (
                <button onClick={resetAllFilters} className="text-sm text-[#215EF8] hover:text-[#1a4bc6] font-medium">
                  Zrušit filtry
                </button>
              )}
              <button onClick={() => setShowFiltersPanel(false)} className="text-sm text-gray-500 hover:text-[#040F2A]">
                Zavřít
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Výše investice</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={amountRange} onChange={(e) => setAmountRange(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="0-10m">0 – 10 mil. Kč</option>
                <option value="10m-30m">10 – 30 mil. Kč</option>
                <option value="30m+">30+ mil. Kč</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Doba trvání</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={durationRange} onChange={(e) => setDurationRange(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="0-18">0 – 18 měs.</option>
                <option value="18-24">18 – 24 měs.</option>
                <option value="24+">24+ měs.</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Výnos p.a.</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={yieldRange} onChange={(e) => setYieldRange(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="0-8">0 – 8 %</option>
                <option value="8-12">8 – 12 %</option>
                <option value="12+">12+ %</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Zajištění</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={collateralFilter} onChange={(e) => setCollateralFilter(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="yes">Ano</option>
                <option value="no">Ne</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Podíl na HV</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={profitShareFilter} onChange={(e) => setProfitShareFilter(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="yes">Ano</option>
                <option value="no">Ne</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">LTV</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={ltvRange} onChange={(e) => setLtvRange(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="0-50">0 – 50 %</option>
                <option value="50-70">50 – 70 %</option>
                <option value="70+">70+ %</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Odměna</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={commissionRange} onChange={(e) => setCommissionRange(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="0-100k">0 – 100 tis. Kč</option>
                <option value="100k-200k">100 – 200 tis. Kč</option>
                <option value="200k+">200+ tis. Kč</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-gray-600 mb-1.5">Shody s klienty</label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#215EF8] focus:border-transparent" value={clientMatchesFilter} onChange={(e) => setClientMatchesFilter(e.target.value)}>
                <option value="all">Všechny</option>
                <option value="high">Vysoká shoda (5+)</option>
                <option value="medium">Střední shoda (2-4)</option>
                <option value="low">Nízká shoda (1)</option>
                <option value="none">Žádná shoda</option>
              </select>
            </div>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full table-fixed">
          <thead className="border-b border-gray-200">
            <tr>
              <th className="pl-0 pr-3 py-3 text-left w-[40px]">
                {/* Icon column */}
              </th>
              <th className="pl-0 pr-4 py-3 text-left w-[140px]">
                <span className="text-[13px] text-gray-700 font-medium" style={{ letterSpacing: '0.02em' }}>Tiket</span>
              </th>
              
              <th className="px-4 py-3 text-left w-[110px]">
                <button className="flex items-center gap-1 text-[13px] text-gray-700 font-medium hover:text-[#215EF8] transition-colors group" style={{ letterSpacing: '0.02em' }}>
                  <span>Výše</span>
                  <div className="flex flex-col -space-y-1">
                    <ChevronUp className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                    <ChevronDown className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                  </div>
                </button>
              </th>
              
              <th className="px-4 py-3 text-left whitespace-nowrap w-[100px]">
                <button className="flex items-center gap-1 text-[13px] text-gray-700 font-medium hover:text-[#215EF8] transition-colors group" style={{ letterSpacing: '0.02em' }}>
                  <span>Výnos p.a.</span>
                  <div className="flex flex-col -space-y-1">
                    <ChevronUp className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                    <ChevronDown className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                  </div>
                </button>
              </th>
              
              <th className="px-4 py-3 text-left w-[280px]">
                <div className="flex items-center gap-1.5">
                  <span className="text-[13px] text-gray-700 font-medium" style={{ letterSpacing: '0.02em' }}>Kapacita tiketu</span>
                  <div className="relative" onMouseEnter={() => setTooltipActive({ type: 'help-capacity', id: 'header' })} onMouseLeave={() => setTooltipActive(null)}>
                    <HelpCircle className="w-3.5 h-3.5 text-gray-400 hover:text-[#215EF8] cursor-help" />
                    {tooltipActive?.type === 'help-capacity' && tooltipActive?.id === 'header' && (
                      <div className="absolute left-0 top-full mt-2 w-72 px-3 py-2 bg-gray-900 text-white text-xs rounded shadow-lg z-50 pointer-events-none">
                        <strong className="block mb-1">Kapacita tiketu</strong>
                        Maximálně 3 paralelní aktivní rezervace na jeden tiket. Zobrazuje vaše rezervace, čekající sloty a aktivitu ostatních makléřů.
                      </div>
                    )}
                  </div>
                </div>
              </th>
              
              <th className="px-4 py-3 text-left w-[100px]">
                <div className="flex items-center gap-2 pl-6">
                  <button className="flex items-center gap-1 text-[13px] text-gray-700 font-medium hover:text-[#215EF8] transition-colors group" style={{ letterSpacing: '0.02em' }}>
                    <Users className="w-4 h-4" />
                    <div className="flex flex-col -space-y-1">
                      <ChevronUp className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                      <ChevronDown className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                    </div>
                  </button>
                  <div className="relative" onMouseEnter={() => setTooltipActive({ type: 'help-shody', id: 'header' })} onMouseLeave={() => setTooltipActive(null)}>
                    <HelpCircle className="w-3.5 h-3.5 text-gray-400 hover:text-[#215EF8] cursor-help" />
                    {tooltipActive?.type === 'help-shody' && tooltipActive?.id === 'header' && (
                      <div className="absolute right-0 top-full mt-2 w-64 px-3 py-2 bg-gray-900 text-white text-xs rounded shadow-lg z-50 pointer-events-none">
                        <strong className="block mb-1">Shody s investory</strong>
                        Počet investorů z vaší databáze, kteří odpovídají parametrům tohoto tiketu (výše, výnos, riziko, oblast).
                      </div>
                    )}
                  </div>
                </div>
              </th>
              
              <th className="px-4 py-3 text-left w-[120px]">
                <button className="flex items-center gap-1 text-[13px] text-gray-700 font-medium hover:text-[#215EF8] transition-colors group" style={{ letterSpacing: '0.02em' }}>
                  <span>Odměna</span>
                  <div className="flex flex-col -space-y-1">
                    <ChevronUp className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                    <ChevronDown className="w-3 h-3 text-gray-400 group-hover:text-[#215EF8]" />
                  </div>
                </button>
              </th>
              
              <th className="px-4 py-3 text-left w-[70px]"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredTickets.flatMap((ticket) => {
              const totalActive = ticket.myActiveReservations + ticket.otherActiveReservations;
              const canReserveTicket = canReserve(ticket);

              const rows = [];

              rows.push(
                <tr key={`${ticket.id}-main`} className="transition-colors">
                  <td className="pl-0 pr-3 py-3">
                    {/* Status icon */}
                    <div className="relative" onMouseEnter={() => setTooltipActive({ type: 'capacity-status', id: ticket.id })} onMouseLeave={() => setTooltipActive(null)}>
                      {totalActive === 3 ? (
                        <XCircle className="w-5 h-5 text-red-500" />
                      ) : totalActive === 2 ? (
                        <AlertCircle className="w-5 h-5 text-orange-500" />
                      ) : (
                        <CheckCircle2 className="w-5 h-5 text-[#14AE6B]" />
                      )}
                      {tooltipActive?.type === 'capacity-status' && tooltipActive?.id === ticket.id && (
                        <div className="absolute left-0 top-full mt-2 px-3 py-2 bg-gray-900 text-white text-xs rounded shadow-lg z-50 whitespace-nowrap pointer-events-none">
                          <strong className="block mb-1">
                            {totalActive === 3 ? '✗ Plná kapacita' : totalActive === 2 ? '⚠ Částečně obsazeno' : '✓ Volná kapacita'}
                          </strong>
                          <span>{totalActive} / 3 aktivních rezervací</span>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="pl-0 pr-4 py-3">
                    <div className="flex items-start gap-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs text-gray-500 mb-0.5">{ticket.id}</p>
                        <p className="text-sm font-medium text-[#040F2A]">{ticket.type}</p>
                      </div>

                      {expandedTicket === ticket.id ? (
                        <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1 cursor-pointer hover:text-[#215EF8]" onClick={(e) => { e.stopPropagation(); setExpandedTicket(null); }} />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1 cursor-pointer hover:text-[#215EF8]" onClick={(e) => { e.stopPropagation(); setExpandedTicket(ticket.id); }} />
                      )}
                    </div>
                  </td>

                  <td className="px-4 py-3">
                    <p className="text-sm font-semibold text-[#040F2A] whitespace-nowrap">{formatCurrencyCompact(ticket.amount)}</p>
                  </td>

                  <td className="px-4 py-3">
                    <p className="text-sm font-medium text-[#14AE6B]">{ticket.yieldPa}%</p>
                  </td>

                  <td className="px-4 py-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] text-gray-500 uppercase">Aktivní rezervace</span>
                        <span className="text-xs font-semibold text-[#040F2A]">{totalActive} / 3</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-1.5 mb-2">
                        <div className={`h-1.5 rounded-full transition-all ${totalActive === 3 ? 'bg-red-500' : totalActive === 2 ? 'bg-orange-500' : 'bg-[#14AE6B]'}`} style={{ width: `${(totalActive / 3) * 100}%` }} />
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[10px]">
                        <div className="bg-[#215EF8]/5 rounded px-2 py-1">
                          <p className="text-gray-500 mb-0.5">Moje aktivita</p>
                          <div className="flex items-center gap-2">
                            {ticket.myActiveReservations > 0 && (
                              <div className="relative flex items-center gap-0.5" onMouseEnter={() => setTooltipActive({ type: 'my-active', id: ticket.id })} onMouseLeave={() => setTooltipActive(null)}>
                                <CheckCircle className="w-3 h-3 text-[#14AE6B]" />
                                <span className="font-semibold text-[#040F2A]">{ticket.myActiveReservations}</span>
                                {tooltipActive?.type === 'my-active' && tooltipActive?.id === ticket.id && (
                                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-[10px] rounded whitespace-nowrap z-10">
                                    Aktivní rezervace (potvrzené)
                                  </div>
                                )}
                              </div>
                            )}
                            {ticket.myGlobalSlotsUsed > 0 && (
                              <div className="relative flex items-center gap-0.5" onMouseEnter={() => setTooltipActive({ type: 'my-slot', id: ticket.id })} onMouseLeave={() => setTooltipActive(null)}>
                                <Clock className="w-3 h-3 text-orange-500" />
                                <span className="font-semibold text-orange-600">{ticket.myGlobalSlotsUsed}</span>
                                {tooltipActive?.type === 'my-slot' && tooltipActive?.id === ticket.id && (
                                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-[10px] rounded whitespace-nowrap z-10">
                                    Čekající slot (před potvrzením)
                                  </div>
                                )}
                              </div>
                            )}
                            {ticket.myActiveReservations === 0 && ticket.myGlobalSlotsUsed === 0 && (
                              <span className="text-gray-400">—</span>
                            )}
                          </div>
                        </div>

                        <div className="bg-gray-50 rounded px-2 py-1">
                          <p className="text-gray-500 mb-0.5">Ostatní makléři</p>
                          <div className="flex items-center gap-2">
                            {ticket.otherActiveReservations > 0 && (
                              <div className="relative flex items-center gap-0.5" onMouseEnter={() => setTooltipActive({ type: 'other-active', id: ticket.id })} onMouseLeave={() => setTooltipActive(null)}>
                                <CheckCircle className="w-3 h-3 text-gray-600" />
                                <span className="font-semibold text-[#040F2A]">{ticket.otherActiveReservations}</span>
                                {tooltipActive?.type === 'other-active' && tooltipActive?.id === ticket.id && (
                                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-[10px] rounded whitespace-nowrap z-10">
                                    Aktivní rezervace ostatních
                                  </div>
                                )}
                              </div>
                            )}
                            {ticket.otherGlobalSlotsUsed > 0 && (
                              <div className="relative flex items-center gap-0.5" onMouseEnter={() => setTooltipActive({ type: 'other-slot', id: ticket.id })} onMouseLeave={() => setTooltipActive(null)}>
                                <Clock className="w-3 h-3 text-gray-400" />
                                <span className="font-semibold text-gray-600">{ticket.otherGlobalSlotsUsed}</span>
                                {tooltipActive?.type === 'other-slot' && tooltipActive?.id === ticket.id && (
                                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-[10px] rounded whitespace-nowrap z-10">
                                    Čekající sloty ostatních
                                  </div>
                                )}
                              </div>
                            )}
                            {ticket.otherActiveReservations === 0 && ticket.otherGlobalSlotsUsed === 0 && (
                              <span className="text-gray-400">—</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="px-4 py-3">
                    <div className="pl-6">
                      {ticket.clientMatches > 0 ? (
                        <button onClick={() => setClientMatchesModal(ticket.id)} className="flex items-center gap-1 hover:opacity-80 transition-opacity">
                          <Users className="h-6 w-6 text-[#215EF8] flex-shrink-0" />
                          <span className="text-base font-semibold text-[#215EF8]">{ticket.clientMatches}</span>
                        </button>
                      ) : (
                        <span className="text-sm text-gray-400">—</span>
                      )}
                    </div>
                  </td>

                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className="text-base font-semibold text-amber-700 whitespace-nowrap">{formatCurrency(ticket.commissionCzk)} Kč</span>
                      <img src={coinsIcon} alt="" className="h-[2.25em] w-auto flex-shrink-0" />
                    </div>
                  </td>

                  <td className="px-4 py-3">
                    <button 
                      disabled={!canReserveTicket} 
                      onClick={() => canReserveTicket && setReservationFlowTicket(ticket)}
                      className={`p-2 rounded-lg transition-colors ${canReserveTicket ? 'hover:bg-[#215EF8]/10 text-[#215EF8] cursor-pointer' : 'text-gray-300 cursor-not-allowed'}`}
                    >
                      <CalendarCheck className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              );

              if (expandedTicket === ticket.id) {
                rows.push(
                  <tr key={`${ticket.id}-expanded`} className="bg-gray-50">
                    <td colSpan={8} className="px-6 py-6">
                      <div className="text-center py-8 text-gray-500">
                        <p className="text-sm">Detail tiketu – bude doplněn později</p>
                      </div>
                    </td>
                  </tr>
                );
              }

              return rows;
            })}
          </tbody>
        </table>
      </div>

      {clientMatchesModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="border-b border-gray-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-[#040F2A]">Shody s investory</h3>
                <button onClick={() => setClientMatchesModal(null)} className="text-gray-400 hover:text-[#040F2A] transition-colors">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              {mockTickets.find(t => t.id === clientMatchesModal)?.matchingClients?.map((client, idx) => (
                <div key={idx} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#215EF8]/10 flex items-center justify-center">
                      <span className="text-sm font-medium text-[#215EF8]">{client.initials}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#040F2A]">{client.name}</p>
                      <p className="text-xs text-gray-500">{client.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-[#040F2A]">{formatCurrencyCompact(client.amount)}</p>
                    <p className="text-xs text-gray-500">Shoda: {client.matchScore}%</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Reservation Flow */}
      {reservationFlowTicket && (
        <ReservationFlow
          ticket={reservationFlowTicket}
          onClose={() => setReservationFlowTicket(null)}
        />
      )}
    </div>
  );
}