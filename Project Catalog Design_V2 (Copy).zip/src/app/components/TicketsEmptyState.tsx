import { Search } from 'lucide-react';

interface TicketsEmptyStateProps {
  onResetFilters: () => void;
}

export function TicketsEmptyState({ onResetFilters }: TicketsEmptyStateProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 px-6 py-12 text-center">
      <div className="w-16 h-16 rounded-lg bg-gray-100 flex items-center justify-center mx-auto mb-3">
        <Search className="w-7 h-7 text-gray-400" />
      </div>
      <h3 className="font-semibold text-[15px] text-gray-900 mb-1">Žádné tikety nenalezeny</h3>
      <p className="text-sm text-gray-600 mb-4">
        Zkuste upravit filtry nebo vyhledávání
      </p>
      <button
        onClick={onResetFilters}
        className="px-4 py-2 rounded-lg bg-[#215EF8] text-white text-sm font-semibold hover:bg-[#1B4FD1] transition-colors"
      >
        Vymazat filtry
      </button>
    </div>
  );
}
