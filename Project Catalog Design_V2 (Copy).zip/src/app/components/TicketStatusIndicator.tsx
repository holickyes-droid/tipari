interface TicketStatusIndicatorProps {
  total: number;
  available: number;
  lastSlot: number;
  full: number;
}

export function TicketStatusIndicator({ 
  total, 
  available, 
  lastSlot, 
  full 
}: TicketStatusIndicatorProps) {
  // Calculate segment widths as percentages
  const availableWidth = (available / total) * 100;
  const lastSlotWidth = (lastSlot / total) * 100;
  const fullWidth = (full / total) * 100;

  return (
    <div className="space-y-2">
      {/* Visual Bar */}
      <div className="flex h-2 rounded-full overflow-hidden bg-muted">
        {available > 0 && (
          <div 
            className="bg-[#14AE6B] transition-all"
            style={{ width: `${availableWidth}%` }}
          />
        )}
        {lastSlot > 0 && (
          <div 
            className="bg-orange-500 transition-all"
            style={{ width: `${lastSlotWidth}%` }}
          />
        )}
        {full > 0 && (
          <div 
            className="bg-muted-foreground/30 transition-all"
            style={{ width: `${fullWidth}%` }}
          />
        )}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 text-xs">
        {available > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[#14AE6B]" />
            <span className="text-muted-foreground">
              {available} dostupn{available === 1 ? 'ý' : available < 5 ? 'é' : 'ých'}
            </span>
          </div>
        )}
        {lastSlot > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-orange-500" />
            <span className="text-muted-foreground">
              {lastSlot} poslední
            </span>
          </div>
        )}
        {full > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-muted-foreground/50" />
            <span className="text-muted-foreground">
              {full} obsazen{full === 1 ? 'ý' : full < 5 ? 'é' : 'ých'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
