/**
 * NEW FEATURE MODAL - EXPANSION MODULE
 * 
 * Modal component for NewFeature functionality
 * Follows Tipari.cz design system and brand guidelines
 */

import React, { useState } from 'react';
import { X, Check, AlertCircle } from 'lucide-react';

interface NewFeatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  onConfirm?: () => void;
}

export function NewFeatureModal({ 
  isOpen, 
  onClose, 
  title = 'Nová funkcionalita',
  onConfirm
}: NewFeatureModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = async () => {
    setIsProcessing(true);
    
    // Simulace async operace
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (onConfirm) {
      onConfirm();
    }
    
    setIsProcessing(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-[#040F2A]/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal Content */}
      <div className="relative bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#215EF8]/10 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-[#215EF8]" />
            </div>
            <h2 className="text-xl font-semibold text-[#040F2A]">{title}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-6">
          <p className="text-sm text-gray-600 leading-relaxed mb-4">
            Toto je ukázkový modal pro novou funkcionalitu. Můžete zde implementovat
            vlastní logiku, formuláře nebo confirmation dialogy.
          </p>

          {/* Info Box */}
          <div className="p-4 bg-[#215EF8]/5 border border-[#215EF8]/20 rounded-lg">
            <div className="flex gap-3">
              <Check className="w-5 h-5 text-[#14AE6B] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-[#040F2A] mb-1">
                  Nezávislý modul
                </p>
                <p className="text-xs text-gray-600">
                  Tento modal je součástí Development Expansion Zone a neovlivňuje
                  uzamčené komponenty (TicketsPageNew v811).
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 disabled:opacity-50 transition-colors"
          >
            Zrušit
          </button>
          <button
            onClick={handleConfirm}
            disabled={isProcessing}
            className="px-5 py-2 bg-[#215EF8] text-white text-sm font-medium rounded-lg hover:bg-[#1a4ec6] disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
          >
            {isProcessing ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Zpracovávám...
              </>
            ) : (
              <>
                <Check className="w-4 h-4" />
                Potvrdit
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
