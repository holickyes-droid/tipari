# 🚀 DEVELOPMENT EXPANSION ZONE - README

## Přehled

Tato složka obsahuje nové komponenty a moduly vytvořené v rámci **Development Expansion Zone** - bezpečného vývojového prostoru, který neovlivňuje uzamčené produkční komponenty.

---

## 🔒 STABILITY LOCK Status

### Uzamčené soubory (NESMÍ být změněny):
- ✅ `/src/app/components/TicketsPageNew.tsx` (verze 811 - kritická)
- ✅ `/src/app/App.tsx`
- ✅ `/src/app/components/ProjectDetail.tsx`
- ✅ `/src/main.tsx`
- ✅ `/index.html`
- ✅ `/tsconfig.json`
- ✅ `/vite.config.ts`
- ✅ `/package.json`

### Development Zone (volně upravitelné):
- ✅ `/src/app/components/NewFeature/` - nové komponenty
- ✅ `/src/app/types/newFeatureTypes.ts` - nové typy
- ✅ `/src/app/hooks/useNewFeature.ts` - custom hooks
- ✅ `/src/app/utils/newHelpers.ts` - utility funkce

---

## 📁 Struktura

```
/src/app/components/NewFeature/
├── NewFeature.tsx          # Main component
├── NewFeatureModal.tsx     # Modal component
├── NewFeatureLogic.ts      # Business logic
└── index.ts                # Clean exports

/src/app/types/
└── newFeatureTypes.ts      # TypeScript definitions

/src/app/hooks/
└── useNewFeature.ts        # Custom React hook

/src/app/utils/
└── newHelpers.ts           # Utility functions
```

---

## 🎨 Design System

### Brand Colors
- **Primary Blue:** `#215EF8`
- **Success Green:** `#14AE6B`
- **Dark Navy:** `#040F2A`

### Komponenty používají:
- ✅ Tailwind CSS v4
- ✅ Radix UI primitives
- ✅ Lucide React icons
- ✅ Professional B2B aesthetic

---

## 🔧 Použití

### Import komponenty:
```tsx
import { NewFeature } from './components/NewFeature';

// V App.tsx nebo jiné komponentě
<NewFeature title="Vlastní název" />
```

### Použití custom hooku:
```tsx
import { useNewFeature } from './hooks/useNewFeature';

function MyComponent() {
  const { data, loadData, addItem } = useNewFeature({ autoLoad: true });
  
  // ... vaše logika
}
```

### Použití utility funkcí:
```tsx
import { formatCzechDate, debounce } from './utils/newHelpers';

const formatted = formatCzechDate(new Date());
const debouncedSearch = debounce(handleSearch, 300);
```

---

## ✅ Pravidla vývoje

### Povoleno:
- ✅ Vytváření nových souborů v Development Zone
- ✅ Rozšiřování funkcionality v NewFeature/
- ✅ Používání stávajících UI komponent
- ✅ Import locked komponent (read-only reference)
- ✅ Experimentování s novými features

### Zakázáno:
- ❌ Úpravy TicketsPageNew.tsx v811
- ❌ Změny v App.tsx nebo ProjectDetail.tsx
- ❌ Modifikace build konfigurace
- ❌ Změny v locked souborech

---

## 🧪 Testing

Pro testování nové komponenty:

1. Importuj do App.tsx (dočasně pro test)
2. Nebo vytvoř samostatnou test page
3. Použij existující routing pro navigaci

---

## 📝 Notes

- Všechny nové komponenty dodržují Tipari.cz brand guidelines
- Používá se professional B2B UX approach
- Compliance-first copy (žádné marketingové fráze)
- Decision-first hierarchy v UI

---

## 🛡️ Status

- **STABILITY LOCK:** ✅ ACTIVE
- **Development Zone:** ✅ ACTIVE
- **TicketsPageNew v811:** ✅ PROTECTED
- **Build Config:** ✅ LOCKED

---

**Last Updated:** 2026-01-06
**Status:** 🚀 Ready for development
