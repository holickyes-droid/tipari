/**
 * NEW FEATURE - EXPORT INDEX
 * 
 * Clean export pattern for NewFeature module
 * Following best practices for component organization
 */

export { default as NewFeature } from './NewFeature';
export { default } from './NewFeature';
