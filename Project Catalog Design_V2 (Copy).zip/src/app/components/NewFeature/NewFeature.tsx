/**
 * NEW FEATURE - DEVELOPMENT EXPANSION ZONE
 * 
 * Design Principles:
 * - Follows Tipari.cz professional B2B aesthetic
 * - Uses brand colors (#215EF8, #14AE6B, #040F2A)
 * - Maintains decision-first UX approach
 * - Compliance-first copy
 * - Private banking clean design
 * 
 * Status: 🚀 Development ready
 * Base: Independent from TicketsPageNew v811
 */

import React from 'react';

interface NewFeatureProps {
  title?: string;
  description?: string;
}

export default function NewFeature({ 
  title = 'Nová funkce', 
  description = 'Zde bude implementace nové funkcionality.'
}: NewFeatureProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#040F2A] via-[#0a1640] to-[#040F2A]">
      <div className="container mx-auto px-6 py-12">
        {/* Header Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-1 h-8 bg-[#215EF8] rounded-full" />
            <h1 className="text-3xl font-semibold text-[#040F2A]">{title}</h1>
          </div>
          <p className="mt-4 text-base text-gray-600 leading-relaxed">
            {description}
          </p>
        </div>

        {/* Content Section */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Feature Card 1 */}
            <div className="p-6 border border-gray-200 rounded-lg hover:border-[#215EF8] transition-colors">
              <div className="w-12 h-12 bg-[#215EF8]/10 rounded-lg flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-[#215EF8]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-[#040F2A] mb-2">
                Feature modul 1
              </h3>
              <p className="text-sm text-gray-600">
                Popis funkcionality, která bude implementována v tomto modulu.
              </p>
            </div>

            {/* Feature Card 2 */}
            <div className="p-6 border border-gray-200 rounded-lg hover:border-[#14AE6B] transition-colors">
              <div className="w-12 h-12 bg-[#14AE6B]/10 rounded-lg flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-[#14AE6B]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-[#040F2A] mb-2">
                Feature modul 2
              </h3>
              <p className="text-sm text-gray-600">
                Další rozšiřující funkcionalita s vlastní logikou a UI.
              </p>
            </div>
          </div>

          {/* Action Section */}
          <div className="mt-8 flex items-center justify-between p-6 bg-gradient-to-r from-[#215EF8]/5 to-[#14AE6B]/5 rounded-lg border border-[#215EF8]/20">
            <div>
              <p className="text-sm font-semibold text-[#040F2A] mb-1">
                Development Expansion Zone aktivní
              </p>
              <p className="text-xs text-gray-600">
                Tento modul je nezávislý na TicketsPageNew v811 a může být volně rozšiřován.
              </p>
            </div>
            <button className="px-6 py-2.5 bg-[#215EF8] text-white rounded-lg font-medium hover:bg-[#1a4ec6] transition-colors text-sm">
              Rozšířit funkci
            </button>
          </div>
        </div>

        {/* Info Footer */}
        <div className="mt-6 p-4 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
          <p className="text-xs text-white/80 text-center">
            🛡️ STABILITY LOCK aktivní • TicketsPageNew v811 nedotčená • Build konfigurace zamražena
          </p>
        </div>
      </div>
    </div>
  );
}
