import { Shield } from 'lucide-react';
import { Ticket } from '../types/project';
import { Button } from './ui/button';

interface TicketsTableProps {
  tickets: Ticket[];
  projectStatus: 'Open' | 'Fully reserved' | 'Paused' | 'Finished';
}

export function TicketsTable({ tickets, projectStatus }: TicketsTableProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('cs-CZ', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getRecommendationBadge = (recommendation?: string) => {
    if (!recommendation) return null;
    
    switch (recommendation) {
      case 'Nejlepší':
        return (
          <div className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-[#14AE6B]/10 text-[#14AE6B] border border-[#14AE6B]/20">
            ⭐ {recommendation}
          </div>
        );
      case 'Vhodný':
        return (
          <div className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
            {recommendation}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        {/* Table Header */}
        <thead>
          <tr className="border-b border-border bg-gray-50">
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Tiket</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Výše (CZK)</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">LTV</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Výnos</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Podíl na HV</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Délka</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Forma</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Zajištění</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Odměna</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Rezervací</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Doporučeno</th>
            <th className="px-4 py-3 text-left text-xs font-semibold text-[#040F2A] uppercase tracking-wider">Akce</th>
          </tr>
        </thead>

        {/* Table Body */}
        <tbody className="divide-y divide-border">
          {tickets.map((ticket, index) => {
            const isReservationDisabled = projectStatus !== 'Open' || ticket.occupancy.current >= ticket.occupancy.total;
            const availableSlots = ticket.occupancy.total - ticket.occupancy.current;
            const investorCount = ticket.occupancy.current;

            return (
              <tr key={ticket.id} className="hover:bg-gray-50 transition-colors">
                {/* Tiket */}
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    <div className="bg-white border border-border rounded px-3 py-1.5">
                      <div className="text-lg font-bold text-[#040F2A]">{index + 1}</div>
                    </div>
                    {getRecommendationBadge(ticket.recommendation)}
                  </div>
                </td>

                {/* Výše (CZK) */}
                <td className="px-4 py-4">
                  <div className="font-semibold text-[#040F2A]">{formatCurrency(ticket.investmentAmount)}</div>
                </td>

                {/* LTV */}
                <td className="px-4 py-4">
                  <span className="inline-flex items-center px-2.5 py-1 rounded-md text-sm font-semibold bg-[#14AE6B]/10 text-[#14AE6B]">
                    {ticket.ltv}%
                  </span>
                </td>

                {/* Výnos */}
                <td className="px-4 py-4">
                  <div className="font-semibold text-[#040F2A]">{ticket.yieldPA}%</div>
                </td>

                {/* Podíl na HV */}
                <td className="px-4 py-4">
                  <div className="font-medium text-[#040F2A]">
                    {ticket.profitSharing && ticket.profitSharing !== 'Ne' 
                      ? typeof ticket.profitSharing === 'string' 
                        ? ticket.profitSharing 
                        : `${ticket.profitSharing.percentage}%`
                      : '—'
                    }
                  </div>
                </td>

                {/* Délka */}
                <td className="px-4 py-4">
                  <div className="font-medium text-[#040F2A]">{ticket.duration} měs.</div>
                </td>

                {/* Forma */}
                <td className="px-4 py-4">
                  <div className="text-sm text-[#040F2A]">{ticket.investmentForm}</div>
                </td>

                {/* Zajištění */}
                <td className="px-4 py-4">
                  {ticket.secured ? (
                    <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-[#14AE6B]/10 text-[#14AE6B]">
                      ANO
                    </span>
                  ) : (
                    <span className="text-sm text-muted-foreground">NE</span>
                  )}
                </td>

                {/* Odměna */}
                <td className="px-4 py-4">
                  <div className="font-semibold text-[#14AE6B]">
                    {formatCurrency((ticket.investmentAmount * ticket.commission) / 100)} Kč
                  </div>
                </td>

                {/* Rezervací */}
                <td className="px-4 py-4">
                  <div className="font-semibold text-[#040F2A]">
                    {ticket.occupancy.current} / {ticket.occupancy.total}
                  </div>
                </td>

                {/* Doporučeno */}
                <td className="px-4 py-4">
                  {investorCount > 0 ? (
                    <button className="text-sm font-medium text-[#215EF8] hover:underline">
                      {investorCount} {investorCount === 1 ? 'investor' : investorCount < 5 ? 'investoři' : 'investorů'}
                    </button>
                  ) : (
                    <span className="text-sm text-muted-foreground">—</span>
                  )}
                </td>

                {/* CTA Button */}
                <td className="px-4 py-4">
                  <Button
                    size="sm"
                    className="bg-[#14AE6B] hover:bg-[#0D7A4A] text-white disabled:bg-gray-300 disabled:text-gray-500 whitespace-nowrap"
                    disabled={isReservationDisabled}
                  >
                    {isReservationDisabled 
                      ? 'Nedostupné' 
                      : `Rezervovat (${availableSlots})`
                    }
                  </Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
