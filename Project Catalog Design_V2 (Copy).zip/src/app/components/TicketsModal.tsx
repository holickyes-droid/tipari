import { X, TrendingUp, DollarSign, Clock, Shield } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import { TicketsGrid } from './TicketsGrid';
import { ReservationFlow } from './ReservationFlow';
import { Project, Ticket } from '../types/project';
import { DraftReservation } from './DraftReservationsPanel';

interface TicketsModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onSaveDraft?: (draft: DraftReservation) => void;
}

export function TicketsModal({ isOpen, onClose, project, onSaveDraft }: TicketsModalProps) {
  const [showReservationFlow, setShowReservationFlow] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);

  if (!isOpen) return null;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('cs-CZ', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getDurationRange = () => {
    if (project.tickets.length === 0) return null;
    const durations = project.tickets.map(t => t.duration);
    const minDuration = Math.min(...durations);
    const maxDuration = Math.max(...durations);
    
    if (minDuration === maxDuration) {
      return `${minDuration} měs.`;
    }
    return `${minDuration}-${maxDuration} měs.`;
  };

  const countTicketsByState = () => {
    let available = 0;
    let lastSlot = 0;
    let full = 0;

    project.tickets.forEach((ticket) => {
      const remaining = ticket.occupancy.total - ticket.occupancy.current;
      if (remaining === 0) {
        full++;
      } else if (remaining === 1) {
        lastSlot++;
      } else {
        available++;
      }
    });

    return { available, lastSlot, full };
  };

  const ticketStats = countTicketsByState();
  const durationRange = getDurationRange();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="border-b border-border px-6 py-5 bg-gradient-to-r from-slate-50 to-white">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-semibold text-[#040F2A]">
                  {project.name}
                </h2>
              </div>
              
              {/* Project Quick Stats */}
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <DollarSign className="w-4 h-4" />
                  <span className="font-medium text-[#040F2A]">{formatCurrency(project.totalInvestmentVolume)} Kč</span>
                </div>
                <span className="text-muted-foreground/50">•</span>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <TrendingUp className="w-4 h-4" />
                  <span className="font-medium text-[#14AE6B]">{project.yieldPA.toFixed(1)}% p.a.</span>
                </div>
                <span className="text-muted-foreground/50">•</span>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span className="font-medium text-[#040F2A]">{durationRange || '—'}</span>
                </div>
                <span className="text-muted-foreground/50">•</span>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Shield className="w-4 h-4" />
                  <span className="font-medium text-[#040F2A]">LTV {project.ltv}%</span>
                </div>
              </div>
            </div>

            {/* Tickets Count Badge */}
            <div className="ml-4 text-center bg-gradient-to-br from-[#215EF8] to-[#1a4bc7] rounded-xl px-5 py-3 shadow-lg shadow-[#215EF8]/25">
              <div className="text-xs uppercase tracking-wider text-white/90 mb-0.5 font-semibold">
                Investiční tikety
              </div>
              <div className="text-2xl font-bold text-white">
                {project.tickets.length}
              </div>
            </div>

            <button
              onClick={onClose}
              className="ml-4 text-muted-foreground hover:text-[#040F2A] transition-colors p-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Ticket Status Indicators */}
          <div className="flex items-center gap-3 mt-4 pt-4 border-t border-border/50">
            <div className="text-xs text-muted-foreground font-medium">Status tiketů:</div>
            <div className="flex items-center gap-3">
              {ticketStats.available > 0 && (
                <div className="flex items-center gap-1.5 text-xs">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#14AE6B]" />
                  <span className="font-medium text-[#040F2A]">{ticketStats.available}</span>
                  <span className="text-muted-foreground">dostupné</span>
                </div>
              )}
              {ticketStats.lastSlot > 0 && (
                <div className="flex items-center gap-1.5 text-xs">
                  <div className="w-2.5 h-2.5 rounded-full bg-orange-500" />
                  <span className="font-medium text-[#040F2A]">{ticketStats.lastSlot}</span>
                  <span className="text-muted-foreground">poslední místo</span>
                </div>
              )}
              {ticketStats.full > 0 && (
                <div className="flex items-center gap-1.5 text-xs">
                  <div className="w-2.5 h-2.5 rounded-full bg-muted-foreground" />
                  <span className="font-medium text-[#040F2A]">{ticketStats.full}</span>
                  <span className="text-muted-foreground">obsazené</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Content - Conditional: Either Tickets Grid OR Reservation Flow */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30">
          {showReservationFlow && selectedTicket ? (
            <div className="max-w-4xl mx-auto">
              <ReservationFlow
                ticket={selectedTicket}
                projectName={project.name}
                projectId={project.id}
                onClose={() => {
                  setShowReservationFlow(false);
                  setSelectedTicket(null);
                }}
                onBack={() => {
                  setShowReservationFlow(false);
                  setSelectedTicket(null);
                }}
                onSaveDraft={onSaveDraft}
              />
            </div>
          ) : (
            <TicketsGrid 
              tickets={project.tickets} 
              projectStatus={project.status} 
              projectName={project.name}
              projectId={project.id}
              onTicketSelect={(ticket) => {
                setSelectedTicket(ticket);
                setShowReservationFlow(true);
              }}
            />
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-border px-6 py-4 bg-white">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Kliknutím na "Shody" u tiketu zobrazíte investory odpovídající parametrům.
            </div>
            <Button
              onClick={onClose}
              className="bg-[#215EF8] hover:bg-[#1a4bc7] text-white"
            >
              Zavřít
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}