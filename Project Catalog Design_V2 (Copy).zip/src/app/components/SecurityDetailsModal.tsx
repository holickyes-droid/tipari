import { X, Shield, FileText, ExternalLink } from 'lucide-react';
import { Button } from './ui/button';
import { SecurityType } from '../types/project';

interface SecurityDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  ticketNumber: string;
  projectName: string;
  projectId: string;
  securedTypes: SecurityType[];
}

export function SecurityDetailsModal({
  isOpen,
  onClose,
  ticketNumber,
  projectName,
  projectId,
  securedTypes,
}: SecurityDetailsModalProps) {
  if (!isOpen) return null;

  const handleProjectDetailClick = () => {
    // Navigate to project detail page
    console.log('Navigate to project:', projectId);
    // In real app: router.push(`/projects/${projectId}`)
  };

  const getSecurityIcon = (type: SecurityType) => {
    // Different icons based on security type
    if (type.includes('Zástava')) return '🏠';
    if (type.includes('směnka')) return '📝';
    if (type.includes('Notářský')) return '⚖️';
    if (type === 'Ručitelský závazek') return '🤝';
    if (type === 'Postoupení pohledávek') return '💰';
    if (type === 'Zajištění nájmů') return '🔑';
    if (type === 'Bez zajištění') return '⚠️';
    return '✓';
  };

  const getSecurityColor = (type: SecurityType) => {
    if (type === 'Zástava 1. pořadí') return 'bg-[#14AE6B]/10 text-[#14AE6B] border-[#14AE6B]/20';
    if (type === 'Zástava 2. pořadí') return 'bg-blue-50 text-blue-700 border-blue-200';
    if (type === 'Bez zajištění') return 'bg-red-50 text-red-700 border-red-200';
    return 'bg-slate-50 text-slate-700 border-slate-200';
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="border-b border-border px-6 py-4 bg-slate-50">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-5 h-5 text-[#215EF8]" />
                <h2 className="text-xl font-semibold text-[#040F2A]">
                  Detaily zajištění
                </h2>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="font-mono font-medium text-[#040F2A]">{ticketNumber}</span>
                <span>•</span>
                <span className="truncate max-w-md">{projectName}</span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-muted-foreground hover:text-[#040F2A] transition-colors p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="space-y-4">
            {/* Security Types Header */}
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-3">
                Typy zajištění ({securedTypes.length})
              </h3>
            </div>

            {/* Security Types Grid */}
            <div className="grid grid-cols-1 gap-3">
              {securedTypes.map((type, index) => (
                <div
                  key={index}
                  className={`border rounded-lg px-4 py-3 transition-all hover:shadow-sm ${getSecurityColor(type)}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{getSecurityIcon(type)}</span>
                    <div className="flex-1">
                      <div className="font-medium">{type}</div>
                      {type === 'Zástava 1. pořadí' && (
                        <div className="text-xs mt-1 opacity-75">
                          Nejvyšší priorita při vymáhání
                        </div>
                      )}
                      {type === 'Zástava 2. pořadí' && (
                        <div className="text-xs mt-1 opacity-75">
                          Druhé v pořadí při vymáhání
                        </div>
                      )}
                      {type === 'Notářský zápis s přímou vykonatelností' && (
                        <div className="text-xs mt-1 opacity-75">
                          Možnost okamžitého vymáhání bez soudního řízení
                        </div>
                      )}
                      {type === 'Bez zajištění' && (
                        <div className="text-xs mt-1 opacity-75">
                          Investice není zajištěna
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Info Box */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
              <div className="flex gap-3">
                <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-blue-900 mb-1">
                    Podrobné informace o zajištění
                  </div>
                  <div className="text-xs text-blue-700 leading-relaxed">
                    Detailní dokumentace k zajištění včetně právních dokumentů je k dispozici v detailu projektu. 
                    Pro přístup k úplné dokumentaci klikněte na tlačítko níže.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-border px-6 py-4 bg-slate-50">
          <div className="flex items-center gap-3 justify-end">
            <Button
              variant="outline"
              onClick={onClose}
            >
              Zavřít
            </Button>
            <Button
              className="bg-[#215EF8] hover:bg-[#1a4bc7] text-white"
              onClick={handleProjectDetailClick}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Zobrazit detail projektu
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
