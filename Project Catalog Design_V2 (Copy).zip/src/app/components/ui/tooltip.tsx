import * as React from "react";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";
import { cn } from "./utils";
import { Info } from 'lucide-react';

// ============================================================================
// RADIX UI TOOLTIP (Original shadcn/ui components)
// ============================================================================

const TooltipProvider = TooltipPrimitive.Provider;

const Tooltip = TooltipPrimitive.Root;

const TooltipTrigger = TooltipPrimitive.Trigger;

const TooltipContent = React.forwardRef<
  React.ElementRef<typeof TooltipPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TooltipPrimitive.Content>
>(({ className, sideOffset = 4, ...props }, ref) => (
  <TooltipPrimitive.Content
    ref={ref}
    sideOffset={sideOffset}
    className={cn(
      "z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
      className
    )}
    {...props}
  />
));
TooltipContent.displayName = TooltipPrimitive.Content.displayName;

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };

// ============================================================================
// CUSTOM METRIC TOOLTIP (For compliance-first metric definitions)
// ============================================================================

/**
 * Metric Tooltip - specialized tooltip for displaying metric definitions
 * with compliance-first approach
 */
interface MetricTooltipProps {
  label: string;
  definition: string;
  example?: string;
  value?: string | number;
}

export function MetricTooltip({ label, definition, example, value }: MetricTooltipProps) {
  const [isVisible, setIsVisible] = React.useState(false);

  return (
    <div className="relative inline-flex items-center">
      {value && <span className="mr-1.5">{value}</span>}
      
      <div
        onMouseEnter={() => setIsVisible(true)}
        onMouseLeave={() => setIsVisible(false)}
        className="cursor-help inline-flex items-center"
      >
        <Info className="w-4 h-4 text-muted-foreground hover:text-[#215EF8] transition-colors" />
      </div>

      {isVisible && (
        <div 
          className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2"
          style={{ maxWidth: '360px' }}
        >
          {/* Tooltip Content */}
          <div className="bg-[#040F2A] text-white text-xs rounded-lg px-3 py-2 shadow-xl">
            <div className="space-y-2">
              <div className="font-semibold text-sm">{label}</div>
              <div className="text-xs leading-relaxed opacity-90">{definition}</div>
              {example && (
                <div className="text-xs italic opacity-75 pt-1 border-t border-white/20">
                  Příklad: {example}
                </div>
              )}
            </div>
          </div>

          {/* Arrow */}
          <div 
            className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-4 border-l-transparent border-r-transparent border-b-transparent border-t-[#040F2A]"
          />
        </div>
      )}
    </div>
  );
}