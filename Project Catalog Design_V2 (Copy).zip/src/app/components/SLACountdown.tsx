import { useState, useEffect } from 'react';
import { Timer, Clock } from 'lucide-react';

interface SLACountdownProps {
  expiresAt: number; // Unix timestamp in seconds
  compact?: boolean;
  simple?: boolean; // New: simple gray design for project detail
}

export function SLACountdown({ expiresAt, compact = false, simple = false }: SLACountdownProps) {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; total: number }>({ days: 0, hours: 0, minutes: 0, total: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = Math.floor(Date.now() / 1000); // Current time in seconds
      const diff = expiresAt - now;

      if (diff <= 0) {
        return { days: 0, hours: 0, minutes: 0, total: 0 };
      }

      const days = Math.floor(diff / (60 * 60 * 24));
      const hours = Math.floor((diff % (60 * 60 * 24)) / (60 * 60));
      const minutes = Math.floor((diff % (60 * 60)) / 60);

      return { days, hours, minutes, total: diff };
    };

    setTimeLeft(calculateTimeLeft());

    const interval = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [expiresAt]);

  const getStatusColor = (): string => {
    const totalHours = timeLeft.days * 24 + timeLeft.hours;
    if (totalHours <= 24) return 'red'; // Critical - less than 24 hours
    if (totalHours <= 72) return 'orange'; // Warning - less than 3 days
    return 'green'; // Good - more than 3 days
  };

  const getProgressPercentage = (): number => {
    // Assume SLA is 7 days (can be parameterized later)
    const totalSLA = 7 * 24 * 60 * 60; // 7 days in seconds
    const remaining = timeLeft.total;
    return Math.min(100, Math.max(0, (remaining / totalSLA) * 100));
  };

  const formatTimeText = (): string => {
    if (timeLeft.total === 0) return 'Vypršelo';
    if (timeLeft.days > 0) {
      return `${timeLeft.days}d ${timeLeft.hours}h`;
    }
    return `${timeLeft.hours}h ${timeLeft.minutes}m`;
  };

  const formatSimpleTimeText = (): string => {
    if (timeLeft.total === 0) return 'Vypršelo';
    if (timeLeft.days > 0) {
      const daysText = timeLeft.days === 1 ? 'den' : timeLeft.days < 5 ? 'dny' : 'dní';
      const hoursText = timeLeft.hours === 1 ? 'hodina' : timeLeft.hours < 5 ? 'hodiny' : 'hodin';
      return `${timeLeft.days} ${daysText} a ${timeLeft.hours} ${hoursText}`;
    }
    const hoursText = timeLeft.hours === 1 ? 'hodina' : timeLeft.hours < 5 ? 'hodiny' : 'hodin';
    return `${timeLeft.hours} ${hoursText}`;
  };

  const statusColor = getStatusColor();
  const progressPercentage = getProgressPercentage();

  const colorClasses = {
    red: { text: 'text-red-600', bg: 'bg-red-500', border: 'border-red-500' },
    orange: { text: 'text-orange-600', bg: 'bg-orange-500', border: 'border-orange-500' },
    green: { text: 'text-[#14AE6B]', bg: 'bg-[#14AE6B]', border: 'border-[#14AE6B]' },
  }[statusColor];

  if (simple) {
    // Simple inline design - just icon + text in gray
    return (
      <div className="flex items-center gap-1.5">
        <Clock className="w-4 h-4 text-gray-600" />
        <span className="text-sm text-gray-600">{formatSimpleTimeText()}</span>
      </div>
    );
  }

  if (compact) {
    // Compact version for table cell
    return (
      <div className="flex items-center gap-1.5">
        <Timer className={`w-3.5 h-3.5 ${colorClasses.text}`} />
        <span className={`text-xs font-semibold ${colorClasses.text}`}>{formatTimeText()}</span>
      </div>
    );
  }

  // Full version for expanded detail
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Timer className={`w-4 h-4 ${colorClasses.text}`} />
          <span className="text-xs font-semibold text-gray-600 uppercase">Platnost nabídky</span>
        </div>
        <span className={`text-sm font-bold ${colorClasses.text}`}>{formatTimeText()}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className={`h-2 rounded-full transition-all ${colorClasses.bg}`} 
          style={{ width: `${progressPercentage}%` }} 
        />
      </div>
      {timeLeft.total > 0 && timeLeft.total <= 24 * 60 * 60 && (
        <p className="text-xs text-red-600 font-medium">⚠ Kritická platnost - méně než 24 hodin!</p>
      )}
    </div>
  );
}