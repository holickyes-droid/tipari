# TYPY PROJEKTU.docx

Typy projektů (Tipari.cz)
🧩 1️⃣ Přehledová tabulka
Doporučená klasifikace (pro UX)
Pro kartu tiketu a filtry doporučuji zobrazovat:
Hlavní typ projektu (1 z výše)
Podtyp (volitelně, např. „Bytový dům – Praha“)
Horizont
Rizikový profil (ikonově, ne textem)

---

## Tables

### Table 1
| # | Typ projektu | Popis | Typický horizont | Riziko | Typické zajištění | Poznámka |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Rezidenční development | Výstavba bytů / RD k prodeji | 18–36 měsíců | 🟡 střední | Zástava nemovitosti, ručení SPV | Nejčastější typ |
| 2 | Rezidenční rekonstrukce | Rekonstrukce + prodej | 6–18 měsíců | 🟢 nižší | Zástava nemovitosti | Rychlejší obrat |
| 3 | Komerční development | Kanceláře, retail, logistika | 24–48 měsíců | 🟡–🔴 | Zástava, bank mix | Vyšší objemy |
| 4 | Nákup hotové nemovitosti (buy & hold) | Pronajímaná nemovitost | 36+ měsíců | 🟢 | Zástava + cashflow | Stabilní výnos |
| 5 | Refinancování projektu | Splacení existujícího úvěru | 6–24 měsíců | 🟢 | Zástava, notářský zápis | Nízké riziko |
| 6 | Bridge financování | Krátkodobý překlenovací úvěr | 3–12 měsíců | 🟡 | Silné zajištění | Časově kritické |
| 7 | Land development | Pozemky, změna územka | 24–60 měsíců | 🔴 vyšší | Křížová zástava | Legislativní riziko |
| 8 | Brownfield redevelopment | Přestavba areálů | 24–48 měsíců | 🔴 | Kombinované | Komplexní projekty |
| 9 | Joint Venture projekt | Kapitálový vstup / podíl | 36+ měsíců | 🔴 | Podíl + kontrola | Individuální struktura |
| 10 | Speciální realitní projekt | Hotel, senior housing apod. | 24–60 měsíců | 🔴 | Individuální | Case-by-case |
