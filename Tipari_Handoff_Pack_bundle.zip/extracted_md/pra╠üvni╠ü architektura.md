# právní architektura.docx

KROK 14 — Právní architektura (big picture)
14.1 Základní právní filozofie (klíčové)
Platforma není investiční zprostředkovatel ani distributor investičních produktů.
Platforma:
neeviduje investici
nepřijímá peníze
nedává investiční doporučení
neevaluuje vhodnost investora
Platforma pouze:
eviduje představení investora
eviduje vznik obchodního vztahu
chrání provizní nárok
➡️ To je páteř celé právní konstrukce.
KROK 14.2 — Přehled POVINNÝCH dokumentů
Core dokumenty (MUST HAVE)
1️⃣ Provizní smlouva (Tipař ↔ Developer)
2️⃣ Smlouva o využití platformy (Developer)
3️⃣ Smlouva o využití platformy (Tipař)
4️⃣ Všeobecné obchodní podmínky (VOP)
5️⃣ Právní disclaimer (investice, odpovědnost)
6️⃣ Zásady zpracování osobních údajů (GDPR)
KROK 14.3 — Provizní smlouva (nejdůležitější dokument)
Strany
Developer (objednatel)
Tipař (zprostředkovatel obchodní příležitosti)
⚠️ Platforma není stranou investiční smlouvy.
Předmět smlouvy (kanonický)
Zprostředkování obchodní příležitosti spočívající v představení investora developerovi.
Klíčové:
NE „zprostředkování investice“
NE „nabídka investičního nástroje“
Vznik nároku na provizi
Nárok vzniká, pokud:
byl investor prokazatelně představen přes platformu
došlo k uzavření obchodní dohody
bez ohledu na konečnou strukturu (úvěr, podíl, kombinace)
➡️ Přesně odpovídá KROKU 9.5.
Splatnost provize
Varianty:
po podpisu
po čerpání
kombinace
➡️ Vždy jasně definováno per projekt.
Ochrana proti obcházení
Povinné ustanovení:
zákaz přímého obejití tipaře
časový test (např. 24 měsíců)
sankce / smluvní pokuta (doporučeno)
KROK 14.4 — Smlouva o využití platformy (Developer)
Co řeší:
přístup na platformu
povinnost potvrzovat stavy (deal, platby)
respektování SLA
akceptace admin rozhodnutí
Kritické klauzule
uznání auditních záznamů platformy
povinnost součinnosti při sporech
možnost blokace / omezení účtu
rozhodčí / soudní doložka (doporučení: obecný soud ČR)
KROK 14.5 — Smlouva o využití platformy (Tipař)
Co řeší:
status tipaře jako nezávislého subjektu
povinnost mít souhlas investora
zákaz klamání / duplicit
respektování procesů
Důležitá ochrana platformy
tipař nenese odpovědnost za investiční výsledek
platforma nenese odpovědnost za rozhodnutí investora
tipař neposkytuje investiční poradenství
KROK 14.6 — VOP (sjednocující dokument)
VOP musí:
odkázat na všechny dílčí smlouvy
definovat pojmy:
„investor“
„představení investora“
„deal“
„provize“
popsat proces:
rezervace
introdukce
potvrzení dealu
spor
➡️ VOP = manuál platformy v právním jazyce.
KROK 14.7 — Právní disclaimer (MiFID / ZPKT safe)
Povinné body:
nejde o veřejnou nabídku
nejde o investiční doporučení
platforma není regulovaným subjektem
investiční rozhodnutí je výlučně na investorovi
Krátké, jasné, viditelné:
při registraci
při každé introdukci investora
v detailu projektu
KROK 14.8 — GDPR (nezbytné minimum)
Specifika Tipari.cz:
investor není uživatel
zpracování údajů:
jméno / entita
kontakt (až po souhlasu)
právní titul:
oprávněný zájem
souhlas investora (potvrzuje tipař)
➡️ Povinné:
audit přístupů
logy
role-based access
