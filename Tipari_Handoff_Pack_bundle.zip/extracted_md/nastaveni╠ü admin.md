# nastavení admin.docx

KROK 13 — Admin & Finance Dashboard (Figma hi-fi specifikace)
Cíl: dát Adminovi plnou kontrolu nad penězi, spory a reputací – rychle, přehledně, bez zahlcení.
13.1 Role & mindset obrazovky
Uživatel: ADMIN
Úkol:
vidět rizika dřív, než explodují
rozhodovat spory datově
hlídat cashflow provizí
udržet autoritu platformy
Design principy:
enterprise / SaaS (klid, jistota)
žádné marketingové barvy
minimum grafů, maximum signálů
vše „one click to detail“
13.2 Informační architektura (IA)
Levé menu (ADMIN ONLY)
Overview
Rezervace
Introdukce investorů
Dealy
Provize
Faktury
Spory
Reputace
Uživatelé
Audit log
Nastavení
➡️ Nikdy nemíchat finance a spory do jedné obrazovky.
13.3 OVERVIEW (řídicí cockpit)
Horní KPI lišta (cards)
Rezervace čekající na akci
Dealy potvrzené (MTD)
Provize po splatnosti (částka)
Aktivní spory
Rizikoví developeři (count)
Interakce: klik = filtruje zbytek stránky
Střed: „Risk radar“
Tabulka (ne graf):
Entity (Developer / Tipař)
Typ rizika (SLA / platby / spory)
Závažnost (Low / Med / High)
Poslední incident
CTA: „Otevřít“
➡️ Admin nečte reporty, admin řeší signály.
13.4 REZERVACE — kontrola toku
Tabulka (server-side)
Sloupce:
Projekt
Tipař
Stav
SLA (countdown)
Poslední akce
CTA: Schválit / Detail
Filtry:
po SLA
pending > 24h
opakovaně rušené
13.5 INTRODUKCE INVESTORŮ
Cíl: hlídat férovost a duplicity.
Sloupce:
Projekt
Tipař
Typ investora
Range objemu
Stav
Čas od představení
CTA: Detail / Zamítnout
Alerty:
duplicitní jméno / entita
podezřele rychlé odmítnutí
13.6 DEALY — „money moment“
Sloupce:
Projekt
Developer
Tipař
Datum podpisu
Finální objem
Stav
CTA: Detail
Badge:
„Admin confirmed“
„Developer confirmed“
„Reported by tipař“
13.7 PROVIZE — finanční páteř
Primární tabulka
Sloupce:
Tipař
Developer (payer)
Částka
Splatnost
Stav
Days overdue
CTA: Faktura / Eskalovat
Hromadné akce (ADMIN):
označit jako „overdue“
eskalovat právně
zmrazit účet developera
13.8 FAKTURY
Sloupce:
Číslo
Vystavil
Komu
Částka
Splatnost
Stav
PDF
CTA: Označit zaplaceno
➡️ Admin má override.
Ale každý override = audit.
13.9 SPORY (nejdůležitější obrazovka)
Queue podle priority
Sloupce:
Typ sporu
Částka (pokud relevantní)
Strany
Stav
Délka
CTA: Převzít
Detail sporu
timeline (události)
dokumenty
rozhodnutí
tlačítka:
Rozhodnout
Vyžádat info
Eskalovat právně
13.10 REPUTACE (interní)
Admin-only pohled:
rozpad skóre
trend (↑ ↓ →)
poslední eventy
doporučená opatření (AI-ready)
➡️ Uživatelé nikdy neuvidí tato čísla.
13.11 AUDIT LOG
Filtry:
entity
user
typ akce
čas
Detail:
before / after
actor
IP
metadata
➡️ Nezpochybnitelné.
