# ZÁKLADNÍ DESIGNOVÁ PRAVIDLA.docx

🧭 ZÁKLADNÍ DESIGNOVÁ PRAVIDLA (která budu dál používat)
🎨 1️⃣ Vizuální identita podle logomanuálu Tipari
💼 2️⃣ Tón značky (Brand Voice)
Značka Tipari musí působit jako privátní investiční partner — ne startup.
🧩 3️⃣ Product / UI Illustrations (Investown & Fingood styl)
Chceme přejmout emocionální strukturu a vizuální archetypy:
💡 Cíl: Tipari působí profesionálně jako Investown, ale méně marketingově – víc „relationship-driven“ než „platform-driven“.
🧠 4️⃣ Designové principy pro další UX/UI návrhy
✨ 5️⃣ Vizuální tón stránky Tikety
Základní rozložení: 3 sloupce (obrázek projektu – parametry – CTA)
Obrázek má jemný modrý overlay
CTA vždy vpravo dole (modrý, primární)
Sloty a SLA nahoře vpravo jako drobné ukazatele
Texty 14–16px, hodně prostoru, žádné přetížení
Každá karta = samostatná investiční příležitost, ne tabulková buňka
🎯 Shrnutí: UX/UI mindset, se kterým budu dál pracovat
🧭 Design ethos:
„Tipari pomáhá profesionálům dělat jistá rozhodnutí rychle, klidně a s důvěrou.“
🧩 UX styl:
Investown + Fingood elegance, ale s B2B strukturou a právní čistotou.
🖼️ Vizuální archetypy:
modro-bílý minimalismus, outline ilustrace, klidná estetika, whitespace.

---

## Tables

### Table 1
| Prvek | Styl | Použití |
| --- | --- | --- |
| Primární barva | #215EF8 (Tipari Blue) | CTA, odkazy, hlavní navigace |
| Sekundární barva | #040F2A (Dark Navy) | pozadí, text, záhlaví sekcí |
| Úspěch / výnosy | #14AE6B (Success Green) | schválené rezervace, provize, SLA OK |
| Varování / SLA | #F59E0B (Gold) | upozornění, expirace, čekání |
| Chyba / uzavřeno | #EF4444 (Red) | vypršelo, odmítnuto |
| Typografie | Manrope / Inter | stabilní, čitelné, B2B elegantní |
| Styl ikon | Outline (Lucide / Feather) | minimalistické, ne barevné |
| Estetika | „Private banking calm“ | velký whitespace, jasná hierarchie, žádné gradienty |

### Table 2
| Tón | Popis |
| --- | --- |
| 💬 Jazyk | věcný, kultivovaný, sebevědomý |
| 👥 Styl | partner, ne instruktor |
| 💡 Mikrocopy | „Zahajte jednání“, ne „Klikněte sem“ |
| 💰 Emoce | klidná jistota, ne hype |
| 📑 Právní bezpečnost | vždy odděluj „rezervace“ od „investice“ |

### Table 3
| Prvek | Vzor z Investown.cz / Fingood.cz | Adaptace pro Tipari |
| --- | --- | --- |
| 🏙️ Hero ilustrace projektů | realistické rendery budov | stejné, ale s jemnou modrošedou maskou |
| 💼 Procesní ilustrace (rezervace, podpisy) | Fingood – 3D gradientní ikony | u nás stylizované flat outline + jemný shadow |
| 📄 Smlouvy a podpisy | Fingood – vizuální timeline | přeneseme do „ReservationFlow“ UI (ikony: investor, developer, handshake) |
| 👤 Lidé / poradci | Investown – 2D flat charakter | u nás použít „outlined human silhouettes“ – klidné, obchodní |
| 📈 Finanční data | Fingood – přehledné modro-bílé karty | adaptujeme do tabulek a tiles s hodně whitespace |

### Table 4
| Princip | Popis |
| --- | --- |
| Decision-first UX | uživatel má vždy vidět to, co má rozhodnout (nikoliv všechno) |
| Calm Hierarchy | jedna primární barva, ostatní odstíny šedé |
| White Breathing Space | 25–35 % prostoru volný – zvyšuje důvěru |
| State Clarity | každá fáze (čekání, podpis, potvrzeno) má jinou barvu a ikonku |
| Progressive disclosure | složité informace (zajištění, dokumenty) se zobrazují až po kliknutí |
| Human feedback | potvrzení úspěchu animované jemným „pulse“ zelené |
