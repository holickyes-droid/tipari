# FORMY INVESTICE.docx

Formy investice (Tipari.cz)
🧩 1️⃣ Přehledová tabulka
🚫 Formy, které NEJSOU na Tipari.cz
(důležité pro compliance – tohle je dobré mít i interně)
🧠 Doporučená klasifikace pro UX
V kartě tiketu zobrazovat:
Formu investice (1 hlavní)
Fixní / variabilní výnos
Očekávaný horizont
Prioritu v kapitálové struktuře (senior / mezz)
Nezobrazovat:
slova „bezpečné, garantované, jisté“
🗄️ DB READY – ENUM investment_form
CREATE TYPE investment_form AS ENUM (
'direct_loan',
'mezzanine_financing',
'bridge_loan',
'profit_share',
'joint_venture',
'forward_funding',
'refinancing',
'buy_and_hold_financing',
'project_participation'
);
🔗 Vazba: forma investice × typ projektu (logika)
Bridge → pouze bridge_loan
Buy & hold → direct_loan / buy_and_hold_financing
JV projekt → joint_venture / profit_share
Refinancování → refinancing
Development → direct_loan / mezzanine_financing
⚠️ Povinná právní formulace (copy-ready)
Investice představuje obchodní příležitost a nese s sebou riziko ztráty části nebo celé investované částky.

---

## Tables

### Table 1
| # | Forma investice | Právní podstata | Výnos | Horizont | Riziko | Poznámka / omezení |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Přímá půjčka projektu | Smlouva o zápůjčce / úvěru | Fixní | Krátký–střední | 🟢–🟡 | Základní a nejčistší forma |
| 2 | Mezaninové financování | Podřízená půjčka | Fixní + bonus | Střední | 🟡–🔴 | Vyšší výnos, vyšší riziko |
| 3 | Bridge financování | Krátkodobý úvěr | Fixní | Velmi krátký | 🟡 | Časově kritické |
| 4 | Participace na zisku (profit share) | Smlouva o spolupráci | Variabilní | Střední–dlouhý | 🔴 | Bez garance výnosu |
| 5 | Joint Venture (kapitálový vstup) | Společenská / JV smlouva | Podíl na zisku | Dlouhý | 🔴🔴 | Individuální struktura |
| 6 | Forward funding | Financování výstavby | Fixní / kombinovaný | Střední | 🟡 | Čerpání po milnících |
| 7 | Refinancování | Nahrazení existujícího úvěru | Fixní | Krátký–střední | 🟢 | Nižší riziko |
| 8 | Buy & hold financování | Dlouhodobý úvěr | Fixní | Dlouhý | 🟢 | Kryto cashflow |
| 9 | Projektová participace bez kapitálového vstupu | Smluvní odměna | Výkonnostní | Různý | 🟡 | Spíš partnerské dealy |

### Table 2
| Forma | Proč ne |
| --- | --- |
| Akcie / podíly veřejně nabízené | MiFID / ZPKT |
| Dluhopisy | Regulovaný investiční nástroj |
| Crowdfunding | ECSP licence |
| Kolektivní investování | Regulace fondů |
| Garance výnosu | Zakázané tvrzení |
