# KANONICKÝ DOMAIN DICTIONARY.docx

KANONICKÝ DOMAIN DICTIONARY — POVINNÁ IMPLEMENTACE (ZÁVAZNÉ)
Tento příkaz nahrazuje veškeré předchozí nejednoznačnosti.
Od této chvíle existuje JEDINÝ ZDROJ PRAVDY pro doménová data platformy.
CÍL:
Zajistit, že UI, validace, workflow a legal texty pracují VÝHRADNĚ
s kanonickými vstupními daty definovanými níže.
Žádné domýšlení, žádné alternativy, žádné jiné labely.
────────────────────────────────
1) FORMY INVESTICE (ENUM – KONEČNÝ SEZNAM)
────────────────────────────────
Použij výhradně tyto machine keys + CZ labely:
- senior_loan → „Seniorní zápůjčka“
- junior_loan → „Juniorní zápůjčka“
- mezzanine → „Mezaninové financování“
- equity → „Kapitálový vstup“
- joint_venture → „Joint Venture“
- profit_share → „Podíl na zisku“
- convertible_loan → „Konvertibilní zápůjčka“
PRAVIDLA:
- Tento seznam je konečný.
- UI NESMÍ zobrazovat žádnou jinou formu investice.
- Labely se NESMÍ měnit.
- Všechny formuláře, filtry, badge, legal texty a validace
MUSÍ používat tyto hodnoty (machine key + CZ label mapping).
────────────────────────────────
2) TYPY PROJEKTU (ENUM – KONEČNÝ SEZNAM)
────────────────────────────────
- residential_development → „Rezidenční development“
- commercial_development → „Komerční development“
- mixed_use → „Smíšený projekt“
- logistics → „Logistika“
- hospitality → „Hotely a ubytování“
- industrial → „Průmyslový projekt“
- land_development → „Pozemkový development“
- reconstruction → „Rekonstrukce“
PRAVIDLA:
- 1:1 mapování.
- Žádné další typy projektu nesmí existovat.
────────────────────────────────
3) FORMY ZAJIŠTĚNÍ (SECURITY TYPES – KONEČNÝ SEZNAM)
────────────────────────────────
- mortgage_1st → „Zástavní právo 1. pořadí“ (PRIMARY)
- mortgage_2nd → „Zástavní právo 2. pořadí“
- pledge_shares → „Zástava podílu“
- bank_guarantee → „Bankovní záruka“
- corporate_guarantee → „Ručení mateřské společnosti“
- personal_guarantee → „Osobní ručení“
- assignment_receivables → „Postoupení pohledávek“
- escrow_account → „Escrow účet“
- notarial_enforcement → „Notářský zápis“
- insurance → „Pojištění“
- cash_collateral → „Hotovostní kolaterál“
- other_security → „Jiné zajištění“
PRAVIDLA:
- mortgage_1st MUSÍ být označeno jako primární zajištění.
- UI musí zobrazovat POŘADÍ zajištění (1., 2., …).
────────────────────────────────
4) ZNALECKÝ POSUDEK (POVINNÁ DATA)
────────────────────────────────
Každý projekt/tiket musí podporovat tato pole:
- appraised_value
- valuation_date
- valuator_name
- valuation_method
- valuation_type
- valid_until
- ltv_calculated
- document_ref
- status
- notes (volitelné)
PRAVIDLA:
- READ-ONLY zobrazení.
- Stav: Platný / Expirovaný.
- Nesmí být ignorováno v UI.
────────────────────────────────
5) VYUŽITÍ PROSTŘEDKŮ (12 KATEGORIÍ)
────────────────────────────────
- land_purchase
- construction
- reconstruction
- technology
- project_preparation
- permits
- marketing
- fees
- financing_costs
- reserve
- taxes
- other_costs
PRAVIDLA:
- Zobrazit v UI (tabulka nebo graf).
- Validace: součet = 100 %.
- Bez těchto dat NELZE projekt považovat za kompletní.
────────────────────────────────
6) ROLE & VIDITELNOST (ZÁVAZNÉ)
────────────────────────────────
- Broker: projekt, tiket, provize
- Developer: projekt, rezervace, smlouva (BEZ investora do podpisu)
- Investor: pouze vlastní smlouva (sign link)
- Admin: vše
- Employee: read-only dle oprávnění
Viditelnost se MUSÍ řídit tabulkou práv a stavů rezervace.
Žádné pole se NESMÍ zobrazit dříve, než dovoluje stav.
────────────────────────────────
7) POVINNÉ TECHNICKÉ KROKY
────────────────────────────────
- Vytvoř centrální Domain Dictionary (např. domain.ts / constants).
- UI NESMÍ mít hard-coded CZ texty mimo dictionary.
- Normalizační vrstva MUSÍ garantovat existenci všech povinných polí.
- /__selfcheck musí ukazovat:
- Domain dictionary loaded = TRUE
- Legacy imports = 0
- Data shape warnings = 0
────────────────────────────────
8) VÝSTUP, KTERÝ ODEVZDÁŠ
────────────────────────────────
- Potvrzení, že UI používá VÝHRADNĚ tato data.
- Aktualizovaná Coverage Matrix:
- Formy investice = 100 % DONE
- Typy projektu = 100 % DONE
- Zajištění = 100 % DONE
- Znalecký posudek = 100 % DONE
- Využití prostředků = 100 % DONE
- Seznam změněných souborů.
────────────────────────────────
ZÁVĚREČNÉ PRAVIDLO:
Pokud něco NENÍ v tomto Domain Dictionary,
NESMÍ to existovat v UI, datech ani logice systému.
END
1️⃣ FORM Y INVESTICE
📄 Zdroj: FORMY INVESTICE.docx, VSTUPNÍ DATA KOMPLET.docx
🔒 Pravidla:
seznam je konečný
UI nesmí zobrazovat jiné formy
labely se nesmí měnit
2️⃣ TYPY PROJEKTU
📄 Zdroj: TYPY PROJEKTU.docx
3️⃣ FORMY ZAJIŠTĚNÍ (SECURITY TYPES)
📄 Zdroj: FORMY ZAJIŠTĚNÍ.docx
🔒 Pravidlo:
Pokud je mortgage_1st, musí být označeno jako primární zajištění.
4️⃣ ZNALECKÝ POSUDEK
📄 Zdroj: ZNALECKÝ POSUDEK.docx
5️⃣ VYUŽITÍ PROSTŘEDKŮ
📄 Zdroj: VYUŽITÍ PROSTŘEDKŮ.docx
🔒 Validace:
Součet = 100 %
6️⃣ ROLE & VIDITELNOST (SHRNUTÍ)
📄 Zdroj: TABULKA PRÁVA A VIDITELNOSTI.docx

---

## Tables

### Table 1
| Machine key (enum) | UI label (CZ) | Popis | Typická zajištění | Znalecký posudek | Využití prostředků |
| --- | --- | --- | --- | --- | --- |
| senior_loan | Seniorní zápůjčka | Zápůjčka s přednostním právem na plnění | Zástavní právo 1. pořadí | POVINNÝ | POVINNÉ |
| junior_loan | Juniorní zápůjčka | Podřízená zápůjčka s vyšším rizikem | Zástava 2.+ pořadí | POVINNÝ | POVINNÉ |
| mezzanine | Mezaninové financování | Kombinace dluhu a výnosové participace | Zástava + smluvní práva | POVINNÝ | POVINNÉ |
| equity | Kapitálový vstup | Přímý kapitálový vstup do projektu | Podíl / SPV | DOPORUČENÝ | POVINNÉ |
| joint_venture | Joint Venture | Společný projekt investora a developera | Podíl + smluvní řízení | POVINNÝ | POVINNÉ |
| profit_share | Podíl na zisku | Investor se podílí na zisku projektu | Smluvní nárok | DOPORUČENÝ | POVINNÉ |
| convertible_loan | Konvertibilní zápůjčka | Dluh s možností konverze na podíl | Zástava + opce | POVINNÝ | POVINNÉ |

### Table 2
| Machine key | UI label (CZ) | Popis |
| --- | --- | --- |
| residential_development | Rezidenční development | Výstavba bytových domů |
| commercial_development | Komerční development | Kanceláře, retail |
| mixed_use | Smíšený projekt | Kombinace rezidenční a komerční |
| logistics | Logistika | Sklady, logistické parky |
| hospitality | Hotely a ubytování | Hotely, resorty |
| industrial | Průmyslový projekt | Výrobní areály |
| land_development | Pozemkový development | Příprava pozemků |
| reconstruction | Rekonstrukce | Přestavby, revitalizace |

### Table 3
| Machine key | UI label | Popis | Pořadí |
| --- | --- | --- | --- |
| mortgage_1st | Zástavní právo 1. pořadí | Primární zástava nemovitosti | 1 |
| mortgage_2nd | Zástavní právo 2. pořadí | Podřízená zástava | 2 |
| pledge_shares | Zástava podílu | Zástava obchodního podílu | — |
| bank_guarantee | Bankovní záruka | Záruka banky | — |
| corporate_guarantee | Ručení mateřské společnosti | Korporátní ručení | — |
| personal_guarantee | Osobní ručení | Ručení fyzické osoby | — |
| assignment_receivables | Postoupení pohledávek | Výnosy z projektu | — |
| escrow_account | Escrow účet | Kontrola toků peněz | — |
| notarial_enforcement | Notářský zápis | Přímá vykonatelnost | — |
| insurance | Pojištění | Pojistné krytí | — |
| cash_collateral | Hotovostní kolaterál | Blokace hotovosti | — |
| other_security | Jiné zajištění | Individuální zajištění | — |

### Table 4
| Field key | UI label | Povinnost |
| --- | --- | --- |
| appraised_value | Odhadní hodnota | POVINNÉ |
| valuation_date | Datum ocenění | POVINNÉ |
| valuator_name | Znalec | POVINNÉ |
| valuation_method | Metodika ocenění | POVINNÉ |
| valuation_type | Typ posudku | POVINNÉ |
| valid_until | Platnost do | POVINNÉ |
| ltv_calculated | LTV z posudku | POVINNÉ |
| document_ref | Dokument | POVINNÉ |
| status | Stav posudku | POVINNÉ |
| notes | Poznámka | VOLITELNÉ |

### Table 5
| Machine key | UI label | Povinnost |
| --- | --- | --- |
| land_purchase | Nákup pozemku | POVINNÉ |
| construction | Výstavba | POVINNÉ |
| reconstruction | Rekonstrukce | POVINNÉ |
| technology | Technologie | VOLITELNÉ |
| project_preparation | Projektová příprava | POVINNÉ |
| permits | Povolení | POVINNÉ |
| marketing | Marketing | VOLITELNÉ |
| fees | Poplatky | POVINNÉ |
| financing_costs | Náklady financování | POVINNÉ |
| reserve | Rezerva | POVINNÉ |
| taxes | Daně | POVINNÉ |
| other_costs | Ostatní náklady | POVINNÉ |

### Table 6
| Role | Vidí |
| --- | --- |
| Broker | Projekt, tiket, provizi |
| Developer | Projekt, rezervace, smlouvu (bez investora) |
| Investor | Pouze vlastní smlouvu (sign link) |
| Admin | Vše |
| Employee | Read-only dle oprávnění |
