# FORMY ZAJIŠTĚNÍ.docx

Přehled forem zajištění (Tipari.cz)
### 📌 Doporučené zobrazení v platformě
Karta tiketu: zobrazit hlavní zajištění + pořadí
Detail tiketu: rozpad na všechna zajištění
DB: enum + možnost kombinace více zajištění
UX: badge + hover detail
⚠️ Povinné právní upozornění (copy-ready)
Zajištění slouží ke snížení rizika investice, nikoliv jako garance návratnosti nebo výnosu.
## 🧩 DB SCHÉMA – FORMY ZAJIŠTĚNÍ
### 1️⃣ ENUM: security_type
Typ zajištění (co to je)
CREATE TYPE security_type AS ENUM (
'real_estate_mortgage',
'corporate_guarantee',
'personal_guarantee',
'promissory_note',
'share_pledge',
'notarial_enforcement',
'bank_guarantee',
'escrow_control',
'insurance'
);
### 2️⃣ ENUM: security_strength
Síla zajištění (UX + risk layer)
CREATE TYPE security_strength AS ENUM (
'low',
'medium',
'high',
'very_high'
);
### 3️⃣ TABULKA: securities
Číselník forem zajištění (master data)
CREATE TABLE securities (
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
type security_type NOT NULL,
name TEXT NOT NULL,
description TEXT,
strength security_strength NOT NULL,
is_primary BOOLEAN DEFAULT false,
is_active BOOLEAN DEFAULT true,
created_at TIMESTAMP DEFAULT now()
);
#### 📌 PŘÍKLADY DAT (seed)
### 4️⃣ TABULKA: ticket_securities
Vazba: tiket ↔ zajištění (M:N)
CREATE TABLE ticket_securities (
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
ticket_id UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
security_id UUID NOT NULL REFERENCES securities(id),
order_rank INTEGER,              -- pořadí (např. zástava 1./2.)
ltv_percent NUMERIC(5,2),         -- relevantní u nemovitostí
note TEXT,                        -- specifické podmínky
is_primary BOOLEAN DEFAULT false, -- hlavní zajištění
created_at TIMESTAMP DEFAULT now()
);
### 5️⃣ VOLITELNÉ ROZŠÍŘENÍ (doporučeno)
#### 🏠 Pro nemovitost
ALTER TABLE ticket_securities
ADD COLUMN property_id UUID NULL REFERENCES properties(id);
#### 🧾 Dokumenty k zajištění
CREATE TABLE security_documents (
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
ticket_security_id UUID REFERENCES ticket_securities(id) ON DELETE CASCADE,
document_type TEXT,
file_url TEXT,
uploaded_at TIMESTAMP DEFAULT now()
);
### 6️⃣ LOGIKA V APLIKACI (kanonická)
1 tiket = N zajištění
max 1 hlavní zajištění (is_primary = true)
order_rank povinné pouze u:
zástav
bank
ltv_percent:
pouze pokud type = real_estate_mortgage
### 7️⃣ UX MAPOVÁNÍ (aby DB dávala smysl UI)
### 8️⃣ POVINNÁ REGULAČNÍ POZNÁMKA (DB / UI)
Doporučuji hard-coded text:
Uvedené zajištění slouží ke snížení investičního rizika, nikoliv jako garance návratnosti nebo výnosu.
### ✅ VÝSLEDEK
Tento model:
❌ neklasifikuje produkt jako regulovaný
✅ umožňuje libovolné kombinace zajištění
✅ je připravený na růst
✅ funguje pro UI, DB i právní texty

---

## Tables

### Table 1
| # | Forma zajištění | Typ zajištění | Síla | Co kryje | Typické použití | Poznámka |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Zástavní právo k nemovitosti (1. pořadí) | Majetkové | 🔒🔒🔒🔒🔒 | Jistina + výnos | Konzervativní projekty | Nejsilnější forma |
| 2 | Zástavní právo k nemovitosti (2. pořadí) | Majetkové | 🔒🔒🔒🔒 | Jistina | Dev projekty s bankou | Nutné sledovat LTV |
| 3 | Křížová zástava více nemovitostí | Majetkové | 🔒🔒🔒🔒 | Jistina | Rizikovější projekty | Snižuje koncentraci rizika |
| 4 | Ručení projektovou společností (SPV) | Korporátní | 🔒🔒🔒 | Jistina | Standardní development | Závislé na bonitě |
| 5 | Ručení mateřskou společností | Korporátní | 🔒🔒🔒🔒 | Jistina | Silné developerské skupiny | Vyšší vymahatelnost |
| 6 | Osobní ručení jednatele / vlastníka | Osobní | 🔒🔒🔒 | Jistina | Menší / first-time projekty | Psychologicky silné |
| 7 | Směnka (blanko / na řad) | Právní | 🔒🔒🔒 | Jistina + sankce | Doplňkové zajištění | Nikdy samostatně |
| 8 | Zástava obchodního podílu (SPV) | Kontrolní | 🔒🔒🔒🔒 | Kontrola projektu | JV / SPV struktury | Nutná SHA |
| 9 | Notářský zápis s vykonatelností | Procesní | 🔒🔒🔒🔒🔒 | Vymahatelnost | Bridge / short-term | Velmi silné |
| 10 | Bankovní záruka | Finanční | 🔒🔒🔒🔒🔒 | Plnění závazků | Výjimečně | Vysoké náklady |
| 11 | Escrow / kontrola cashflow | Procesní | 🔒🔒🔒 | Čerpání kapitálu | Výstavba | Kontrolní mechanismus |
| 12 | Pojištění nemovitosti / stavby | Pojistné | 🔒🔒 | Škody | Doplňkové | Nikdy hlavní |

### Table 2
| type | name | strength | is_primary |
| --- | --- | --- | --- |
| real_estate_mortgage | Zástavní právo k nemovitosti | very_high | true |
| notarial_enforcement | Notářský zápis s vykonatelností | very_high | false |
| corporate_guarantee | Ručení projektovou společností | high | false |
| personal_guarantee | Osobní ručení jednatele | medium | false |
| promissory_note | Směnka | medium | false |
| escrow_control | Kontrola cashflow / escrow | medium | false |

### Table 3
| DB pole | UX význam |
| --- | --- |
| security.name | Badge text |
| security.strength | Barva / ikona |
| order_rank | „1. pořadí / 2. pořadí“ |
| ltv_percent | Tooltip / detail |
| is_primary | zvýraznění na kartě |
