#  ROZDĚLENÍ PROVIZE.docx

📊 ROZDĚLENÍ PROVIZE – ADMIN ONLY (TIPARI.CZ)
🔑 Základní princip
Admin určuje, kdo má na jakou část provize nárok.
Ostatní role data pouze vidí.
🟦 TABULKA: NASTAVENÍ ROZDĚLENÍ PROVIZE
🟩 VAZBA NA OSTATNÍ ENTITY
🧠 DOPORUČENÁ PRAVIDLA (IMPLEMENTAČNÍ)
1️⃣ Rozdělení provize se zadává až po úhradě provize developera platformě
2️⃣ Jakákoli změna = nová verze (versioning)
3️⃣
4️⃣ Změny po rezervaci → vyžadují interní schválení

---

## Tables

### Table 1
| Pole | Popis | Typ / ENUM | Kdo zadává | Poznámka |
| --- | --- | --- | --- | --- |
| Celková provize | Celková provize z tiketu | Procenta / CZK | Admin | Základ pro výpočet |
| Měna provize | Měna, ve které se provize počítá | ENUM: CZK, EUR | Admin | Musí odpovídat tiketu |
| Platforma – podíl | Podíl platformy na provizi | Procenta | Admin | Povinné pole |
| Tipař 1 – podíl | Podíl primárního tipaře | Procenta | Admin | Přímý vztah k investorovi |
| Tipař 2 – podíl | Podíl sekundárního tipaře | Procenta | Admin | Přímý vztah k projektu |
| Součet podílů | Kontrolní součet | Automaticky | Systém | Musí = 100 % |
| Typ rozdělení | Jak je provize rozdělena | ENUM: Fixní %, Individuální dohoda | Admin | Pro audit |
| Důvod rozdělení | Interní poznámka admina | Text | Admin | Nezobrazovat tipařům |
| Okamžik vzniku nároku | Kdy vzniká nárok na provizi | ENUM: Přijatá platba od developera | Admin | Navázáno na tiket |
| Okamžik vyplacení | Kdy je provize vyplacena | ENUM: Ihned, Po splnění podmínek, Jiný | Admin | Navázáno na tiket |
| Stav rozdělení | Aktuální stav | ENUM: Draft, Schváleno, Vyplaceno | Systém | Workflow |
| Datum nastavení | Datum vytvoření rozdělení | Datum | Systém | Audit |
| Nastavil admin | Identifikace admina | User ID | Systém | Audit |

### Table 2
| Entita | Vazba |
| --- | --- |
| Projekt | nepřímo (přes tiket) |
| Tiket | přímá vazba (1:1 nebo 1:N dle verze) |
| Tipař 1 | User ID / Role = tipař |
| Tipař 2 | User ID / Role = tipař |
| Platforma | Interní účet platformy |
