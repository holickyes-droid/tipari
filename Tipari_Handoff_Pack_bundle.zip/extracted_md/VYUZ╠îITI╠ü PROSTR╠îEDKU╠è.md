# VYUŽITÍ PROSTŘEDKŮ.docx

Využití prostředků (Use of Funds)
🧩 1️⃣ Přehledová tabulka
🧠 Doporučená pravidla (best practice)
Co ANO
jasně definované použití
vazba na typ projektu
procentuální rozpad (alespoň orientační)
logika: peníze → aktivum / hodnota
Co NE
vágní formulace („obecné účely“)
přesuny mimo projekt
výplata zisku před splněním podmínek
🗄️ DB READY – ENUM use_of_funds
CREATE TYPE use_of_funds AS ENUM (
'property_acquisition',
'construction',
'reconstruction',
'refinancing',
'bridge_financing',
'capex_reserve',
'operational_costs',
'technical_preparation',
'marketing_and_sales',
'tax_and_transaction_costs',
'partner_buyout',
'combined_use'
);
🔗 Vazba: využití prostředků × typ projektu (validace)
⚠️ Povinná právní formulace (copy-ready)
Uvedené využití prostředků je plánované a může se v průběhu realizace projektu měnit v závislosti na vývoji projektu.

---

## Tables

### Table 1
| # | Využití prostředků | Popis | Typické projekty | Riziko | Poznámka |
| --- | --- | --- | --- | --- | --- |
| 1 | Nákup nemovitosti | Akvizice pozemku / budovy | Buy & hold, development | 🟢 | Nejčistší použití |
| 2 | Výstavba | Hrubá stavba, dokončení | Rezidenční / komerční dev | 🟡 | Nutná kontrola čerpání |
| 3 | Rekonstrukce | Stavební úpravy, modernizace | Rekonstrukce, brownfield | 🟡 | Milníkové čerpání |
| 4 | Refinancování závazků | Splacení úvěru / půjčky | Refinancování | 🟢 | Snižuje riziko |
| 5 | Překlenovací financování | Krátkodobý cashflow gap | Bridge financování | 🟡 | Časově citlivé |
| 6 | Projektová rezerva (CAPEX) | Nečekané náklady | Development | 🟢–🟡 | Doporučeno |
| 7 | Provozní náklady projektu | Energie, správa, služby | Buy & hold | 🟢 | Kryto cashflow |
| 8 | Technická příprava projektu | Projekce, studie, povolení | Land, dev | 🟡 | Předvýstavbová fáze |
| 9 | Marketing a prodej | Prodejní náklady | Rezidenční dev | 🟡 | Omezený podíl |
| 10 | Daňové a transakční náklady | Daň, poplatky, právní služby | Všechny | 🟢 | Standardní |
| 11 | Splacení společníka / investora | Interní restrukturalizace | JV / SPV | 🟡 | Nutná transparentnost |
| 12 | Kombinované využití | Více účelů současně | Většina projektů | 🟡 | Nutný rozpad v detailu |

### Table 2
| Typ projektu | Povolené využití |
| --- | --- |
| Rezidenční development | Nákup, výstavba, marketing, rezerva |
| Rekonstrukce | Rekonstrukce, technická příprava |
| Buy & hold | Nákup, provoz, CAPEX |
| Refinancování | Refinancování |
| Bridge | Překlenovací financování |
| Land development | Technická příprava |
| JV | Kombinované |
