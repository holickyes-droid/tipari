# REGISTRACE OBCHODNIK DEVELOPER.docx

A) REGISTRACE OBCHODNÍKA (BROKERA / TIPAŘE)
Cíl:
✔ vědět, kdo je obchodník
✔ kdo za něj právně odpovídá
✔ jakou má roli v provizním a rezervačním flow
A1️⃣ ZÁKLADNÍ IDENTIFIKAČNÍ DATA (POVINNÁ)
A2️⃣ AML / KYC DATA OBCHODNÍKA – zatím nezahrnovat do ux,ui
A3️⃣ OBCHODNÍ PROFIL OBCHODNÍKA
A4️⃣ PRÁVNÍ A SMLUVNÍ SOUHLASY
A5️⃣ INTERNÍ SYSTÉMOVÁ DATA (GENEROVÁNA)
Broker ID (UUID)
Stav účtu
ENUM: Pending / Ověřen / Aktivní / Pozastaven / Zablokován
Datum registrace
Ověřil admin (user_id)
Audit log
B) REGISTRACE DEVELOPERA (ZADAVATELE PROJEKTU)
Cíl:
✔ vědět, kdo projekty zadává
✔ kdo je oprávněná osoba
✔ že má právo s projektem nakládat
B1️⃣ ZÁKLADNÍ IDENTIFIKAČNÍ DATA (POVINNÁ)
B2️⃣ OPRÁVNĚNÁ OSOBA (STATUTÁR / ZÁSTUPCE)
B3️⃣ PROFIL DEVELOPERA
B4️⃣ PRÁVNÍ A SMLUVNÍ SOUHLASY
B5️⃣ INTERNÍ SYSTÉMOVÁ DATA (GENEROVÁNA)
Developer ID (UUID)
Stav účtu
ENUM: Pending / Ověřen / Aktivní / Pozastaven / Zablokován
Datum registrace
Ověřil admin (user_id)
Audit log
🧠 KLÍČOVÝ ROZDÍL (DŮLEŽITÉ)
zatím nezasazujeme na platformu

---

## Tables

### Table 1
| Pole | Typ / ENUM | Poznámka |
| --- | --- | --- |
| Typ subjektu | ENUM: Fyzická osoba / Právnická osoba | Určuje další pole |
| Jméno a příjmení (FO) | Text | Povinné |
| Název společnosti (PO) | Text | Povinné |
| IČO (PO) | Text | Povinné |
| Datum narození (FO) | Datum | AML |
| Státní příslušnost | Text | AML |
| Daňová rezidence | Text | AML |
| E-mail | Email | Přihlašovací |
| Telefon | Telefon | Ověření |
| Adresa bydliště / sídla | Text | Povinné |

### Table 2
| Pole | Typ / ENUM | Poznámka |
| --- | --- | --- |
| Typ dokladu | ENUM: OP / Pas | Povinné |
| Číslo dokladu | Text | Povinné |
| Platnost dokladu | Datum | Povinné |
| Stát vydání | Text | Povinné |
| Kopie dokladu | Soubor | Povinné |
| Selfie / video-identifikace | Soubor | Povinné |
| PEP status | ENUM: Ano / Ne | Povinné |
| Sankční seznamy | ENUM: Bez nálezu / Nález | Systém |
| Zdroj příjmů | ENUM: Podnikání / Zaměstnání / Jiný | Povinné |

### Table 3
| Pole | Typ / ENUM | Poznámka |
| --- | --- | --- |
| Typ spolupráce | ENUM: Nezávislý / Vázaný / Interní | Interní logika |
| Region působnosti | MULTI-ENUM: Kraje / Země | Matching |
| Specializace | MULTI-ENUM: Reality / Development / Energetika / Ostatní / Dluh / Ekvita | Matching |
| Typičtí investoři | ENUM: Retail / HNWI / Institucionální | Informativní |
| Průměrná velikost dealu | Číslo (CZK) | Informativní |
| Preferovaná komunikace | ENUM: Telefon / Email / Osobně | UX |

### Table 4
| Pole | Typ | Poznámka |
| --- | --- | --- |
| Rámcová smlouva s platformou | Souhlas / Podpis | Povinné |
| NDA | Souhlas / Podpis | Povinné |
| Provizní podmínky | Souhlas | Povinné |
| Etický kodex | Souhlas | Povinné |
| GDPR souhlas | Souhlas | Povinné |

### Table 5
| Pole | Typ / ENUM | Poznámka |
| --- | --- | --- |
| Typ subjektu | ENUM: Právnická osoba / FO podnikatel | Povinné |
| Název společnosti | Text | Povinné |
| IČO | Text | Povinné |
| DIČ | Text | Volitelné |
| Sídlo společnosti | Text | Povinné |
| Země registrace | Text | Povinné |
| E-mail | Email | Přihlašovací |
| Telefon | Telefon | Ověření |

### Table 6
| Pole | Typ / ENUM | Poznámka |
| --- | --- | --- |
| Jméno a příjmení | Text | Povinné |
| Funkce | Text | Povinné |
| Datum narození | Datum | AML |
| Státní příslušnost | Text | AML |

### Table 7
| Pole | Typ / ENUM | Poznámka |
| --- | --- | --- |
| Zaměření | MULTI-ENUM: Rezidenční / Logistika / Komerční / Development / Energetika / Energetika | Matching |
| Počet realizovaných projektů | Číslo | Informativní |
| Celkový objem projektů | Číslo (CZK) | Informativní |
| Typické financování | ENUM: Banka / Privátní kapitál / Jiné / Kombinace | Informativní |
| Regiony působnosti | MULTI-ENUM | Matching |
| Web / prezentace | URL | Volitelné |

### Table 8
| Pole | Typ | Poznámka |
| --- | --- | --- |
| Rámcová smlouva s platformou | Podpis | Zadává admin ručně do profilu developera |
| Prohlášení o oprávnění k projektu | Souhlas | Povinné |
| Anti-obcházející ujednání | Souhlas | Zadává admin ručně do profilu developera |
| GDPR souhlas | Souhlas | Povinné |

### Table 9
| Oblast | Obchodník | Developer |
| --- | --- | --- |
| Práce s investory | Ano | Ne |
| Zadávání projektů | Ano | Ano |
| Rezervace | Ano | Ne |
| Provize | Nárok po rozhodnutí admina | Platí platformě |
| AML/KYC | Povinné – zatím nezasazujeme na platformu | Povinné (statutár) |
