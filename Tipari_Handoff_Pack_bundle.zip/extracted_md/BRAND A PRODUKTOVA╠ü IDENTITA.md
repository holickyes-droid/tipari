# BRAND A PRODUKTOVÁ IDENTITA.docx

1️⃣ BRAND A PRODUKTOVÁ IDENTITA
2️⃣ CÍLOVÉ SKUPINY
3️⃣ HLAVNÍ FUNKCE PLATFORMY
4️⃣ UX PRINCIPY (HYBRID v2.0)
5️⃣ OBSAHOVÉ BLOKY KARTY TIKETU
6️⃣ DESIGN & UI SYSTÉM
7️⃣ OBCHODNÍ MODEL & LOGIKA
8️⃣ TONE OF VOICE

---

## Tables

### Table 1
| Otázka | Odpověď |
| --- | --- |
| Název projektu: | Tipari.cz |
| Typ produktu: | B2B investiční platforma pro obchodníky a developery (zprostředkování investic formou tiketů). |
| Mise značky: | Propojovat investory, developery a obchodníky prostřednictvím transparentních investičních příležitostí. |
| Vize: | Vytvořit nový standard profesionálního realitního investování v Česku – přehledně, férově, s lidským přístupem. |
| Hodnoty značky: | Důvěra, transparentnost, profesionalita, respekt, jistota, jednoduchost. |
| Styl značky: | Hybrid – blízký a přátelský, ale prémiový a odborný. |
| Reference pro vizuální styl: | investown.cz, fingood.cz – čisté, moderní, s důrazem na přehlednost. |

### Table 2
| Segment | Popis |
| --- | --- |
| 🧍‍♂️ Obchodník / zprostředkovatel | Profesionál, který pracuje s investory, vybírá pro ně vhodné projekty, sleduje provize a uzavírá rezervace. |
| 💼 Developer / žadatel o investici | Potřebuje financování projektu (development, akvizice, refinancování, apod.). |
| 💰 Investor (klient obchodníka) | Vyhledává investice dle svých preferencí (výnos, zajištění, délka, typ investice, lokalita). |
| ⚖️ Administrátor / tým Tipari | Spravuje projekty, tikety a rezervace. |

### Table 3
| Funkce | Popis |
| --- | --- |
| 🎟️ Tikety (investiční příležitosti) | Každý tiket = konkrétní investice (část projektu). Obsahuje výnos, provizi, LTV, zajištění atd. |
| 💬 Matching investorů | Na základě preferencí obchodníků se doporučují ideální investoři pro daný tiket. |
| 🧩 Rezervace tiketů | Obchodník může rezervovat tiket → má 48h na podpis smlouvy investorem → pak developer schvaluje. |
| 💰 Provize tipaře | Zobrazuje odměnu v Kč, ne v %. Klíčová motivace. |
| 🔐 Zajištění investice | Může mít více úrovní (např. zástava, směnka, notářský zápis). Hodnoceno jako klíčový faktor důvěry. |
| 📈 Výnos a LTV | Ukazatele výkonnosti a rizika. Kliknutím se otevře detailní vysvětlení. |
| 👁️ Přehled a filtrace | Filtry podle typu, výnosu, LTV, zajištění, dostupnosti, lokace, investor matchingu. |
| 🏆 Tier / Level obchodníka | Rozlišuje úrovně přístupu a počet dostupných slotů (Partner, Premium, Elite). |

### Table 4
| Princip | Popis |
| --- | --- |
| 🧭 Decision-first UX | Uživatel musí okamžitě vidět, co je pro něj důležité (provize, výnos, zajištění). |
| 🎯 Eye-movement hierarchy | Horní levý kvadrant = projekt, prostřední část = výnos & provize, pravá část = akce. |
| 🧩 Compliance clarity | Texty rozlišují rezervaci × investici, právní přesnost bez zahlcení. |
| 🧠 Psychologická motivace | Kombinuje urgentnost (čas, dostupnost) + jistotu (zajištění, transparentnost). |
| 🎨 Hybridní tón komunikace | Přátelský, důvěryhodný, profesionální, ne korporátní ani přehnaně familiární. |

### Table 5
| Oblast | Priorita | Popis |
| --- | --- | --- |
| 💰 Provize pro tipaře | 🥇 Nejvyšší – hlavní motivace obchodníka. Velké, čitelné, nahoře. |  |
| 📈 Výnos p.a. | 🥈 Klíčová informace pro investora. V zelené barvě (pozitivní, růstová). |  |
| 🛡️ Zajištění | 🥉 Nejvíce ovlivňuje důvěru. Tooltip se seznamem typů zajištění. |  |
| 🧾 LTV | Doplňkový ukazatel rizika, kliknutím otevře detail. |  |
| 💼 Typ investice | Barevné odlišení + krátký popis (Ekvita, Mezanin, Dluh…). |  |
| 🤝 Shoda s investory | Kliknutím otevře InvestorMatchesModal. Ukazuje počet a důvody shody. |  |
| ⏱️ Do uzávěrky | Psychologický „časový tlak“. <30 dní = červeně, <90 dní = oranžově. |  |
| 🎟️ Volné rezervace | Praktická informace pro rozhodnutí. Zobrazuje dostupné sloty. |  |
| 🧾 Podíl na zisku | Ikona „✓“ nebo „📊“ — viditelně, ale decentně. |  |
| 🔘 Rezervovat tiket | Jasné CTA, modré tlačítko, microcopy: „Rezervace platná po podpisu smlouvy do 48 h.“ |  |

### Table 6
| Prvek | Definice |
| --- | --- |
| 🎨 Barevná paleta | Primární: #215EF8 (brand blue), Sekundární: #14AE6B (success green), Text: #040F2A, Neutral: #F9FAFB |
| 🔤 Typografie | Poppins / Inter (600–700 headings, 400–500 body), tabulární čísla pro finanční údaje |
| 🧱 Komponenty | Dlaždicové karty, modální okna, sticky filtry, hover efekty, microinteractions |
| 🧠 Psychologické vrstvy | Použití světla, prostoru a hierarchie k vyvolání pocitu jistoty a exkluzivity |
| 🪶 Microcopy tón | Hybrid Friendly: “Srozumitelně, lidsky, bez nadbytečných slov. Každé slovo má váhu.” |

### Table 7
| Prvek | Popis |
| --- | --- |
| 🧮 Rezervace | Platná až po podpisu smlouvy investorem. Obchodník má 48h. |
| 💼 Globální sloty obchodníka | Každý obchodník má 10 globálních slotů (podle úrovně Partner/Premium/Elite). |
| 🔢 Max. rezervace na tiket | Max 3 aktivní rezervace na 1 tiket. |
| 💸 Provize výhradně v Kč | Nikdy ne v %. |
| 🧭 Investor matching | Na základě preferencí (lokalita, typ, výnos, zajištění). |
| 🔐 Zajištění | Více typů (Zástava, Směnka, Notářský zápis, atd.) — nikdy ne kombinace s „Bez zajištění“. |

### Table 8
| Aspekt | Styl |
| --- | --- |
| Osobnost | “Odborník, který mluví lidsky.” |
| Tón | Klidný, sebejistý, přátelský. Nikdy agresivní nebo příliš technický. |
| Příklad textu | „Rezervací si zajistíte přednostní přístup. Smlouvu potvrdíte během 48 hodin.“ |
| Zákaznická psychologie | Vyvolává pocit důvěry, kompetence a férovosti. |
