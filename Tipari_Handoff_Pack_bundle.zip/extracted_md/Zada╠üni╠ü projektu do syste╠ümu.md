# Zadání projektu do systému.docx

📊 VSTUPNÍ DATA – PROJEKT & TIKET (TIPARI.CZ)
Legenda rolí (TEXT)
Zadává = může vyplnit / editovat
Zdroj informace = kdo odpovídá za správnost
Schvaluje = potvrzuje finální platnost / publikaci
🟦 A) DATA O PROJEKTU
A1️⃣ Základní identifikace projektu
A2️⃣ Lokalita & nemovitost
A3️⃣ Developer / vlastník projektu
A4️⃣ Finanční rámec projektu
A5️⃣ Právní & technický stav
A6️⃣ Dokumenty k projektu
🟩 B) DATA O TIKETU
B1️⃣ Základní parametry tiketu
B2️⃣ Výnos & doba
B3️⃣ Zajištění tiketu
B4️⃣ Investiční struktura
B5️⃣ Rezervace & proces
B6️⃣ Provize & obchodní podmínky
B7️⃣ Dokumenty k tiketu
🧠 FINÁLNÍ ARCHITEKTONICKÁ VĚTA
Všichni mohou navrhovat data.
Platforma rozhoduje, co je finální a závazné.
#### NAVRŽENÉ DALŠÍ KROKY
Chceme-li tato data implementovat v rámci sandboxového vývoje (bez backendu), doporučuji:
Prompt 58 – Project & Ticket Data Models (Sandbox JSON Schema)
→ vytvoří statické struktury MOCK_PROJECTS a MOCK_TICKETS podle tohoto zadání,
včetně validace a rolové hierarchie.
Prompt 59 – Project Entry & Approval Flow
→ vizuální komponenty pro vložení projektu (developer), kontrolu (obchodník), schválení (admin).
Prompt 60 – Ticket Generator & Binding
→ automatické generování tiketů z projektu podle parametrů financování a zajištění.
Prompt 61 – Project Lifecycle Simulation
→ simuluje stav projektu (draft → review → approved → published).

---

## Tables

### Table 1
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Název projektu | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Typ projektu | ENUM: Rezidenční, Logistika, Komerční, Smíšený, Retail, Hotel, Pozemek, Energetika, Ostatní | Zadává, Zdroj informace | Zadává | Schvaluje |
| Stručný popis projektu | Text (3–5 vět) | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 2
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Obec / město | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Kraj | ENUM: Hlavní město Praha, Středočeský, Jihočeský, Plzeňský, Karlovarský, Ústecký, Liberecký, Královéhradecký, Pardubický, Vysočina, Jihomoravský, Olomoucký, Zlínský, Moravskoslezský | Zadává, Zdroj informace | Zadává | Schvaluje |
| Přesná adresa | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Popis nemovitosti | Text | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 3
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Název společnosti | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| IČO | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Sídlo společnosti | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Kontaktní osoba – jméno | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Kontaktní osoba – e-mail | Email | Zadává, Zdroj informace | Zadává | Schvaluje |
| Kontaktní osoba – telefon | Telefon | Zadává, Zdroj informace | Zadává | Schvaluje |
| Profil developera | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Reference developera | Text | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 4
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Celkový rozpočet projektu | Číslo (CZK) | Zadává, Zdroj informace | Zadává | Schvaluje |
| Vlastní kapitál | Číslo (CZK) | Zadává, Zdroj informace | Zadává | Schvaluje |
| Cizí zdroje – typ | ENUM: Banka, Úvěr, Jiné | Zadává, Zdroj informace | Zadává | Schvaluje |
| Cizí zdroje – výše | Číslo | Zadává, Zdroj informace | Zadává | Schvaluje |
| Orientační podmínky | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Účel financování | ENUM: Koupě, Výstavba, Refinancování, Provoz, Prodej | Zadává, Zdroj informace | Zadává | Schvaluje |
| Harmonogram projektu | Text | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 5
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Vlastnický stav | ENUM: Vlastník, SPV | Zadává, Zdroj informace | Zadává | Schvaluje |
| Stavební stav | ENUM: Povolení ANO, Povolení NE | Zadává, Zdroj informace | Zadává | Schvaluje |
| Existující zástavy | Text | Zadává, Zdroj informace | Zadává | Schvaluje |
| Věcná břemena | Text | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 6
| Dokument | Typ | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| List vlastnictví | Soubor (PDF) | Zadává, Zdroj informace | Zadává | Schvaluje |
| Projektová dokumentace | Soubor | Zadává, Zdroj informace | Zadává | Schvaluje |
| Rozpočet projektu | Soubor | Zadává, Zdroj informace | Zadává | Schvaluje |
| Term sheet / shrnutí | Soubor | Zadává, Zdroj informace | Zadává | Schvaluje |
| Další podklady | Soubor | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 7
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Typ tiketu | ENUM: Dluhový, Ekvitní, Mezanin, Jiné | Zadává, Zdroj informace | Zadává | Schvaluje |
| Investiční částka | Číslo (CZK) | Zadává, Zdroj informace | Zadává | Schvaluje |
| Měna | ENUM: CZK, EUR | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 8
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Výnos p.a. | Procenta | Zadává, Zdroj informace | Zadává | Schvaluje |
| Forma výnosu | ENUM: Fixní, Variabilní, Jednáním | Zadává, Zdroj informace | Zadává | Schvaluje |
| Podíl na zisku | ENUM: Ano, Ne, Jednáním | Zadává, Zdroj informace | Zadává | Schvaluje |
| Doba trvání | Číslo + ENUM: měsíce, roky | Zadává, Zdroj informace | Zadává | Schvaluje |
| Výplata výnosu | ENUM: Měsíční, Kvartální, Pololetní, Roční, Na konci | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 9
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Je investice zajištěná | ENUM: Ano, Ne | Zadává, Zdroj informace | Zadává | Schvaluje |
| Typ zajištění | MULTI-ENUM: Zástava 1. pořadí, Zástava 2. pořadí, Zástava k OP, KL, Akcie (s.r.o., a.s.), Osobní směnka, Firemní směnka, Notářský zápis, Notářský zápis s přímou vykonatelností, Ručitelský závazek, Postoupení pohledávek, Zástava movitých věcí, Zajištění nájmů, Převedení vlastnictví se zpětným odkupem, Zajišťovací blankosměnka, Bez zajištění | Zadává, Zdroj informace | Zadává | Schvaluje |
| Pořadí zástavy | ENUM: 1., 2., Jiné | Zadává, Zdroj informace | Zadává | Schvaluje |
| Odhad LTV | Procenta | Zadává, Zdroj informace | Zadává | Schvaluje |
| Popis zajištění | Text | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 10
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Použití prostředků | MULTI-ENUM: Development, Financování, Refinancování, Akvizice shares, Akvizice asset, Redevelopment, Prodej asset, Prodej SPV | Zadává, Zdroj informace | Zadává | Schvaluje |
| Vztah tiketu k projektu | ENUM: Seniorní, Podřízený, Jiné | Zadává, Zdroj informace | Zadává | Schvaluje |
| Exit strategie | ENUM: Prodej, Refinancování, Splacení z provozu, Jiné | Zadává, Zdroj informace | Zadává | Schvaluje |

### Table 11
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Maximální počet rezervací | Číslo | Zadává | Zadává | Schvaluje |
| Délka rezervace (SLA) | ENUM: 48 h, 72 h, Jiná | Zadává | Zadává | Schvaluje |

### Table 12
| Pole | Typ / ENUM hodnoty | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Výše provize celkem | Procenta / CZK | Zadává | Zadává | Schvaluje |
| Rozdělení provize | Procenta | Zadává | Zadává | Schvaluje |
| Okamžik vzniku nároku | ENUM: Podpis investiční smlouvy, Převod prostředků, Jiné | Zadává | Zadává | Schvaluje |
| Okamžik vyplacení | ENUM: Ihned, Po splnění podmínek, Jiné | Zadává | Zadává | Schvaluje |

### Table 13
| Dokument | Typ | Developer | Obchodník | Admin |
| --- | --- | --- | --- | --- |
| Rezervační smlouva / podklady | Soubor | Zadává | Zadává | Schvaluje |
| Investiční smlouva | Soubor | Zadává | Zadává | Schvaluje |
| Specifické podmínky tiketu | Text | Zadává | Zadává | Schvaluje |
| Rizika spojená s tiketem | Text | Zadává | Zadává | Schvaluje |
