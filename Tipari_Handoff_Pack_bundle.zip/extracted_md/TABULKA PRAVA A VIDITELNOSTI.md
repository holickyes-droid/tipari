# TABULKA PRAVA A VIDITELNOSTI.docx

🧭 TABULKA VIDITELNOSTI – VŠECHNY ROLE A STAVY
🔒 PŘEHLED VIDITELNOSTI POLE (atributů)
📊 Barevné značení stavů (Figma prototyp)

---

## Tables

### Table 1
| 🔢 Stav rezervace | 👤 Obchodník | 💼 Investor | 🏗️ Developer | 🧑‍💼 Platforma |
| --- | --- | --- | --- | --- |
| 1️⃣ Rezervace v přípravě (reservation_in_progress) | Vidí parametry projektu (výnos, LTV, doba, částka, zajištění). ❌ Nevidí název ani obrázek projektu. | Vidí totéž co obchodník (základní parametry). | Vidí vše o projektu, ale nevidí žádné informace o investorovi ani obchodníkovi. | Vidí vše o projektu, obchodníkovi i investorovi. |
| 2️⃣ Odesláno ke schválení platformou (reservation_submitted_to_platform) | Vidí parametry projektu + čekací banner: „Rezervace odeslána ke schválení platformě.“ | Nevidí nic navíc, pouze potvrzení o odeslání. | Vidí projekt + banner: „Nový investor čeká na schválení platformou.“ | Vidí vše + tlačítka „Schválit / Zamítnout investora“. |
| 3️⃣ Kontrola platformy (platform_due_diligence) | Čekací stav: vidí banner „Probíhá ověření investora.“ | Nevidí nic nového, čeká na výsledek. | Vidí projekt + banner „Investor v ověřování“. | Aktivní práce platformy – vidí vše a provádí kontrolu. |
| 4️⃣ Schváleno platformou (platform_approved) | Vidí notifikaci „Investor schválen — čeká se na podpis smlouvy.“ | Obdrží e-mail s eSign podpisem smlouvy. | Vidí projekt + banner „Investor čeká na podpis smlouvy.“ | Vidí vše a spravuje stav. |
| 5️⃣ Investor podepsal (investor_signed) | Vidí „Investor podepsal smlouvu — čeká se na potvrzení developera.“ | Vidí detail projektu (odemknutý), jméno developera zatím skryté. | Vidí projekt + banner „Investor podepsal — potvrďte zájem.“ (bez jména investora) | Vidí vše. |
| 6️⃣ Developer potvrdil (developer_confirmed) | Vidí: všechny informace projektu + potvrzený stav. | Vidí: všechny informace projektu. | Vidí: jméno investora a obchodníka (odemčeno). | Vidí vše. |
| 7️⃣ Rezervace aktivní (active_reservation) | Vidí kompletní informace o projektu, investorovi i developerovi. | Vidí kompletní informace. | Vidí kompletní informace. | Vidí kompletní informace. |
| 8️⃣ Rezervace zrušena / vypršela (expired / cancelled) | Vidí jen základní parametry projektu (výnos, LTV, zajištění). | Vidí jen základní parametry projektu. | Vidí pouze informace o projektu (bez investorů). | Vidí vše, včetně historie rezervace. |

### Table 2
| Atribut | Obchodník | Investor | Developer | Platforma |
| --- | --- | --- | --- | --- |
| Název projektu | 🔒 (do podpisu) | 🔒 (do podpisu) | ✅ | ✅ |
| Obrázek projektu | 🔒 (do podpisu) | 🔒 (do podpisu) | ✅ | ✅ |
| Výnos p.a. | ✅ | ✅ | ✅ | ✅ |
| Částka | ✅ | ✅ | ✅ | ✅ |
| LTV | ✅ | ✅ | ✅ | ✅ |
| Doba | ✅ | ✅ | ✅ | ✅ |
| Zajištění | ✅ | ✅ | ✅ | ✅ |
| Typ investice | ✅ | ✅ | ✅ | ✅ |
| Finanční přehled projektu | 🔒 (do podpisu) | 🔒 (do podpisu) | ✅ | ✅ |
| Dokumenty ke stažení | 🔒 (do podpisu) | 🔒 (do podpisu) | ✅ | ✅ |
| Jméno investora | ✅ | — | 🔒 (do podpisu) | ✅ |
| Kontakt investora | ✅ | — | 🔒 (do podpisu) | ✅ |
| Jméno obchodníka | ✅ | 🔒 | 🔒 (do podpisu) | ✅ |
| Kontakt obchodníka | ✅ | 🔒 | 🔒 (do podpisu) | ✅ |
| Provize obchodníka | ✅ | 🔒 | 🔒 | ✅ |
| NDA / Podmínky | ✅ | ✅ | ✅ | ✅ |
| Stav rezervace | ✅ | ✅ | ✅ | ✅ |

### Table 3
| Barva | Stav | Význam |
| --- | --- | --- |
| 🔵 Modrá | reservation_submitted_to_platform | Odesláno ke schválení |
| 🟡 Žlutá | platform_due_diligence | Kontrola platformy |
| 🟢 Zelená | platform_approved, active_reservation | Schváleno / Aktivní |
| 🟠 Oranžová | investor_signed | Čeká se na potvrzení developera |
| ⚪ Šedá | expired / cancelled | Vypršelo / Zrušeno |
