# VSTUPNÍ DATA O INVESTOROVI.docx

VSTUPNÍ DATA O INVESTOROVI – TIPARI.CZ
Rozdělení rolí: ADMIN × BROKER
Legenda (textově, jednoznačně)
Zadává = může vytvořit / editovat hodnotu
Zdroj pravdy = odpovídá za správnost a závaznost
Vidí = má přístup ke čtení
### 🟦 A) ZÁKLADNÍ IDENTIFIKACE INVESTORA
### 🟨 B) AML / KYC / COMPLIANCE = neimplementujeme do ux a ui
Kritická data – Admin je vždy zdroj pravdy
### 🟩 C) OBCHODNÍ VZTAH & HISTORIE
### 🟪 D) INVESTIČNÍ PREFERENCE INVESTORA
Broker preference sbírá. Admin je schvaluje jako platné.
#### D1️⃣ Finanční preference
#### D2️⃣ Riziko & zajištění
#### D3️⃣ Typy projektů & lokality
#### D4️⃣ Investiční struktura
### 🟫 E) KOMUNIKACE & SOUHLASY
### 🧠 FINÁLNÍ SYSTÉMOVÝ PRINCIP
Broker data sbírá.
Admin je potvrzuje jako pravdu.
Systém zajišťuje audit a kontinuitu.

---

## Tables

### Table 1
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Typ investora | ENUM: Fyzická osoba / Právnická osoba | Zadává, Zdroj pravdy | Zadává |
| Jméno / Název | Text | Zadává, Zdroj pravdy | Zadává |
| Datum narození (FO) | Datum | Zadává, Zdroj pravdy | Nezadává |
| IČO (PO) | Text | Zadává, Zdroj pravdy | Zadává |
| DIČ | Text | Zadává, Zdroj pravdy | Zadává |
| Státní příslušnost | Text | Zadává, Zdroj pravdy | Zadává |
| Daňová rezidence | Text | Zadává, Zdroj pravdy | Zadává |
| E-mail | Email | Zadává, Zdroj pravdy | Zadává |
| Telefon | Telefon | Zadává, Zdroj pravdy | Zadává |
| Adresa bydliště / sídla | Text | Zadává, Zdroj pravdy | Zadává |
| Korespondenční adresa | Text | Zadává, Zdroj pravdy | Zadává |

### Table 2
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Typ identifikačního dokladu | ENUM: OP / Pas | Zadává, Zdroj pravdy | Vidí |
| Číslo dokladu | Text | Zadává, Zdroj pravdy | Vidí |
| Platnost dokladu | Datum | Zadává, Zdroj pravdy | Vidí |
| Stát vydání dokladu | Text | Zadává, Zdroj pravdy | Vidí |
| Kopie dokladu | Soubor | Zadává, Zdroj pravdy | Vidí |
| Video / selfie identifikace | Soubor | Zadává, Zdroj pravdy | Vidí |
| Politicky exponovaná osoba (PEP) | ENUM: Ano / Ne | Zadává, Zdroj pravdy | Vidí |
| Sankční seznamy | ENUM: Bez nálezu / Nález | Zadává, Zdroj pravdy | Vidí |
| Zdroj prostředků | ENUM: Podnikání / Zaměstnání / Investice / Dědictví / Jiný | Zadává, Zdroj pravdy | Vidí |
| Odhadovaný roční objem investic | Číslo | Zadává, Zdroj pravdy | Vidí |

### Table 3
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Primární broker | User ID | Zadává, Zdroj pravdy | Vidí |
| Stav investora | ENUM: Nový / Aktivní / Neaktivní / Blokovaný | Zadává, Zdroj pravdy | Vidí |
| Historie rezervací | Systémová data | Vidí | Vidí |
| Historie investic | Systémová data | Vidí | Vidí |
| Celkový objem investic | Číslo | Vidí | Vidí |

### Table 4
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Min. investice | Číslo (CZK) | Zadává, Zdroj pravdy | Zadává |
| Max. investice | Číslo (CZK) | Zadává, Zdroj pravdy | Zadává |
| Preferovaná měna | ENUM: CZK / EUR | Zadává, Zdroj pravdy | Zadává |
| Minimální výnos p.a. | % | Zadává, Zdroj pravdy | Zadává |
| Max. délka investice | Číslo + ENUM: měsíce / roky | Zadává, Zdroj pravdy | Zadává |
| Výplata výnosu | Dle enum tiketů a projektů | Zadává, Zdroj pravdy | Zadává |

### Table 5
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Požadavek na zajištění | ENUM: Ano / Ne / Preferováno | Zadává, Zdroj pravdy | Zadává |
| Preferované typy zajištění | Dle enum tiketů a projektů | Zadává, Zdroj pravdy | Zadává |
| Maximální LTV | % | Zadává, Zdroj pravdy | Zadává |

### Table 6
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Preferované typy projektů | MULTI-ENUM: Rezidenční, Komerční, Logistika, Retail, Energetika, Pozemky | Zadává, Zdroj pravdy | Zadává |
| Preferovaná fáze projektu | ENUM: Příprava / Výstavba / Provoz | Zadává, Zdroj pravdy | Zadává |
| Preferované regiony | MULTI-ENUM: Kraje / Město | Zadává, Zdroj pravdy | Zadává |

### Table 7
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Preferovaný typ investice | Dle enum tiketů a projektů | Zadává, Zdroj pravdy | Zadává |
| Ochota podřízenosti | ENUM: Ano / Ne / Individuálně | Zadává, Zdroj pravdy | Zadává |
| Ochota bankovního spolufinancování | ENUM: Ano / Ne | Zadává, Zdroj pravdy | Zadává |
| Ochota vstupu do SPV | ENUM: Ano / Ne | Zadává, Zdroj pravdy | Zadává |

### Table 8
| Pole | Typ / ENUM | Admin | Broker |
| --- | --- | --- | --- |
| Preferovaný způsob komunikace | ENUM: Telefon / Email / Osobně / Kombinace | Zadává | Zadává |
| Frekvence kontaktu | ENUM: Ihned / Při nové nabídce / Periodicky | Zadává | Zadává |
